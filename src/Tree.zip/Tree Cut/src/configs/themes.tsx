export type CSSVars = Record<`--${string}`, string>;
export type ThemeKey = "main";

// const otherStyles: CSSVars = {
//     "--main-border-radius": "20px",
//     "--main-x-padding": "20px",
//     "--main-y-padding": "20px",
//     "--header-height": "60px",
//     "--content-height": "400px",
// }

export const otherColors: CSSVars = {
    "--in-process-color": "225, 241, 49", // rgb(225, 241, 49)
    "--no-confirmed-color": "246, 144, 109", // rgb(246, 144, 109)
    "--confirmed-color": "0, 172, 79", // rgb(0, 172, 79)
}

export const Theme: Record<ThemeKey, CSSVars> = {
    "main": {
        ...otherColors,
        // ...otherStyles,
        "--area-color": "217, 219, 202", // #D9DBCA
        "--icon-color": "50, 59, 35", // rgb(50, 59, 35)
        "--icon-area-color": "174, 179, 162", // #aeb3a2
        "--main-color": "99, 108, 84", // #636C54
        "--active-color": "225, 241, 49", // #e1f131
        "--active-text-color": "252, 254, 238", // #fcfeee
        "--text-color": "17, 24, 39", // #01131F
    }
}
