export interface filterStruct {
    id: ""
}