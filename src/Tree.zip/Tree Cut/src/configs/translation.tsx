export type LangKey = "UZ" | "RU" | "EN";
export const Translations: Record<string, Record<LangKey, string>> = {
    "": {
        UZ: "Hech narsa topilmadi",
        RU: "Ничего не найдено",
        EN: "Nothing found"
    },
    "prefix": {
        UZ: "ta",
        RU: "",
        EN: ""
    },
    "mainPage": {
        UZ: "TreeCut",
        RU: "TreeCut",
        EN: "TreeCut"
    },
    // "mainPage": {
    //     UZ: "Daraxt kesilishi",
    //     RU: "Вырубка деревьев",
    //     EN: "Tree cutting"
    // },
    "statisticPage": {
        UZ: "Statistika",
        RU: "Статистика",
        EN: "Statistics"
    },
    "search": {
        UZ: "Unikal ID ni kiriting",
        RU: "Введите уникальный ID",
        EN: "Enter unique ID",
    },
    "indicatorCount": {
        UZ: "Ob'ektlar soni",
        RU: "Количество объектов",
        EN: "Number of objects",
    },
    "indicatorArea": {
        UZ: "Ob'ektlar maydoni",
        RU: "Площадь объектов",
        EN: "Area of objects",
    },
    "dailyReport": {
        UZ: "Kunlik hisobot",
        RU: "Ежедневный отчет",
        EN: "Daily report",
    },
    "filterTitle": {
        UZ: "Filtrlar",
        RU: "Фильтры",
        EN: "Filters",
    },
    "filterRepublics": {
        UZ: "Respublikalar",
        RU: "Республики",
        EN: "Republics",
    },
    "filterRegions": {
        UZ: "Viloyatlar",
        RU: "Области",
        EN: "Regions",
    },
    "filterDistricts": {
        UZ: "Tumanlar",
        RU: "Районы",
        EN: "Districts",
    },
    "filterDates": {
        UZ: "Sana oralig'i",
        RU: "Диапазон дат",
        EN: "Date range",
    },
    "filterClear": {
        UZ: "Tozalash",
        RU: "Очистить",
        EN: "Clear",
    },
    "filterApply": {
        UZ: "Qo'llash",
        RU: "Применить",
        EN: "Apply",
    },
    "langsTitle": {
        UZ: "Tillar",
        RU: "Языки",
        EN: "Languages",
    },
    "langsName": {
        UZ: "O'zbekcha",
        RU: "Русский",
        EN: "English",
    },
    "tableRegion": {
        UZ: "Hudud",
        RU: "Регион",
        EN: "Region",
    },
    "tableMFY": {
        UZ: "MFY",
        RU: "СГМ",
        EN: "CFU",
    },
    "tableCoordinates": {
        UZ: "Koordinatalar",
        RU: "Координаты",
        EN: "Coordinates",
    },
    "tableDate": {
        UZ: "Sana",
        RU: "Дата",
        EN: "Date",
    },
    "tableArea": {
        UZ: "Maydon (m²)",
        RU: "Площадь (м²)",
        EN: "Area (m²)",
    },
    "tableStatus": {
        UZ: "Holat",
        RU: "Статус",
        EN: "Status",
    },
    "pieChartTitle": {
        UZ: "Statuslar bo'yicha statistika",
        RU: "Статистика по статусам",
        EN: "Statistics by status",
    },
    "pieInTheProcess": {
        UZ: "Jarayonda",
        RU: "В процессе",
        EN: "In process",
    },
    "pieConfirmed": {
        UZ: "Tasdiqlangan",
        RU: "Подтверждено",
        EN: "Confirmed",
    },
    "pieUnverified": {
        UZ: "Tasdiqlanmagan",
        RU: "Неподтверждено",
        EN: "Unverified",
    },
    "pieInformation": {
        UZ: "Ma'lumot",
        RU: "Информация",
        EN: "Information",
    },
    "graphTitle": {
        UZ: "Kunlik statistika",
        RU: "Ежедневная статистика",
        EN: "Daily statistics",
    },
    "graphDaySide": {
        UZ: "Kunlik",
        RU: "Ежедневно",
        EN: "Daily",
    }
};