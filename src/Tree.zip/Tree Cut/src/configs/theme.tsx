type CSSVars = Record<`--${string}`, string>;

const otherStyles: CSSVars = {
    "--main-border-radius": "20px",
    "--main-x-padding": "20px",
    "--main-y-padding": "20px",
}

export type ThemeKey = "main";
export const Theme: Record<ThemeKey, CSSVars> = {
    "main": {
        ...otherStyles,
        "--area-color": "217, 219, 202", // #D9DBCA
        "--main-color": "50, 59, 35", // #323b23
        "--text-color": "220, 220, 220", // #dcdcdc
        "--active-text-color": "17, 24, 39", // #111827
        "--active-color": "225, 241, 49", // #e1f131
    }
};