import { React } from "jimu-core";
import "./SearchButton.css";

import { SearchIcon, CloseIcon } from "../../../configs/icons";
import { Translations, LangKey } from "../../../configs/translation";
import { Theme, ThemeKey } from "../../../configs/theme";

interface SearchButton {
    getButtonsStatus: "" | "inInput" | "outInput";
    setButtonsStatus: (value: "" | "inInput" | "outInput") => void;
    getLang: LangKey;
    getTheme: ThemeKey;
}

export default function SearchButton({
    getButtonsStatus,
    setButtonsStatus,
    getLang,
    getTheme,
}) {
    return (
        <div className="button">
            <div
                className={`buttonLogo ${getButtonsStatus === "inInput" && "active"}`}
                onClick={() =>
                    setButtonsStatus(
                        getButtonsStatus === "inInput"
                            ? "outInput"
                            : "inInput",
                    )
                }
            >
                {getButtonsStatus !== "inInput" ? (
                    <SearchIcon
                        size="30px"
                        color={`rgb(${Theme[getTheme as ThemeKey]["--main-color"]})`}
                    />
                ) : (
                    <CloseIcon
                        size="30px"
                        color={`rgb(${Theme[getTheme as ThemeKey]["--main-color"]})`}
                    />
                )}
            </div>

            <div
                className={`searchInputArea`}
                style={{
                    animationName: getButtonsStatus,
                }}
            >
                <input
                    className="tempInput"
                    placeholder={Translations["search"][getLang]}
                    type="text"
                />
            </div>
        </div>
    );
}
