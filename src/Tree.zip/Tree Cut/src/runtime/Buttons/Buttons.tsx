import { React } from "jimu-core";
import "./Buttons.css";

import {
    LogoIcon,
    // BellIcon,
    // BottomDownIcon,
    // BottomLeftIcon,
    // CalendarIcon,
    // CheckIcon,
    // CloseIcon,
    DailyInformationIcon,
    // DoubleArrowIcon,
    // DownloadIcon,
    FilterIcon,
    // FullScreenIcon,
    LanguageIcon,
    // ListIcon,
    MenuIcon,
    // MinusIcon,
    ObjectAreaIcon,
    ObjectCountIcon,
    // PlusIcon,
    SearchIcon,
    CloseIcon,
    // VideosIcon
} from "../../configs/icons";
import { filterStruct } from "../../configs/config";
import { Translations, LangKey } from "../../configs/translation";
import { Theme, ThemeKey } from "../../configs/theme";
import SearchButton from "./SearchButton/SearchButton";
import LanguageButton from "./LanguageButton/LanguageButton";

interface ButtonsProps {
    setSelectedId: (value: string) => void;
    getTheme: ThemeKey;
    setTheme: (value: ThemeKey) => void;
    getLang: LangKey;
    setLang: (value: LangKey) => void;
}

interface ButtonsStatus {
    search: "" | "inInput" | "outInput";
    filter: boolean;
    language: boolean;
    menu: boolean;
}

export default function Buttons({
    getTheme,
    setTheme,
    getLang,
    setLang,
}: ButtonsProps) {
    const [getButtonsStatus, setButtonsStatus] = React.useState<ButtonsStatus>({
        search: "",
        filter: false,
        language: false,
        menu: false,
    } as ButtonsStatus);

    return (
        <div className="buttons">
            <SearchButton
                getButtonsStatus={getButtonsStatus["search"]}
                setButtonsStatus={(value: "" | "inInput" | "outInput") =>
                    setButtonsStatus((prev: ButtonsStatus) => ({
                        ...prev,
                        search: value,
                    }))
                }
                getLang={getLang}
                getTheme={getTheme}
            />

            <div className="button">
                <div
                    className={`buttonLogo ${getButtonsStatus["filter"] && "active"}`}
                    onClick={() => {
                        setButtonsStatus(
                            (prev: ButtonsStatus) =>
                                ({
                                    ...prev,
                                    filter: !getButtonsStatus["filter"],
                                    language: false,
                                }) as ButtonsStatus,
                        );
                    }}
                >
                    <FilterIcon
                        size="30px"
                        color={`rgb(${Theme[getTheme as ThemeKey]["--main-color"]})`}
                    />
                </div>
                <div className="buttonContent"></div>
            </div>

            <LanguageButton
                getButtonsStatus={getButtonsStatus["language"]}
                setButtonsStatus={(value: boolean) =>
                    setButtonsStatus(
                        (prev: ButtonsStatus) => ({
                            ...prev,
							filter: false,
                            language: value,
                        }),
                    )
                }
                getLang={getLang}
                setLang={setLang}
                getTheme={getTheme}
            />

            <div className="button">
                <div
                    className={`buttonLogo ${getButtonsStatus["menu"] && "active"}`}
                    onClick={() => {
                        setButtonsStatus(
                            (prev: ButtonsStatus) =>
                                ({
                                    ...prev,
                                    menu: !getButtonsStatus["menu"],
                                }) as ButtonsStatus,
                        );
                    }}
                >
                    <MenuIcon
                        size="30px"
                        color={`rgb(${Theme[getTheme as ThemeKey]["--main-color"]})`}
                    />
                </div>
                <div className="buttonContent"></div>
            </div>
        </div>
    );
}
