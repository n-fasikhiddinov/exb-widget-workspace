import { React } from "jimu-core";
import "./LanguageButton.css";

import { LanguageIcon, CheckIcon, CloseIcon } from "../../../configs/icons";
import { Translations, LangKey } from "../../../configs/translation";
import { Theme, ThemeKey } from "../../../configs/theme";

interface LanguageButtonProps {
    getButtonsStatus: boolean;
    setButtonsStatus: (value: boolean) => void;
    getLang: LangKey;
    setLang: (value: LangKey) => void;
    getTheme: ThemeKey;
}

export default function LanguageButton({
    getButtonsStatus,
    setButtonsStatus,
    getLang,
    setLang,
    getTheme,
}: LanguageButtonProps) {
    return (
        <div className="button">
            <div
                className={`buttonLogo ${getButtonsStatus && "active"}`}
                onClick={() => setButtonsStatus(!getButtonsStatus)}
            >
                <LanguageIcon
                    size="30px"
                    color={`rgb(${Theme[getTheme as ThemeKey]["--main-color"]})`}
                />
            </div>
            {getButtonsStatus && (
                <div className="languageSelector">
                    <div className="languageSelectorTitle">
                        {Translations["langsTitle"][getLang]}
                    </div>
                    {Object.entries(Translations["langsName"]).map(
                        (option: [string, string], index: number) => {
                            return (
                                <div
                                    key={index}
                                    className={`languageSelectorOption ${option[0] === getLang && "active"}`}
                                    onClick={() =>
                                        setLang(option[0] as LangKey)
                                    }
                                >
                                    {option[1]}
                                    {option[0] === getLang && (
                                        <CheckIcon
                                            size="30px"
                                            color={`rgb(${Theme[getTheme as ThemeKey]["--main-color"]})`}
                                        />
                                    )}
                                </div>
                            );
                        },
                    )}
                </div>
            )}
        </div>
    );
}
