import { React } from "jimu-core";
import "./Buttons.css";

import { MenuIcon } from "../../configs/icon";
import { filterStruct, selectedPolyStruct } from "../../configs/config";
import { Theme, ThemeKey } from "../../configs/themes";
import { LangKey } from "../../configs/translations";

import SearchButton from "./SearchButton/SearchButton";
import LanguageButton from "./LanguageButton/LanguageButton";
import FilterButton from "./FilterButton/FilterButton";

import FeatureLayer from "@arcgis/core/layers/FeatureLayer";

interface ButtonsProps {
    setFilter: (value: filterStruct) => void;
    polygonRef: React.MutableRefObject<FeatureLayer>;
    setSelectedPoly: React.Dispatch<React.SetStateAction<selectedPolyStruct>>;
    getTheme: ThemeKey;             // ← только для логики переключения
    setTheme: (value: ThemeKey) => void;
    getLang: LangKey;
    setLang: (value: LangKey) => void;
}

interface ButtonsStatus {
    search: "" | "inInput" | "outInput";
    filter: boolean;
    language: boolean;
    menu: boolean;
}

export default function Buttons({
    setFilter,
    polygonRef,
    setSelectedPoly,
    getTheme,
    setTheme,
    getLang,
    setLang,
}: ButtonsProps) {
    const [getButtonsStatus, setButtonsStatus] = React.useState<ButtonsStatus>({
        search: "",
        filter: false,
        language: false,
        menu: false,
    });

    return (
        <div className="buttons">
            <SearchButton
                setSelectedPoly={setSelectedPoly}
                getButtonsStatus={getButtonsStatus.search}
                setButtonsStatus={(value: "" | "inInput" | "outInput") =>
                    setButtonsStatus((prev: ButtonsStatus) => ({ ...prev, search: value }))
                }
                getLang={getLang}
                themeVars={getTheme}
            />

            <FilterButton
                polygonRef={polygonRef}
                getButtonsStatus={getButtonsStatus.filter}
                setButtonsStatus={(value: boolean) =>
                    setButtonsStatus((prev: ButtonsStatus) => ({ ...prev, filter: value, language: false }))
                }
                themeVars={getTheme}
                getLang={getLang}
                setFilter={setFilter}
            />

            <LanguageButton
                getButtonsStatus={getButtonsStatus.language}
                setButtonsStatus={(value: boolean) =>
                    setButtonsStatus((prev: ButtonsStatus) => ({ ...prev, filter: false, language: value }))
                }
                getLang={getLang}
                setLang={setLang}
                themeVars={getTheme}
            />
        </div>
    );
}
