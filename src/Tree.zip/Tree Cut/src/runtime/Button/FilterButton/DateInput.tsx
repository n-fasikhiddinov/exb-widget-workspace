import { React } from "jimu-core"
import { CalendarIcon } from "../../../configs/icons"

interface DateInputProps {
    className?: string
    value: string
    onChange: (value: string) => void
    placeholder?: string
}

const onlyDigits = (value: string): string => {
    return value.replace(/\D/g, "").slice(0, 8)
}

const formatDateValue = (value: string): string => {
    const digits = onlyDigits(value)

    const day = digits.slice(0, 2)
    const month = digits.slice(2, 4)
    const year = digits.slice(4, 8)

    if (digits.length <= 2) return day
    if (digits.length <= 4) return `${day} / ${month}`
    return `${day} / ${month} / ${year}`
}

const isPartialDateValid = (digits: string): boolean => {
    const day = digits.slice(0, 2)
    const month = digits.slice(2, 4)

    if (day.length === 2) {
        const dayNum = Number(day)
        if (dayNum < 1 || dayNum > 31) return false
    }

    if (month.length === 2) {
        const monthNum = Number(month)
        if (monthNum < 1 || monthNum > 12) return false
    }

    return true
}

export const displayToIso = (display: string): string => {
    const digits = onlyDigits(display)
    if (digits.length < 8) return ""
    const day = digits.slice(0, 2)
    const month = digits.slice(2, 4)
    const year = digits.slice(4, 8)
    return `${year}-${month}-${day}`
}

export default function DateInput({
    className,
    value,
    onChange,
    placeholder = "KK / OO / YYYY"
}: DateInputProps) {
    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const raw = e.target.value
        const digits = onlyDigits(raw)

        if (!isPartialDateValid(digits)) return

        onChange(formatDateValue(digits))
    }

    const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
        const allowedControlKeys = [
            "Backspace", "Delete", "ArrowLeft", "ArrowRight",
            "Tab", "Home", "End"
        ]

        if (allowedControlKeys.indexOf(e.key) !== -1) return

        const isSeparator = e.key === " " || e.key === "/" || e.key === "."

        if (isSeparator) {
            e.preventDefault()

            const digits = onlyDigits(value)

            // len === 1 → введена 1 цифра дня,  len === 3 → введена 1 цифра месяца
            if (digits.length === 1 || digits.length === 3) {
                const len = digits.length
                const padded = digits.slice(0, len - 1) + "0" + digits.slice(len - 1)
                if (isPartialDateValid(padded)) {
                    onChange(formatDateValue(padded) + " / ")  // ← добавили " / " в конец
                }
            }

            return
        }

        if (!/^\d$/.test(e.key)) e.preventDefault()
    }

    return (
        <div className="filterDateField">
            <div className="filterDateIcon">
                <CalendarIcon size="24px" color="#000" />
            </div>

            <input
                type="text"
                className={className}
                value={value}
                onChange={handleChange}
                onKeyDown={handleKeyDown}
                placeholder={placeholder}
                inputMode="numeric"
                autoComplete="off"
            />
        </div>
    )
}