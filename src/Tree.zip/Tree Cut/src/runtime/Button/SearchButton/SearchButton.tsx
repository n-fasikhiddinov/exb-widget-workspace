import { React } from "jimu-core";
import "./SearchButton.css";

import { SearchIcon, CloseIcon } from "../../../configs/icon";
import { Translations, LangKey } from "../../../configs/translations";
import { selectedPolyStruct, uniqueIdField } from "../../../configs/config";
import { ThemeKey } from "../../../configs/themes";

interface SearchButtonProps {
    setSelectedPoly: React.Dispatch<React.SetStateAction<selectedPolyStruct>>;
    getButtonsStatus: "" | "inInput" | "outInput";
    setButtonsStatus: (value: "" | "inInput" | "outInput") => void;
    getLang: LangKey;
    themeVars: ThemeKey;             // ← вместо getTheme
}

export default function SearchButton({
    setSelectedPoly,
    getButtonsStatus,
    setButtonsStatus,
    getLang,
    themeVars,
}: SearchButtonProps) {
    const [getSearchInput, setSearchInput] = React.useState<string>("")

    const iconColor = `rgb(${themeVars["--main-color"]})`

    return (
        <div className="button">
            <div
                className={`buttonLogo ${getButtonsStatus === "inInput" && "active"}`}
                onClick={() => {
                    setButtonsStatus(getButtonsStatus === "inInput" ? "outInput" : "inInput")
                    if (getButtonsStatus === "inInput") {
                        setSelectedPoly({
							[uniqueIdField]: ""
						} as selectedPolyStruct)
                        setSearchInput("")
                    }
                }}
            >
                {getButtonsStatus !== "inInput" ? (
                    <SearchIcon size="30px" color={iconColor} />
                ) : (
                    <CloseIcon size="30px" color={iconColor} />
                )}
            </div>

            <div className="searchInputArea" style={{ animationName: getButtonsStatus }}>
                <input
                    value={getSearchInput}
                    className="tempInput"
                    placeholder={Translations["search"][getLang]}
                    type="text"
                    onChange={(value: any) => setSearchInput(value.target.value)}
                    onKeyDown={(event: any) => {
                        if (event.keyCode === 13) {
                            setSelectedPoly(event.target.value)
                            setSearchInput(event.target.value)
                        }
                    }}
                />
            </div>
        </div>
    );
}
