import { React } from "jimu-core"

interface CustomMapProps {
    children: React.ReactNode
    className?: string
    style?: React.CSSProperties
    width?: number
    side?: "left" | "right"
    padding?: number
}

export default function CustomScroll({
    children,
    className = "",
    style = {},
    width = 5,
    side = "right",
    padding = 5
}: CustomMapProps) {
    const childrenRef = React.useRef<HTMLDivElement | null>(null)
    const trackRef = React.useRef<HTMLDivElement | null>(null)
    const scrollerRef = React.useRef<HTMLDivElement | null>(null)

    const scrollerDragging = React.useRef<boolean>(false)
    const dragStartY = React.useRef<number>(0)
    const dragStartScrollTop = React.useRef<number>(0)

    const [showScroll, toggleScroll] = React.useState<boolean>(false)

    const updateScroll = React.useCallback(() => {
        const children = childrenRef.current
        const track = trackRef.current
        const scroller = scrollerRef.current

        if (!children) return

        const needScroll = children.scrollHeight > children.clientHeight
        toggleScroll(needScroll)

        if (!track || !scroller || !needScroll) return

        const trackHeight = track.clientHeight
        const visibleRatio = children.clientHeight / children.scrollHeight
        const scrollerHeight = Math.max(visibleRatio * trackHeight, 15)

        const maxScroll = children.scrollHeight - children.clientHeight
        const maxThumbTop = trackHeight - scrollerHeight
        const scrollRatio = maxScroll > 0 ? children.scrollTop / maxScroll : 0

        scroller.style.height = `${scrollerHeight}px`
        scroller.style.top = `${scrollRatio * maxThumbTop}px`
    }, [])

    React.useEffect(() => {
        const children = childrenRef.current
        if (!children) return

        children.addEventListener("scroll", updateScroll, { passive: true })

        const resize = new ResizeObserver(updateScroll)
        resize.observe(children)

        const mutate = new MutationObserver(updateScroll)
        mutate.observe(children, { childList: true, subtree: true, characterData: true })

        updateScroll()

        return () => {
            children.removeEventListener("scroll", updateScroll)
            resize.disconnect()
            mutate.disconnect()
        }
    }, [updateScroll])

    React.useEffect(() => {
        if (showScroll) {
            requestAnimationFrame(updateScroll)
        }
    }, [showScroll, updateScroll])

    const onMouseDown = (event: React.MouseEvent) => {
        event.preventDefault()

        const children = childrenRef.current
        if (!children) return

        scrollerDragging.current = true
        dragStartY.current = event.clientY
        dragStartScrollTop.current = children.scrollTop

        const onMove = (moveEvent: MouseEvent) => {
            if (!scrollerDragging.current) return

            const children = childrenRef.current
            const track = trackRef.current
            const scroller = scrollerRef.current

            if (!children || !track || !scroller) return

            const maxThumbTop = track.clientHeight - scroller.offsetHeight
            const maxScroll = children.scrollHeight - children.clientHeight

            if (maxThumbTop <= 0 || maxScroll <= 0) return

            const delta = moveEvent.clientY - dragStartY.current
            children.scrollTop =
                dragStartScrollTop.current + delta * (maxScroll / maxThumbTop)
        }

        const onUp = () => {
            scrollerDragging.current = false
            window.removeEventListener("mousemove", onMove)
            window.removeEventListener("mouseup", onUp)
        }

        window.addEventListener("mousemove", onMove)
        window.addEventListener("mouseup", onUp)
    }

    return (
        <div
            className={className}
            style={{
                ...style,
                position: "relative",
                minHeight: 0,
            }}
        >
            <style>{`.customScrollHide::-webkit-scrollbar{display:none}`}</style>

            <div
                ref={childrenRef}
                className="customScrollHide"
                style={{
                    width: "100%",
                    height: "100%",
                    overflowY: "scroll",
                    overflowX: "hidden",
                    scrollbarWidth: "none",
                    msOverflowStyle: "none",
                }}
            >
                {children}
            </div>

            {showScroll && (
                <div
                    ref={trackRef}
                    style={{
                        position: "absolute",
                        top: "5px",
                        bottom: "5px",
                        [side]: `${padding}px`,
                        width: `${width}px`,
                        borderRadius: "10px",
                        backgroundColor: "rgb(var(--icon-area-color))",
                        zIndex: 1000
                    }}
                >
                    <div
                        ref={scrollerRef}
                        onMouseDown={onMouseDown}
                        style={{
                            position: "absolute",
                            left: 0,
                            right: 0,
                            top: 0,
                            borderRadius: "10px",
                            backgroundColor: "rgb(var(--main-color))",
                            cursor: "pointer",
                            transition: "background 0.15s ease-in-out"
                        }}
                    />
                </div>
            )}
        </div>
    )
}