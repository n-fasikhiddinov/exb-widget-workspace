import { React } from "jimu-core"

import FeatureLayer from "@arcgis/core/layers/FeatureLayer"

import "./Table.css"

import { LangKey, Translations } from "../../configs/translations"
import { BottomLeftIcon, EndSkipIcon, NextIcon } from "../../configs/icon"
import { otherColors, Theme, ThemeKey } from "../../configs/themes"
import { buildWhereQuery, filterStruct, selectedPolyStruct, summaryStruct, uniqueIdField } from "../../configs/config"
import Query from "@arcgis/core/rest/support/Query"
import CustomScroll from "./CustomScroll"

interface tableProps {
    getSelectedPoly: selectedPolyStruct;
    setSelectedPoly: React.Dispatch<React.SetStateAction<selectedPolyStruct>>;
    getSummary: summaryStruct;
    mainDateRef: React.MutableRefObject<FeatureLayer>;
    style?: React.CSSProperties;
    className?: string;
    getLang: LangKey;
    getTheme: ThemeKey;
    getFilter: filterStruct;
}

interface pageInfo {
    minPage: number
    currentPage: number
    maxPage: number
}

const getColor = (status: 0 | 1 | 2): string => {
    switch (status) {
        case 0: return otherColors["--in-process-color"];
        case 1: return otherColors["--no-confirmed-color"];
        case 2: return otherColors["--confirmed-color"];
        default: return otherColors["--in-process-color"];
    }
}

export default function Table({
    getSelectedPoly,
    setSelectedPoly,
    getSummary,
    mainDateRef,
    style,
    className,
    getLang,
    getTheme,
    getFilter
}: tableProps) {
    const PAGE_COUNT = 50;

    const [getInputValue, setInputValue] = React.useState<string>("1");
    const [getPageInfo, setPageInfo] = React.useState<pageInfo>({
        minPage: 0,
        currentPage: 0,
        maxPage: 0
    });
    const [showMoreInfo, toggleMoreInfo] = React.useState<boolean>(false);
    const [getTableData, setTableData] = React.useState<any>({
        fields: [],
        features: []
    });

    const gotoPage = (page: number) => {
        const pageNumber = Math.max(getPageInfo.minPage, Math.min(getPageInfo.maxPage, page));

        setInputValue((prev: string) => {
            const nextValue = `${pageNumber + 1}`;
            return prev === nextValue ? prev : nextValue;
        });

        setPageInfo((prev: pageInfo) => {
            if (prev.currentPage === pageNumber) return prev;
            return {
                ...prev,
                currentPage: pageNumber
            };
        });
    };

    React.useEffect(() => {
        setPageInfo({
            minPage: 0,
            currentPage: 0,
            maxPage: Math.floor(getSummary.count / PAGE_COUNT)
        });
    }, [getSummary]);

    React.useEffect(() => {
        mainDateRef.current.queryFeatures(new Query({
            where: buildWhereQuery(getFilter, "Table"),
            returnGeometry: false,
            outFields: [
                uniqueIdField,
                "id_region",
                "id_distric",
                "id_mahalla",
                "area",
                "date",
                "status",
            ],
            start: getPageInfo.currentPage * PAGE_COUNT,
            num: PAGE_COUNT
        })).then((result: any) => {
            setInputValue(getPageInfo.currentPage + 1);
            setTableData({
                fields: result.fields.map((item: any) => item.name),
                features: result.features
            });
        });
    }, [getFilter, getPageInfo, mainDateRef]);

    const GridColumn = React.useMemo(() => {
        const width = window.innerWidth;
        const height = window.innerHeight;

        if (width <= 1920 && height <= 1080) {
            if (!showMoreInfo) return "200px 200px 0 0 190px";
            return "0 0 105px 105px 380px";
        }
        if (!showMoreInfo) return "180px 180px 150px 120px 170px";
        return "150px 150px 120px 0px 380px";
    }, [showMoreInfo]);

    const paginationButtons = () => {
        const btnHalfCount = 2;
        const btns = [];

        for (let buttonIndex = -btnHalfCount; buttonIndex <= btnHalfCount; buttonIndex++) {
            if (buttonIndex === 0) {
                btns.push(
                    <input
                        key="inputBtn"
                        className="paginationInput"
                        type="text"
                        value={getInputValue}
                        onChange={(event: React.InputEvent<HTMLInputElement>) => {
                            if (/^\d*$/.test(event.currentTarget.value)) {
                                setInputValue(event.currentTarget.value);
                            }
                        }}
                        onKeyDown={(event: React.KeyboardEvent<HTMLInputElement>) => {
                            if (event.key === "Enter") {
                                if (getInputValue === "") {
                                    setInputValue(`${getPageInfo.currentPage + 1}`);
                                    return;
                                }

                                gotoPage(Number(getInputValue) - 1);
                            }
                        }}
                    />
                );
                continue;
            }

            const newPage = getPageInfo.currentPage + buttonIndex;

            if (getPageInfo.minPage <= newPage && newPage <= getPageInfo.maxPage) {
                btns.push(
                    <div
                        key={buttonIndex}
                        className="btn"
                        onClick={() => gotoPage(newPage)}
                    >
                        {newPage + 1}
                    </div>
                );
                continue;
            }

            btns.push(
                <div
                    key={buttonIndex}
                    className="btn disable"
                    style={{ opacity: "0.3", cursor: "default" }}
                >
                    -
                </div>
            );
        }

        return btns;
    };

    const statusRender = (status: 0 | 1 | 2): React.ReactNode => {
        const color = getColor(status);
        const isConfirmed = status === 2;

        return (
            <div className={`pulseArea ${showMoreInfo ? "expanded" : ""}`}>
                <div
                    className="pulse pulse-left"
                    style={{
                        ["--status-color" as any]: otherColors["--confirmed-color"],
                        ["--animation-name" as any]: "pulseAnimation",
                        ["--animation-delay" as any]: "0ms",
                    }}
                />

                <div
                    className="pulse pulse-center"
                    style={{
                        ["--status-color" as any]: color,
                        ["--animation-name" as any]: "pulseAnimation",
                        ["--animation-delay" as any]: "200ms",
                    }}
                />

                {isConfirmed && <div
                    className="pulse pulse-right"
                    style={{
                        ["--status-color" as any]: otherColors["--in-process-color"],
                        ["--animation-name" as any]: isConfirmed ? "pulseAnimation" : "none",
                        ["--animation-delay" as any]: "400ms",
                    }}
                />}
            </div>
        );
    };

    return (
        <div
            className={`tableArea ${className ?? ""}`}
            style={style}
        >
            <div className="tableHeader">
                <div className="tableTitle">{Translations["tableTitle"][getLang]}</div>

                <div
                    className={`tableBtn ${showMoreInfo ? "active" : ""}`}
                    onClick={() => toggleMoreInfo((prev: boolean) => !prev)}
                >
                    <BottomLeftIcon
                        size="30px"
                        color={`rgb(${Theme[getTheme]["--text-color"]})`}
                    />
                </div>
            </div>

            <div className="tableDataArea">
                <div
                    className="tableCols"
                    style={{
                        gridTemplateColumns: GridColumn
                    }}
                >
                    <div className="tableCol">{Translations["tableRegionDistrict"][getLang]}</div>
                    <div className="tableCol">{Translations["tableMFY"][getLang]}</div>
                    <div className="tableCol">{Translations["tableDate"][getLang]}</div>
                    <div className="tableCol">{Translations["tableArea"][getLang]}</div>

                    <div className="tableCol">
                        <div className={`statusArea ${showMoreInfo ? "expanded" : ""}`}>
                            <div className="statusName statusName-left">UZKOSMOS</div>
                            <div className="statusName statusName-center">ORMON</div>
                            <div className="statusName statusName-right">PROKAROTURA</div>
                            <div className="statusName statusName-single">
                                {Translations["tableStatus"][getLang]}
                            </div>
                        </div>
                    </div>
                </div>

                <CustomScroll>
                    {getTableData.features.map((row: any) => (
                        <div
                            key={row.attributes[uniqueIdField]}
                            className={`tableRows ${getSelectedPoly[uniqueIdField] === row.attributes[uniqueIdField] ? "active" : ""}`}
                            style={{
                                ["--row-color" as any]: getColor(row.attributes.status),
                                gridTemplateColumns: GridColumn
                            }}
                            onClick={() => setSelectedPoly((prev: selectedPolyStruct) => {
                                if (prev[uniqueIdField] === row.attributes[uniqueIdField]) {
                                    return {
                                        ...prev,
                                        [uniqueIdField]: ""
                                    }
                                }

                                return {
                                    ...prev,
                                    [uniqueIdField]: row.attributes[uniqueIdField]
                                };
                            })}
                        >
                            <div className="tableRow">
                                <div className="tableRegion">{Translations[row.attributes.id_region][getLang]}</div>
                                <div className="tableDistrict">{Translations[row.attributes.id_distric][getLang]}</div>
                            </div>

                            <div className="tableRow">{Translations[row.attributes.id_mahalla][getLang]}</div>
                            <div className="tableRow">{row.attributes.date}</div>
                            <div className="tableRow">{row.attributes.area}</div>
                            <div className="tableRow">{statusRender(row.attributes.status)}</div>
                        </div>
                    ))}
                </CustomScroll>
            </div>

            <div className="paginationArea">
                <div className="pageNumbers">
                    {Translations["tablePage"][getLang]}: {getPageInfo.currentPage + 1}/{getPageInfo.maxPage + 1}
                </div>

                <div className="paginationBtns">
                    <div
                        className={`btn ${getPageInfo.currentPage === getPageInfo.minPage ? "disable" : ""}`}
                        style={{ transform: "rotate(180deg)" }}
                        onClick={() => gotoPage(getPageInfo.minPage)}
                    >
                        <EndSkipIcon
                            size="15px"
                            color={`${Theme[getTheme]["--main-color"]}`}
                        />
                    </div>

                    <div
                        className={`btn ${getPageInfo.currentPage === getPageInfo.minPage ? "disable" : ""}`}
                        style={{ transform: "rotate(180deg)" }}
                        onClick={() => gotoPage(getPageInfo.currentPage - 5)}
                    >
                        <NextIcon
                            size="15px"
                            color={`${Theme[getTheme]["--main-color"]}`}
                        />
                    </div>

                    {paginationButtons()}

                    <div
                        className={`btn ${getPageInfo.currentPage === getPageInfo.maxPage ? "disable" : ""}`}
                        onClick={() => gotoPage(getPageInfo.currentPage + 5)}
                    >
                        <NextIcon
                            size="15px"
                            color={`${Theme[getTheme]["--main-color"]}`}
                        />
                    </div>

                    <div
                        className={`btn ${getPageInfo.currentPage === getPageInfo.maxPage ? "disable" : ""}`}
                        onClick={() => gotoPage(getPageInfo.maxPage)}
                    >
                        <EndSkipIcon
                            size="15px"
                            color={`${Theme[getTheme]["--main-color"]}`}
                        />
                    </div>
                </div>
            </div>
        </div>
    );
}