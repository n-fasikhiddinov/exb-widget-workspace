import { React } from "jimu-core"

import Map from "@arcgis/core/Map"
import MapView from "@arcgis/core/views/MapView"
import FeatureLayer from "@arcgis/core/layers/FeatureLayer"
import SimpleRenderer from "@arcgis/core/renderers/SimpleRenderer"
import SimpleMarkerSymbol from "@arcgis/core/symbols/SimpleMarkerSymbol"
import ColorVariable from "@arcgis/core/renderers/visualVariables/ColorVariable"
import SizeVariable from "@arcgis/core/renderers/visualVariables/SizeVariable"
import UniqueValueRenderer from "@arcgis/core/renderers/UniqueValueRenderer"
import Query from "@arcgis/core/rest/support/Query.js"

import { filterStruct } from "../../configs/config";
import { Translations, LangKey } from "../../configs/translation";
import { Theme, ThemeKey } from "../../configs/theme";

interface CustomMapProps {
    getTheme: ThemeKey;
    getLang: LangKey;
    setMap: (value: MapView) => void;
}

export default function CustomMap({
    getTheme,
    getLang,
    setMap,
}: CustomMapProps) {
    const center = [64.9865, 41.0835]
    const mapRef = React.useRef<HTMLDivElement | null>(null)

    React.useEffect(() => {
        if (!mapRef.current) return
        const map = new Map({
            basemap: "hybrid"
        })

        const mapView = new MapView({
            container: mapRef.current,
            map,
            zoom: 6,
            center: center,
            ui: {
                components: [],
            }
        })

        setMap(mapView)

        return () => {
            mapView.destroy()
        }
    }, [])

    return (
        <div
            ref={mapRef}
            style={{
                position: "absolute",
                top: "0",
                left: "0",
                width: "100%",
                height: "100%"
            }}
        />
    )
}
