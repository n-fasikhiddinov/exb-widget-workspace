import { React } from "jimu-core"
import Map from "@arcgis/core/Map"
import MapView from "@arcgis/core/views/MapView"
import FeatureLayer from "@arcgis/core/layers/FeatureLayer"
import FeatureEffect from "@arcgis/core/layers/support/FeatureEffect"
import FeatureFilter from "@arcgis/core/layers/support/FeatureFilter"

import "./CustomMap.css"

import { FullScreenActiveIcon, FullScreenNoActiveIcon, MinusIcon, PlusIcon } from "../../configs/icon"
import { uniqueIdField, selectedPolyStruct, escapeSqlString } from "../../configs/config"
import { ThemeKey, Theme } from "../../configs/themes"

interface CustomMapProps {
    setSelectedPoly: React.Dispatch<React.SetStateAction<selectedPolyStruct>>;
    getSelectedPoly: selectedPolyStruct;
    toggleScreen: (value: boolean) => void;
    isFullScreen: boolean;
    mainDateRef: React.RefObject<FeatureLayer>;
    setMap: (map: MapView) => void;
    getMap: MapView;
    getTheme: ThemeKey;
}

export default function CustomMap({
    setSelectedPoly,
    getSelectedPoly,
    toggleScreen,
    isFullScreen,
    mainDateRef,
    setMap,
    getMap,
    getTheme
}: CustomMapProps) {
    console.log("[CustomMap Rerender]");
    const customMapRef = React.useRef<HTMLDivElement | null>(null)
    const mapViewRef = React.useRef<MapView | null>(null)
    const layerViewRef = React.useRef<__esri.FeatureLayerView | null>(null)

    React.useEffect(() => {
        if (!customMapRef.current || !mainDateRef.current) return

        const map = new Map({ basemap: "hybrid" })
        const mapView = new MapView({
            container: customMapRef.current,
            map,
            zoom: 6,
            center: [64.9865, 41.0835],
            ui: { components: [] },
            constraints: {
                minZoom: 6,
                maxZoom: 22,
                rotationEnabled: false
            }
        })

        mapViewRef.current = mapView
        map.add(mainDateRef.current)
        setMap(mapView)

        mapView.whenLayerView(mainDateRef.current).then((lv) => {
            layerViewRef.current = lv
        })

        mapView.on("click", (event: __esri.ViewClickEvent) => {
            mapView.hitTest(event).then((response) => {
                const result = response.results.find(
                    (value: __esri.MapViewViewHit) => value.layer === mainDateRef.current
                ) as __esri.GraphicHit | undefined

                if (result?.graphic?.attributes) {
                    const nextId = result.graphic.attributes[uniqueIdField]

                    setSelectedPoly((prev: selectedPolyStruct) => {
                        if (prev[uniqueIdField] === nextId) return prev

                        return {
                            ...prev,
                            [uniqueIdField]: nextId
                        } as selectedPolyStruct
                    })
                }
                else {
                    setSelectedPoly((prev: selectedPolyStruct) => {
                        if (!prev[uniqueIdField]) return prev

                        return {
                            ...prev,
                            [uniqueIdField]: ""
                        } as selectedPolyStruct
                    })
                }
            })
        })

        return () => {
            layerViewRef.current = null
            mapViewRef.current = null
            mapView.destroy()
        }
    }, [setSelectedPoly])

    React.useEffect(() => {
        const mapView = mapViewRef.current
        const layerView = layerViewRef.current
        const layer = mainDateRef.current
        const selectedId = getSelectedPoly?.[uniqueIdField]

        if (!mapView || !layerView || !layer) return

        if (!selectedId) {
            layerView.featureEffect = null
            return
        }

        const where = `${uniqueIdField} = '${escapeSqlString(String(selectedId))}'`

        layerView.featureEffect = new FeatureEffect({
            filter: new FeatureFilter({ where }),
            excludedEffect: "opacity(60%) saturate(0.4)"
        })

        layer.queryFeatures({
            where,
            returnGeometry: true,
            outFields: [uniqueIdField]
        }).then((result: any) => {
            const feature = result.features?.[0]
            const geometry = feature?.geometry
            const extent = geometry?.extent

            if (!geometry || !extent) return

            mapView.goTo(
                {
                    target: extent.expand(2)
                },
                {
                    duration: 400,
                    easing: "ease-in-out"
                }
            )
        }).catch(() => {
            // здесь можно оставить пусто или добавить лог при необходимости
        })
    }, [getSelectedPoly])

    const mapZoom = React.useCallback((zoomValue: number) => {
        if (!getMap) return

        getMap.goTo(
            { zoom: getMap.zoom + zoomValue },
            { duration: 400 }
        )
    }, [getMap])

    return (
        <div className="CustomMapArea">
            <div className="customMap" ref={customMapRef} />

            <div className="mapBtns">
                <div className="mapBtn" onClick={() => mapZoom(+1)}>
                    <PlusIcon
                        size="25px"
                        color={`${Theme[getTheme]["--active-text-color"]}`}
                    />
                </div>
                <div className="mapBtn" onClick={() => mapZoom(-1)}>
                    <MinusIcon
                        size="25px"
                        color={`${Theme[getTheme]["--active-text-color"]}`}
                    />
                </div>
            </div>

            <div
                className={`mapBtn ${isFullScreen ? "btnBottom" : "btnTop"}`}
                onClick={() => toggleScreen(!isFullScreen)}
            >
                {isFullScreen ? (
                    <FullScreenActiveIcon
                        size={"25px"}
                        color="#000000"
                    />
                ) : (
                    <FullScreenNoActiveIcon
                        size={"25px"}
                        color="#000000"
                    />
                )}
            </div>
        </div>
    )
}