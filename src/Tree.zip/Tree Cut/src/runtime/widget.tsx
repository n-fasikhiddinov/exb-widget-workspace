/** @jsx jsx */
import { React, jsx } from "jimu-core";
import MapView from "@arcgis/core/views/MapView";
import "./style.css";

import { filterStruct } from "../configs/config";
import { Translations, LangKey } from "../configs/translation";
import { Theme, ThemeKey } from "../configs/theme";
import {
    LogoIcon,
    // BellIcon,
    // BottomDownIcon,
    // BottomLeftIcon,
    // CalendarIcon,
    // CheckIcon,
    // CloseIcon,
    DailyInformationIcon,
    // DoubleArrowIcon,
    // DownloadIcon,
    // FilterIcon,
    // FullScreenIcon,
    // LanguageIcon,
    // ListIcon,
    // MenuIcon,
    // MinusIcon,
    ObjectAreaIcon,
    ObjectCountIcon,
    // PlusIcon,
    // SearchIcon,
    // VideosIcon
} from "../configs/icons";

import CustomMap from "./CustomMap/CustomMap";
import Buttons from "./Buttons/Buttons";

export default function Widget() {
    const [getMap, setMap] = React.useState<MapView | null>(null);
    const [getLang, setLang] = React.useState<LangKey>("UZ" as LangKey);
    const [getTheme, setTheme] = React.useState<ThemeKey>("main" as ThemeKey);
	const [getSelectedId, setSelectedId] = React.useState<string>("");
    const [getFilter, setFilter] = React.useState<filterStruct>({
        id: "",
    } as filterStruct);

    return (
        <div style={Theme[getTheme as ThemeKey]} className="mainArea">
            <CustomMap getTheme={getTheme} getLang={getLang} setMap={setMap} />

            <div className="logo">
                <LogoIcon
                    size={["160px", "60px"]}
                    color={`rgb(${Theme[getTheme as ThemeKey]["--text-color"]})`}
                />
            </div>

            <div className="pageBtns">
                <div className="pageBtn active">
                    {Translations["mainPage"][getLang as LangKey]}
                </div>
                <div className="pageBtn">
                    {Translations["statisticPage"][getLang as LangKey]}
                </div>
            </div>

            <Buttons
				setSelectedId={setSelectedId}
                getTheme={getTheme}
                setTheme={setTheme}
                getLang={getLang}
                setLang={setLang}
            />

            <div className="indicators">
                <div className="indicator">
                    <div className="indicatorLogo">
                        <ObjectCountIcon
                            size="40px"
                            color={`rgb(${Theme[getTheme as ThemeKey]["--main-color"]})`}
                        />
                    </div>
                    <div className="indicatorInfo">
                        <div className="indicatorTitle">
                            {Translations["indicatorCount"][getLang as LangKey]}
                        </div>
                        <div className="indicatorValue">111217121</div>
                    </div>
                </div>
                <div className="indicator">
                    <div className="indicatorLogo">
                        <ObjectAreaIcon
                            size="40px"
                            color={`rgb(${Theme[getTheme as ThemeKey]["--main-color"]})`}
                        />
                    </div>
                    <div className="indicatorInfo">
                        <div className="indicatorTitle">
                            {Translations["indicatorArea"][getLang as LangKey]}
                        </div>
                        <div className="indicatorValue">111217121</div>
                    </div>
                </div>
                <div className="indicator">
                    <div className="indicatorLogo">
                        <DailyInformationIcon
                            size="40px"
                            color={`rgb(${Theme[getTheme as ThemeKey]["--main-color"]})`}
                        />
                    </div>
                    <div className="indicatorInfo">
                        <div className="indicatorTitle">
                            {Translations["dailyReport"][getLang as LangKey]}
                        </div>
                        <div className="indicatorValue">111217121</div>
                    </div>
                </div>
            </div>

            <div className="contentSection">
                <div className="table"></div>
                <div className="pieChart"></div>
                <div className="graph"></div>
            </div>
        </div>
    );
}
/*
<BellIcon
    size="50px"
    color="#F0FF0F"
/>
<BottomDownIcon
    size="50px"
    color="#F0FF0F"
/>
<BottomLeftIcon
    size="50px"
    color="#F0FF0F"
/>
<CalendarIcon
    size="50px"
    color="#F0FF0F"
/>
<CheckIcon
    size="50px"
    color="#F0FF0F"
/>
<CloseIcon
    size="50px"
    color="#F0FF0F"
/>
<DailyInformation
    size="50px"
    color="#F0FF0F"
/>
<DoubleArrowIcon
    size="50px"
    color="#F0FF0F"
/>
<DownloadIcon
    size="50px"
    color="#F0FF0F"
/>
<FilterIcon
    size="50px"
    color="#F0FF0F"
/>
<FullScreenIcon
    size="50px"
    color="#F0FF0F"
/>
<Language
    size="50px"
    color="#F0FF0F"
/>
<ListIcon
    size="50px"
    color="#F0FF0F"
/>
<MenuIcon
    size="50px"
    color="#F0FF0F"
/>
<MinusIcon
    size="50px"
    color="#F0FF0F"
/>
<ObjectAreaIcon
    size="50px"
    color="#F0FF0F"
/>
<ObjectCountIcon
    size="50px"
    color="#F0FF0F"
/>
<PlusIcon
    size="50px"
    color="#F0FF0F"
/>
<SearchIcon
    size="50px"
    color="#F0FF0F"
/>
<VideosIcon
    size="50px"
    color="#F0FF0F"
/>
*/

