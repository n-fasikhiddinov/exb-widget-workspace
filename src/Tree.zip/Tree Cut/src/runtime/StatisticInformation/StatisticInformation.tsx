import { React } from "jimu-core"

import FeatureLayer from "@arcgis/core/layers/FeatureLayer"

import "./StatisticInformation.css"

import { filterStruct, selectedPolyStruct, summaryStruct } from "../../configs/config"
import { ThemeKey } from "../../configs/themes"
import { LangKey } from "../../configs/translations"
import Table from "../Tabe/Table"
import Graph from "../Graph/Graph"
import TreeCutPieChart from "../TreeCutPieChart/TreeCutPieChart"

interface statisticInformationProps {
    getSelectedPoly: selectedPolyStruct
    setSelectedPoly: React.Dispatch<React.SetStateAction<selectedPolyStruct>>
    getSummary: summaryStruct
    mainDateRef: React.MutableRefObject<FeatureLayer>
    isFullScreen: boolean
    getFilter: filterStruct
    setFilter: React.Dispatch<React.SetStateAction<filterStruct>>
    getTheme: ThemeKey
    getLang: LangKey
}

export default function StatisticInformation({
    getSelectedPoly,
    setSelectedPoly,
    getSummary,
    mainDateRef,
    isFullScreen,
    getFilter,
    setFilter,
    getTheme,
    getLang
}: statisticInformationProps) {
    console.log("[Statistic Rerender]");
    // const [getDivInfo, setDivInfo] = React.useState<DOMRect | null>(null);
    const [getDivInfo, setDivInfo] = React.useState<number>(0);
    const divRef = React.useRef<HTMLDivElement | null>(null);

    React.useLayoutEffect(() => {
        if (divRef.current) setDivInfo(Math.floor((divRef.current.getBoundingClientRect().width - 20) / 3));
    }, [])

    return <>
        <div className="widthDiv" ref={divRef} />
        <Table
            getSummary={getSummary}
            mainDateRef={mainDateRef}
            getSelectedPoly={getSelectedPoly}
            setSelectedPoly={setSelectedPoly}
            style={{
                left: "0",
                width: `${getDivInfo}px`
            }}
            className={`panel side ${isFullScreen ? "bottomPanel" : "topPanel"}`}
            getLang={getLang}
            getTheme={getTheme}
            getFilter={getFilter}
        />
        <TreeCutPieChart
            getSummary={getSummary}
            style={{
                left: "50%",
                width: `${getDivInfo}px`
            }}
            mainDateRef={mainDateRef}
            className={`panel middle ${isFullScreen ? "bottomPanel" : "topPanel"}`}
            getLang={getLang}
            getTheme={getTheme}
            getFilter={getFilter}
            setFilter={setFilter}
        />
        <Graph
            style={{
                right: "0",
                width: `${getDivInfo}px`
            }}
            mainDateRef={mainDateRef}
            className={`panel side ${isFullScreen ? "bottomPanel" : "topPanel"}`}
            getLang={getLang}
            getTheme={getTheme}
            getFilter={getFilter}
            setFilter={setFilter}
        />
    </>
}