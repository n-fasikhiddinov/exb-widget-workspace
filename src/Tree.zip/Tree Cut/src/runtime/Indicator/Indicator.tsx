import { React } from "jimu-core"

interface indicatorProps {
    value: number;
    duration?: number;
    digits?: number;
}

export default function Indicator({
    value,
    duration = 600,
    digits = 0
}: indicatorProps) {
    const [getValue, setValue] = React.useState<number>(value);
    const frameRef = React.useRef<number | null>(null);
    const startTimeRef = React.useRef<number | null>(null);
    const startValueRef = React.useRef<number>(value);

    React.useEffect(() => {
        if (frameRef.current !== null) cancelAnimationFrame(frameRef.current);

        startValueRef.current = getValue;
        startTimeRef.current = null;

        const animate = (time: number) => {
            if (startTimeRef.current === null) startTimeRef.current = time;

            const elapsed = time - startTimeRef.current;
            const progress = Math.min(elapsed / duration, 1);

            const eased = 1 - Math.pow(1 - progress, 3);
            const nextValue = startValueRef.current + (value - startValueRef.current) * eased;

            setValue(nextValue);

            if (progress < 1) {
                frameRef.current = requestAnimationFrame(animate);
            }
            else {
                setValue(value);
                frameRef.current = null;
            }
        }

        frameRef.current = requestAnimationFrame(animate);

        return () => {
            if (frameRef.current !== null) cancelAnimationFrame(frameRef.current);
        }
    }, [value])

    return <span>{Number(getValue.toFixed(digits)).toLocaleString("ru-RU", {
        minimumFractionDigits: digits,
        maximumFractionDigits: digits
    })}</span>
}