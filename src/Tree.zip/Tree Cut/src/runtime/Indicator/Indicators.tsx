import { React } from "jimu-core"

import "./Indicators.css"

import { ObjectCountIcon, ObjectAreaIcon, DailyInformationIcon } from "../../configs/icon";
import { ThemeKey, Theme } from "../../configs/themes"
import { LangKey, Translations } from "../../configs/translations";
import { summaryStruct } from "../../configs/config";

import Indicator from "./Indicator";

interface indicatorsProps {
    getTheme: ThemeKey;
    getLang: LangKey;
    getSummary: summaryStruct;
    isFullScreen: boolean;
}

interface indicatorInfo {
    title: string;
    value: "count" | "sum" | "dailyCount";
    prefix: string;
    icon: any;
}

export default function Indicators({
    getTheme,
    getLang,
    getSummary,
    isFullScreen
}: indicatorsProps) {
    console.log("[Indicators Rerender]");
    const indicators: indicatorInfo[] = [
        {
            title: "indicatorCount",
            value: "count",
            prefix: "countPrefix",
            icon: <ObjectCountIcon
                size="35px"
                color={`rgb(${Theme[getTheme]["--icon-color"]})`}
            />
        },
        {
            title: "indicatorArea",
            value: "sum",
            prefix: "areaPrefix",
            icon: <ObjectAreaIcon
                size="35px"
                color={`rgb(${Theme[getTheme]["--icon-color"]})`}
            />
        },
        {
            title: "indicatorDailyCount",
            value: "dailyCount",
            prefix: "countPrefix",
            icon: <DailyInformationIcon
                size="35px"
                color={`rgb(${Theme[getTheme]["--icon-color"]})`}
            />
        },
    ]
    return <>
        {indicators.map((item: indicatorInfo, index: number, arr: indicatorInfo[]) => {
            return (<div className={`indicatorArea ${isFullScreen ? "topIndicator" : "bottomIndicator"}`}
                style={{
                    left: `calc(${(index * 280)}px)`,
                    top: `calc(-${isFullScreen ? 40 : 0}px)`,
                    transitionDelay: `${index * 50}ms`,
                    opacity: `${isFullScreen ? 0 : 1}`
                }}
            >
                <div className="indicatorLogo"
                    style={{
                        animationDelay: `${index * 300}ms`,
                    }}
                >{item["icon"]}</div>
                <div className="indicatorInfo">
                    <div className="indicatorTitle">{Translations[item["title"]][getLang]}</div>
                    <div className="indicatorValue">
                        <Indicator
                            value={getSummary[item["value"]] ?? 0}
                            duration={500}
                        />
                        <span style={{ userSelect: "none" }}>&nbsp;{Translations[item["prefix"]][getLang]}</span>
                    </div>
                </div>
            </div>)
        })}
    </>
}