import { React } from "jimu-core"

import "./Popup.css"

import { buildSelectedWhereQuery, selectedPolyStruct, uniqueIdField } from "../../configs/config";
import { LangKey, Translations } from "../../configs/translations";
import { Theme, ThemeKey } from "../../configs/themes";
import { CloseIcon } from "../../configs/icon";
import CustomScroll from "../Tabe/CustomScroll";

import FeatureLayer from "@arcgis/core/layers/FeatureLayer";

interface PopupProps {
    mainDateRef: React.RefObject<FeatureLayer>;
    isFullScreen: boolean;
    setSelectedPoly: React.Dispatch<React.SetStateAction<selectedPolyStruct>>;
    getSelectedPoly: selectedPolyStruct;
    getLang: LangKey;
    getTheme: ThemeKey
}

export default function Popup({
    mainDateRef,
    isFullScreen,
    setSelectedPoly,
    getSelectedPoly,
    getLang,
    getTheme
}: PopupProps) {
    console.log("[Popup Rerender]");
    const timeoutRef = React.useRef<NodeJS.Timeout | null>(null);
    const [showFullImg, toggleFullImg] = React.useState<boolean>(false)
    const [getCopyText, setCopyText] = React.useState<string>("");
    const [getPopupInfo, setPopupInfo] = React.useState<any>({
        attribute: {},
        images: {
            before: "",
            after: ""
        }
    })

    React.useEffect(() => {
        if (!getSelectedPoly[uniqueIdField]) return;
        mainDateRef.current.queryFeatures({
            where: buildSelectedWhereQuery(getSelectedPoly),
            returnGeometry: false,
            outFields: [
                "id_region",
                "id_distric",
                "id_mahalla",
                "area",
                "date",
                "type_tree",
                "count_tree",
                "status",
                "tax",
            ]
        })
            .then((result: any) => {
                setPopupInfo((prev: any) => ({
                    ...prev,
                    attribute: result.features[0].attributes
                }))
            })
            .catch((error: any) => console.error("Query failed Popup:", error))

        fetch(`http://localhost:8005/panel/api/cases/photos/${getSelectedPoly[uniqueIdField]}/`)
            .then((result: any) => result.json())
            .then((data: any) => {
                setPopupInfo((prev: any) => ({
                    ...prev,
                    images: {
                        before: data[0].before,
                        after: data[0].after
                    }
                }))
            })
    }, [getSelectedPoly])

    React.useEffect(() => {
        if (!getCopyText) return;

        (async () => {
            try {
                await navigator.clipboard.writeText(getCopyText);

                timeoutRef.current = setTimeout(() => {
                    setCopyText("");
                }, 600);

            } catch (error) {
                console.error("Ошибка копирования:", error);
            }
        })();

        return () => {
            if (timeoutRef.current) {
                clearTimeout(timeoutRef.current);
                timeoutRef.current = null;
            }
        };
    }, [getCopyText])

    return <>
        <div className={`popupArea 
            ${getSelectedPoly[uniqueIdField] ? "popupIn" : "popupOut"}
            ${isFullScreen ? "popupBottom" : "popupTop"}
        `}>
            <div className="popCloseBtn"
                onClick={() => {
                    setSelectedPoly((prev: selectedPolyStruct) => {
                        if (!prev[uniqueIdField]) return prev
                        return {
                            ...prev,
                            [uniqueIdField]: ""
                        }
                    })
                }}
            >
                <CloseIcon
                    size="20px"
                    color={`rgb(${Theme[getTheme]["--text-color"]})`}
                />
            </div>
            <div className="popupTitle">{Translations["popupTitle"][getLang]}</div>
            {/* <div className="popupInfoRows"> */}
            <CustomScroll
                className="popupInfoRows"
                width={3}
                side="left"
                padding={-5}
            >
                {Object.entries(getPopupInfo.attribute).map((value: [string, any]) => {
                    let option = value[1] ?? "-";
                    if ([
                        "id_region",
                        "id_distric",
                        "id_mahalla",
                        "status",
                    ].includes(value[0])) option = Translations?.[option]?.[getLang] ?? option;
                    if (value[0] === "type_tree") {
                        return (<>
                            <div className="popupTitle">{Translations["popupIns"][getLang]}</div>
                            <div className="popupInfoRow">
                                <div className="popupInfoKey">{Translations[value[0]][getLang]}:</div>
                                <div className="popupInfoValue">{option}</div>
                            </div>
                        </>)
                    }

                    return (<div className="popupInfoRow">
                        <div className="popupInfoKey">{Translations[value[0]][getLang]}:</div>
                        <div className="popupInfoValue">{option}</div>
                    </div>)
                })}
            </CustomScroll>
            {/* </div> */}
        </div>

        <div className={`imagesArea 
                ${getSelectedPoly[uniqueIdField] ? "popupIn" : "popupOut"}
                ${isFullScreen ? "popupBottom" : "popupTop"}
            `}
            onClick={() => toggleFullImg(true)}
        >
            <div className="imageBlock">
                <div className="imageTitle">{Translations["beforeStatus"][getLang]}</div>
                <div className="imageArea"
                    style={{
                        backgroundImage: `url(${getPopupInfo["images"]["before"]})`
                    }}
                />
            </div>
            <div className="imageBlock">
                <div className="imageTitle">{Translations["afterStatus"][getLang]}</div>
                <div className="imageArea"
                    style={{
                        backgroundImage: `url(${getPopupInfo["images"]["after"]})`
                    }}
                />
            </div>
        </div>

        <div className={`uniqueIdArea 
            ${getSelectedPoly[uniqueIdField] ? "popupIn" : "popupOut"}
            ${isFullScreen ? "popupBottom" : "popupTop"}
        `}>
            {/* <div className="uniqueIdTitle">{Translations["uniqueId"][getLang]}</div> */}
            <div className={`uniqueIdBlock ${getCopyText !== "" && "copy"}`}>
                <div className="uniqueIdCopy"
                    onClick={() => {
                        if (getCopyText !== "") return;
                        setCopyText(getSelectedPoly[uniqueIdField])
                    }}
                >ID: {getSelectedPoly[uniqueIdField]}</div>
                <div className="uniqueIdCopied">{Translations["copied"][getLang]}</div>
            </div>
        </div>

        {showFullImg && <div className="fullShowArea" onClick={(e) => {
            if (e.target === e.currentTarget) {
                toggleFullImg(false);
            }
        }}>
            <div className="fullShowBlock">
                <div className="fullShowImagesArea">
                    <div className="fullShowImagesBlock">
                        <div className="fullShowImage"
                            style={{
                                backgroundImage: `url(${getPopupInfo["images"]["before"]})`
                            }}
                        />
                        <div className="fullShowImageTitle">{Translations["beforeStatus"][getLang]}</div>
                    </div>
                    <div className="fullShowImagesBlock">
                        <div className="fullShowImage"
                            style={{
                                backgroundImage: `url(${getPopupInfo["images"]["after"]})`
                            }}
                        />
                        <div className="fullShowImageTitle">{Translations["afterStatus"][getLang]}</div>
                    </div>
                </div>
                {/* <div className="fullShowInfoArea">
                    <div className="fullShowInfoText">{`
                        Адрес: 
                        ${Translations?.[getPopupInfo.attribute["id_region"]]?.[getLang] ?? getPopupInfo.attribute["id_region"]}
                        ${Translations?.[getPopupInfo.attribute["id_distric"]]?.[getLang] ?? getPopupInfo.attribute["id_region"]}
                        ${Translations?.[getPopupInfo.attribute["id_mahalla"]]?.[getLang] ?? getPopupInfo.attribute["id_region"]}
                    `}
                    </div>
                    <div className="fullShowInfoText"></div>
                    <div className="fullShowInfoText"></div>
                </div> */}
            </div>
        </div>}
    </>
}