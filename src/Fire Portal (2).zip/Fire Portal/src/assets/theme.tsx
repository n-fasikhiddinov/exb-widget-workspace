type CSSVars = Record<`--${string}`, string>;
// export type ThemeKey = "light" | "blue" | "dark" | "darker";
export type ThemeKey = "light" | "dark";

import dark_bg from "./darkBackgrounImage.png";
import blue_bg from "./blueBackgrounImage.jpg"

const otherStyles: CSSVars = {
    "--active-color": "96, 130, 240", /* #3660e7 #6082f0 rgb(96, 130, 240) */
    "--error-color": "255, 102, 102", /* #ff6666 */
    "--main-color-hsl": "214, 61%", /* #74a2dd */
    "--checked-color": "35, 131, 249", /* #2383F9 */
}

export const otherColors: CSSVars = {
    "--in-process": "255, 252, 64", /* rgb(255, 252, 64); */
    "--no-confirmed-color": "188, 27, 27", /* #BC1B1B */
    "--confirmed-color": "40, 193, 65", /* #28c141 */
}

export const Theme: Record<ThemeKey, CSSVars> = {
    "light": {
        "--background-img": "",
        ...otherStyles,
        ...otherColors,
        "--main-bg": "246, 247, 252", /* #F6F7FC */
        "--area-bg": "255, 255, 255", /* #FFFFFF */
        "--color": "12, 27, 36", /* #0C1B24 */
    },
    // "blue": {
    //     "--background-img": blue_bg,
    //     ...otherStyles,
    //     ...otherColors,
    //     "--main-bg": "70, 56, 107", /* rgb(70, 56, 107) */
    //     "--area-bg": "50, 44, 66", /* rgb(50, 44, 66) */
    //     "--color": "242, 242, 252", /* rgb(242, 242, 252) */
    //     "--main-color-hsl": "244, 56%", /* hsl(244, 79%, 69%) */
    // },
    // "dark": {
    //     "--background-img": dark_bg,
    //     ...otherStyles,
    //     ...otherColors,
    //     "--main-bg": "4, 13, 21", /* #172430 */
    //     "--area-bg": "16, 37, 53", /* #102535 */
    //     "--color": "255, 255, 255", /* #FFFFFF */
    // },
    "dark": {
        "--background-img": "",
        ...otherStyles,
        ...otherColors,
        "--main-bg": "16, 17, 27", /* #10111B */
        "--area-bg": "31, 32, 48", /* #1F2030 */
        "--color": "255, 255, 255", /* #FFFFFF */
    },
}