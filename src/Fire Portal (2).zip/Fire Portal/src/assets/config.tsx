import { getAppStore } from "jimu-core";

export const uniqueIdField = "uniqueid";

export interface selectedPolyStruct {
    [uniqueIdField]: string;
}

export interface filterStruct {
    type_id: string | number;

    region_id: string;
    distric_id: string;

    year: string;
    month: string;
    day: string;

    fire_present: string;
}

export interface getDataValue {
    name: string;
    count_area: number;
    sum_area: number;
}

export const escapeSqlString = (value: string): string => {
    return value.replace(/'/g, "''");
};

export const buildFirePresentWhere = (value: string): string => {
    const normalized = String(value ?? "").trim();

    if (!normalized) {
        return "";
    }

    // 0 = в процессе
    if (normalized === "0") {
        return "fire_present IS NULL";
    }

    // 1 = подтверждено
    if (normalized === "1") {
        return "fire_present = true";
    }

    // 2 = не подтверждено
    if (normalized === "2") {
        return "fire_present = false";
    }

    // 3 = подтверждено + не подтверждено
    if (normalized === "3") {
        return "fire_present IS NOT NULL";
    }

    return "";
};

const addBaseFilters = (result: string[], filter: filterStruct): void => {
    if (filter.year) {
        const year = escapeSqlString(filter.year);

        // Часть тестовых записей может иметь пустое/неверное поле year,
        // хотя правильный год присутствует в текстовом fire_date (ДД/ММ/ГГГГ).
        // Поэтому год проверяем по обоим полям.
        result.push(`(year = '${year}' OR fire_date LIKE '%/${year}%')`);
    }
    if (filter.type_id !== "" && filter.type_id !== null && filter.type_id !== undefined) {
        const typeId = String(filter.type_id).trim();

        // Важно сохранять фактический тип значения из Feature Layer.
        // Если type_id хранится как строка, запрос должен содержать кавычки.
        // Если поле числовое, значение приходит из selector как number.
        result.push(
            typeof filter.type_id === "number"
                ? `type_id = ${filter.type_id}`
                : `type_id = '${escapeSqlString(typeId)}'`
        );
    }
    if (filter.region_id) result.push(`region_id = '${escapeSqlString(filter.region_id)}'`);
};

const addDistrictFilter = (result: string[], filter: filterStruct): void => {
    if (filter.distric_id) result.push(`distric_id = '${escapeSqlString(filter.distric_id)}'`);
};

const addFirePresentFilter = (result: string[], filter: filterStruct): void => {
    const where = buildFirePresentWhere(filter.fire_present);

    if (where) {
        result.push(where);
    }
};

export interface ParsedFireDate {
    year?: string;
    month?: string;
    day?: string;
}

export const twoDigit = (value: string | number): string => {
    const normalized = String(Number(value));
    return normalized.length === 1 ? `0${normalized}` : normalized;
};

const numericDatePart = (value: string | number): string => {
    const n = Number(String(value ?? "").trim());
    return Number.isFinite(n) && n > 0 ? String(n) : "";
};

const unique = (values: string[]): string[] => Array.from(new Set(values.filter(Boolean)));

export const parseFireDateText = (raw: any): ParsedFireDate => {
    if (raw instanceof Date && !Number.isNaN(raw.getTime())) {
        return {
            year: String(raw.getFullYear()),
            month: twoDigit(raw.getMonth() + 1),
            day: twoDigit(raw.getDate()),
        };
    }

    if (typeof raw === "number" && Number.isFinite(raw)) {
        const date = new Date(raw);
        if (!Number.isNaN(date.getTime())) {
            return {
                year: String(date.getFullYear()),
                month: twoDigit(date.getMonth() + 1),
                day: twoDigit(date.getDate()),
            };
        }
    }

    const s = String(raw ?? "").trim();
    if (!s) return {};

    // Данные в слое лежат текстом в формате день/месяц/год.
    const parts = s.split("/").map((part) => part.trim()).filter(Boolean);

    if (parts.length === 3) {
        const [day, month, year] = parts;

        if (/^\d{1,2}$/.test(day) && /^\d{1,2}$/.test(month) && /^\d{4}$/.test(year)) {
            return { day: twoDigit(day), month: twoDigit(month), year };
        }
    }

    if (/^\d{1,2}$/.test(s)) return { month: twoDigit(s) };

    return {};
};

export const fireDateToTime = (raw: any): number => {
    const parsed = parseFireDateText(raw);
    const y = Number(parsed.year);
    const m = Number(parsed.month);
    const d = Number(parsed.day);

    if (!Number.isFinite(y) || !Number.isFinite(m) || !Number.isFinite(d)) {
        return Number.NaN;
    }

    return new Date(y, m - 1, d).getTime();
};

export const compareFireDateText = (a: any, b: any): number => {
    const ta = fireDateToTime(a);
    const tb = fireDateToTime(b);

    if (Number.isFinite(ta) && Number.isFinite(tb)) return ta - tb;
    if (Number.isFinite(ta)) return -1;
    if (Number.isFinite(tb)) return 1;

    return String(a ?? "").localeCompare(String(b ?? ""));
};

const buildFireDateWhere = (month: string, day?: string): string => {
    const m = numericDatePart(month);
    const mm = twoDigit(month);

    if (!m) return "";

    const monthValues = unique([m, mm]);

    if (day) {
        const d = numericDatePart(day);
        const dd = twoDigit(day);

        if (!d) return "";

        const dayValues = unique([d, dd]);
        const conditions: string[] = [];

        dayValues.forEach((dayValue) => {
            monthValues.forEach((monthValue) => {
                conditions.push(`fire_date LIKE '${dayValue}/${monthValue}/%'`);
            });
        });

        return `(${unique(conditions).join(" OR ")})`;
    }

    const conditions = monthValues.map((monthValue) => {
        return `fire_date LIKE '%/${monthValue}/%'`;
    });

    return `(${unique(conditions).join(" OR ")})`;
};


export type RuleOperator = "equal" | "range" | "include" | "like";

export interface AccessRule {
    id: string;
    operator: RuleOperator;
    value?: string;
    from?: string;
    to?: string;
    values?: string[];
    groups: string[];
}

export interface AccessFieldRule {
    id: string;
    title: string;
    field: string;
    rules: AccessRule[];
}

export interface AccessConfig {
    fullAccessGroups: string[];
    rules: AccessFieldRule[];
}

const emptyAccessConfig: AccessConfig = {
    fullAccessGroups: [],
    rules: [],
};

let activeAccessConfig: AccessConfig = emptyAccessConfig;
let access = "1=0";

export let fullAccess = false;
export let region = "1=0";

const normalizeOperator = (operator: any): RuleOperator => {
    if (
        operator === "equal" ||
        operator === "range" ||
        operator === "include" ||
        operator === "like"
    ) {
        return operator;
    }

    if (operator === "eq") return "equal";
    if (operator === "between") return "range";
    if (operator === "in") return "include";

    return "equal";
};

const normalizeAccessConfig = (config: any): AccessConfig => {
    const rawConfig =
        typeof config?.asMutable === "function"
            ? config.asMutable({ deep: true })
            : config;

    if (!rawConfig) {
        return emptyAccessConfig;
    }

    return {
        fullAccessGroups: Array.isArray(rawConfig.fullAccessGroups)
            ? rawConfig.fullAccessGroups.map((groupId: any) => String(groupId))
            : [],
        rules: Array.isArray(rawConfig.rules)
            ? rawConfig.rules.map((fieldRule: any) => ({
                id: String(fieldRule?.id ?? ""),
                title: String(fieldRule?.title ?? ""),
                field: String(fieldRule?.field ?? ""),
                rules: Array.isArray(fieldRule?.rules)
                    ? fieldRule.rules.map((rule: any) => ({
                        id: String(rule?.id ?? ""),
                        operator: normalizeOperator(rule?.operator),
                        value: rule?.value !== undefined
                            ? String(rule.value)
                            : undefined,
                        from: rule?.from !== undefined
                            ? String(rule.from)
                            : undefined,
                        to: rule?.to !== undefined
                            ? String(rule.to)
                            : undefined,
                        values: Array.isArray(rule?.values)
                            ? rule.values.map((value: any) => String(value))
                            : [],
                        groups: Array.isArray(rule?.groups)
                            ? rule.groups.map((groupId: any) => String(groupId))
                            : [],
                    }))
                    : [],
            }))
            : [],
    };
};

const quoteValue = (value: string): string => {
    const trimmed = String(value ?? "").trim();

    if (trimmed.toLowerCase() === "true" || trimmed.toLowerCase() === "false") {
        return trimmed.toLowerCase();
    }

    return `'${escapeSqlString(trimmed)}'`;
};

const buildAccessRuleWhere = (field: string, rule: AccessRule): string => {
    if (field.trim() === "") {
        return "1=0";
    }

    if (rule.operator === "equal") {
        return `${field} = ${quoteValue(rule.value ?? "")}`;
    }

    if (rule.operator === "range") {
        return `${field} BETWEEN ${quoteValue(rule.from ?? "")} AND ${quoteValue(rule.to ?? "")}`;
    }

    if (rule.operator === "include") {
        const values = rule.values ?? [];

        if (values.length === 0) {
            return "1=0";
        }

        return `${field} IN (${values.map(quoteValue).join(", ")})`;
    }

    if (rule.operator === "like") {
        return `${field} LIKE ${quoteValue(rule.value ?? "")}`;
    }

    return "1=0";
};

const getCurrentUserGroupIds = (): string[] => {
    return Array.from(
        getAppStore().getState()?.user?.groups ?? []
    ).map((group: any) => String(group.id));
};

const checkingAccess = (config: AccessConfig): string => {
    const userGroups = getCurrentUserGroupIds();

    const hasFullAccess = config.fullAccessGroups.some((groupId: string) => {
        return userGroups.includes(groupId);
    });

    if (hasFullAccess) {
        return "1=1";
    }

    for (let fieldIndex = 0; fieldIndex < config.rules.length; fieldIndex++) {
        const fieldRule = config.rules[fieldIndex];

        for (let ruleIndex = 0; ruleIndex < fieldRule.rules.length; ruleIndex++) {
            const rule = fieldRule.rules[ruleIndex];

            const hasRuleAccess = rule.groups.some((groupId: string) => {
                return userGroups.includes(groupId);
            });

            if (hasRuleAccess) {
                return buildAccessRuleWhere(fieldRule.field, rule);
            }
        }
    }

    return "1=0";
};

const updateComputedAccess = (): void => {
    access = checkingAccess(activeAccessConfig);
    fullAccess = access === "1=1";

    if (fullAccess) {
        region = "";
        return;
    }

    const regionMatch = /^region_id\s*=\s*'?([^'\s]+)'?$/i.exec(access);
    region = regionMatch ? regionMatch[1] : "1=0";
};

export const setAccessConfig = (config?: any): void => {
    activeAccessConfig = normalizeAccessConfig(config);
    updateComputedAccess();
};

export const buildSelectedWhereQuery = (selected: selectedPolyStruct): string => {
    return `${access} AND ${uniqueIdField} = '${escapeSqlString(selected[uniqueIdField])}'`;
};

export const buildWhereQuery = (filter: filterStruct, content: string, additionalQuery: string = '1=1'): string => {
    const result: string[] = [
        // "1=1",
        // additionalQuery,
        access
    ];

    switch (content) {
        case "region":
            addBaseFilters(result, filter);
            break;

        case "status":
            addBaseFilters(result, filter);
            addDistrictFilter(result, filter);
            break;

        case "graph":
            addBaseFilters(result, filter);
            addDistrictFilter(result, filter);

            if (filter.month) {
                const fireDateWhere = buildFireDateWhere(filter.month);
                if (fireDateWhere) result.push(fireDateWhere);
            }

            addFirePresentFilter(result, filter);
            break;

        case "map":
            addBaseFilters(result, filter);
            addDistrictFilter(result, filter);

            if (filter.month) {
                const fireDateWhere = buildFireDateWhere(filter.month, filter.day || undefined);
                if (fireDateWhere) result.push(fireDateWhere);
            }

            addFirePresentFilter(result, filter);
            break;

        default:
            break;
    }

    return result.join(" AND ");
};