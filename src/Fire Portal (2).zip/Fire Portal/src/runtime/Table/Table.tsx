import { React } from "jimu-core"
import FeatureLayer from "@arcgis/core/layers/FeatureLayer"
import Query from "@arcgis/core/rest/support/Query"
import CustomScroll from "../CustomScroll"
import {
    filterStruct,
    buildWhereQuery
} from "../../assets/config"
import { Translations, LangKey } from "../../assets/translations"
import { ArrowIcon } from "../../assets/icons"
import { Theme, ThemeKey } from "../../assets/theme"
import "./Table.css"

interface TableProps {
    getTheme: ThemeKey
    getLang: LangKey
    getFilter: filterStruct
    getSelected: string | null
    setSelected: (value: string | null) => void
    getTotal: number
    mainLayerRef: React.MutableRefObject<FeatureLayer>
}

interface pageInfo {
    page: number
    count: number
}

type TableRow = {
    rn: number
    uniqueid: string
    region_id: string
    distric_id: string
    fire_date: string
    areaha: number
    fire_present: string
    mfy_id?: string
}


function parseFireDateTime(value: any): number {
    if (value === null || value === undefined || value === "") return 0

    if (typeof value === "number") {
        return value < 100000000000 ? value * 1000 : value
    }

    const raw = String(value).trim()
    if (!raw) return 0

    if (/^\d+$/.test(raw)) {
        const num = Number(raw)
        return num < 100000000000 ? num * 1000 : num
    }

    // Основной формат слоя: день/месяц/год
    // Примеры: 29/10/2026, 29.10.2026, 29-10-2026, 29/10/2026 14:30:00
    const dmy = raw.match(/^(\d{1,2})[./-](\d{1,2})[./-](\d{4})(?:[ T](\d{1,2}):(\d{1,2})(?::(\d{1,2}))?)?/)
    if (dmy) {
        const day = Number(dmy[1])
        const month = Number(dmy[2])
        const year = Number(dmy[3])
        const hour = Number(dmy[4] ?? 0)
        const minute = Number(dmy[5] ?? 0)
        const second = Number(dmy[6] ?? 0)
        const time = new Date(year, month - 1, day, hour, minute, second).getTime()
        return Number.isFinite(time) ? time : 0
    }

    // Запасной вариант: год/месяц/день
    // Примеры: 2026-10-29, 2026/10/29 14:30:00
    const ymd = raw.match(/^(\d{4})[./-](\d{1,2})[./-](\d{1,2})(?:[ T](\d{1,2}):(\d{1,2})(?::(\d{1,2}))?)?/)
    if (ymd) {
        const year = Number(ymd[1])
        const month = Number(ymd[2])
        const day = Number(ymd[3])
        const hour = Number(ymd[4] ?? 0)
        const minute = Number(ymd[5] ?? 0)
        const second = Number(ymd[6] ?? 0)
        const time = new Date(year, month - 1, day, hour, minute, second).getTime()
        return Number.isFinite(time) ? time : 0
    }

    const parsed = new Date(raw).getTime()
    return Number.isFinite(parsed) ? parsed : 0
}

function compareFireDateDMY(a: any, b: any): number {
    const ta = parseFireDateTime(a)
    const tb = parseFireDateTime(b)

    if (ta && tb) return ta - tb
    if (ta) return -1
    if (tb) return 1

    return String(a ?? "").localeCompare(String(b ?? ""))
}

function pickExistingField(layer: FeatureLayer, candidates: string[]): string | null {
    const layerFields = (layer.fields ?? []).map((field) => String(field.name))
    for (const candidate of candidates) {
        if (layerFields.includes(candidate)) return candidate
    }
    return null
}

export default function Table({
    getTheme,
    getLang,
    getFilter,
    getSelected,
    setSelected,
    getTotal,
    mainLayerRef
}: TableProps) {
    const [getSortInfo, setSortInfo] = React.useState({
        name: "",
        dir: ""
    })
    const [isLong, setLong] = React.useState(false)
    const [getTableData, setTableData] = React.useState<TableRow[]>([])
    const [getPaginationInfo, setPaginationInfo] = React.useState<pageInfo>({
        page: 1,
        count: 100
    })

    const [inputPage, setInputPage] = React.useState<string>("1")
    const [realTotal, setRealTotal] = React.useState<number>(getTotal || 0)

    const MIN_PAGE = 1
    const PAGE_WINDOW = 5
    const MAX_PAGE = Math.max(1, Math.ceil(realTotal / getPaginationInfo.count))
    const clampPage = (value: number) => Math.max(MIN_PAGE, Math.min(MAX_PAGE, value))

    React.useEffect(() => {
        setPaginationInfo((prev: pageInfo) => ({
            ...prev,
            page: 1
        }))
        setInputPage("1")
    }, [getFilter])

    React.useEffect(() => {
        let cancelled = false

            ; (async () => {
                const layer = mainLayerRef?.current
                if (!layer) return

                try {
                    await layer.load()

                    const where = buildWhereQuery(getFilter, "map")

                    const countQuery = layer.createQuery()
                    countQuery.where = where
                    countQuery.returnGeometry = false

                    const totalCount = await layer.queryFeatureCount(countQuery)
                    if (cancelled) return

                    setRealTotal(totalCount)

                    const safePage = Math.max(1, Math.min(getPaginationInfo.page, Math.max(1, Math.ceil(totalCount / getPaginationInfo.count))))
                    if (safePage !== getPaginationInfo.page) {
                        setPaginationInfo((prev) => ({
                            ...prev,
                            page: safePage
                        }))
                        setInputPage(String(safePage))
                        return
                    }

                    const uniqueIdField = pickExistingField(layer, ["uniqueid"])
                    const regionField = pickExistingField(layer, ["region_id", "region"])
                    const districtField = pickExistingField(layer, ["distric_id", "district"])
                    const dateField = pickExistingField(layer, ["fire_date", "date", "detected_date"])
                    const areaField = pickExistingField(layer, ["areaha"])
                    const statusField = pickExistingField(layer, ["fire_present"])
                    const mfyField = pickExistingField(layer, ["mfy_id"])

                    if (!uniqueIdField || !regionField || !districtField || !dateField || !areaField || !statusField) {
                        console.error("[Table] required fields not found:", {
                            uniqueIdField,
                            regionField,
                            districtField,
                            dateField,
                            areaField,
                            statusField,
                            mfyField,
                            fields: (layer.fields ?? []).map((f) => f.name)
                        })
                        setTableData([])
                        return
                    }

                    const outFields = [
                        uniqueIdField,
                        regionField,
                        districtField,
                        dateField,
                        areaField,
                        statusField,
                        ...(mfyField ? [mfyField] : [])
                    ]

                    const pageSize = layer.capabilities?.query?.maxRecordCount ?? 2000
                    const totalPagesForData = Math.max(1, Math.ceil(totalCount / pageSize))

                    const loadedPages = await Promise.all(
                        Array.from({ length: totalPagesForData }, async (_, pageIndex) => {
                            const query = new Query({
                                where,
                                outFields,
                                returnGeometry: false,
                                num: pageSize,
                                start: pageIndex * pageSize
                            })

                            const result = await layer.queryFeatures(query)

                            return (result.features ?? []).map((feature: any) => {
                                const attrs = feature.attributes ?? {}
                                const rawStatus = attrs[statusField]
                                const firePresent = rawStatus === null || rawStatus === undefined
                                    ? "0"
                                    : (rawStatus === true || rawStatus === 1 || rawStatus === "true" || rawStatus === "1")
                                        ? "1"
                                        : "2"

                                return {
                                    rn: 0,
                                    uniqueid: String(attrs[uniqueIdField] ?? ""),
                                    region_id: String(attrs[regionField] ?? ""),
                                    distric_id: String(attrs[districtField] ?? ""),
                                    fire_date: String(attrs[dateField] ?? ""),
                                    areaha: Number(attrs[areaField] ?? 0),
                                    fire_present: firePresent,
                                    mfy_id: mfyField ? String(attrs[mfyField] ?? "") : ""
                                } as TableRow
                            })
                        })
                    )

                    if (cancelled) return

                    const sortedRows = loadedPages
                        .flat()
                        .sort((a, b) => {
                            const dir = getSortInfo.name === "fire_date"
                                ? (getSortInfo.dir || "ASC")
                                : "DESC"
                            const result = compareFireDateDMY(a.fire_date, b.fire_date)
                            return dir === "DESC" ? -result : result
                        })

                    const startIndex = (safePage - 1) * getPaginationInfo.count
                    const rows = sortedRows
                        .slice(startIndex, startIndex + getPaginationInfo.count)
                        .map((row, index) => ({
                            ...row,
                            rn: startIndex + index + 1
                        }))

                    setTableData(rows)
                    setInputPage(String(safePage))
                } catch (error) {
                    console.error("[Table] query error:", error)
                    if (!cancelled) {
                        setTableData([])
                    }
                }
            })()

        return () => {
            cancelled = true
        }
    }, [getPaginationInfo, getFilter, getSortInfo, mainLayerRef])

    React.useEffect(() => {
        setRealTotal(getTotal || 0)
    }, [getTotal])

    const statusContent = React.useCallback((value: "0" | "1" | "2" | "3") => {
        const PULSE_COUNT = 3;
        let color = ""
        switch (value) {
            case "0": color = Theme[getTheme]["--in-process"]; break
            case "1": color = Theme[getTheme]["--confirmed-color"]; break
            case "2": color = Theme[getTheme]["--no-confirmed-color"]; break
            case "3": color = Theme[getTheme]["--checked-color"]; break
            default: color = Theme[getTheme]["--in-process"]
        }

        return (
            <div className={`cellCenter ${"active"}`}>
                <div className={`statusAnimationBlock ${isLong && "left"}`}>
                    <div className="statusAnimationLayer1"
                        style={{
                            animation: `pulse 2000ms ${PULSE_COUNT}`,
                            animationDelay: "0",
                            backgroundImage:
                                `radial-gradient(circle at center, transparent 50%, rgb(var(--confirmed-color)) 55%, transparent)`
                        }}
                    />
                    <div className="statusAnimationLayer2"
                        style={{ animationDelay: "0", backgroundColor: `rgb(var(--confirmed-color))` }}
                    />
                </div>

                <div className="statusAnimationBlock" style={{ opacity: "1" }}>
                    <div className="statusAnimationLayer1"
                        style={{
                            animation: `pulse 2000ms ${PULSE_COUNT}`,
                            animationDelay: "150ms",
                            backgroundImage:
                                `radial-gradient(circle at center, transparent 50%, rgb(${color}) 55%, transparent)`
                        }}
                    />
                    <div className="statusAnimationLayer2"
                        style={{ animationDelay: "150ms", backgroundColor: `rgb(${color})` }}
                    />
                </div>

                <div className={`statusAnimationBlock ${isLong && "right"}`}>
                    <div className="statusAnimationLayer1"
                        style={{
                            animation: `${value === "2" && `pulse 2000ms ${PULSE_COUNT}`}`,
                            animationDelay: "300ms",
                            backgroundImage:
                                `radial-gradient(circle at center, transparent 50%, rgba(var(--in-process), ${value !== "2" ? 0.3 : 1}) 55%, transparent)`
                        }}
                    />
                    <div className="statusAnimationLayer2"
                        style={{
                            animation: `${value === "2" && `scaleAnim 2000ms ${PULSE_COUNT}`}`,
                            animationDelay: "300ms",
                            backgroundColor: `rgba(var(--in-process), ${value !== "2" ? 0.5 : 1})`,
                            backdropFilter: "blur(24px)"
                        }}
                    />
                </div>

                <div
                    className={`gradientLine ${isLong && "long"}`}
                    style={{
                        background:
                            `linear-gradient(90deg, rgb(var(--confirmed-color)), rgb(${color}), rgba(var(--in-process), ${value !== "2" ? 0.3 : 1}))`
                    }}
                />
            </div>
        )
    }, [isLong, getTheme])

    const goToPage = (page: number) => {
        setPaginationInfo((prev: pageInfo) => ({
            ...prev,
            page: clampPage(page)
        }))
    }

    const renderPages = () => {
        const pages = []
        const half = Math.floor(PAGE_WINDOW / 2)

        for (let index = -half; index <= half; index++) {
            const page = getPaginationInfo.page + index
            if (page < MIN_PAGE || page > MAX_PAGE) {
                pages.push(<div className="btn disable" key={index}>-</div>)
                continue
            }

            if (index === 0) {
                pages.push(
                    <input
                        key="input"
                        className="paginationInput"
                        type="text"
                        value={inputPage}
                        onChange={(e) => {
                            const value = e.target.value
                            if (/^\d*$/.test(value)) setInputPage(value)
                        }}
                        onKeyDown={(e) => {
                            if (e.key === "Enter") {
                                if (inputPage === "") {
                                    goToPage(MIN_PAGE)
                                    return
                                }
                                goToPage(Number(inputPage))
                            }
                        }}
                    />
                )
                continue
            }

            pages.push(
                <div
                    key={index}
                    className="btn"
                    onClick={() => goToPage(page)}
                >
                    {page}
                </div>
            )
        }

        return pages
    }
    return (
        <div className="tableArea">
            <CustomScroll style={{ borderRadius: "5px", flex: 1, minHeight: 0, border: "1px solid hsla(var(--main-color-hsl), 30%, 0.7)" }}>
                <table className={`tableMain ${isLong && "long"}`}>
                    <colgroup>
                        <col style={{ width: 50 }} />
                        <col style={{ width: "auto" }} />
                        <col style={{ width: isLong ? 0 : 200 }} />
                        <col style={{ width: 120 }} />
                        <col style={{ width: isLong ? 0 : 120 }} />
                        <col style={{ width: isLong ? 440 : 120 }} />
                    </colgroup>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>{Translations[isLong ? "manzil" : "uniqueid"][getLang]}</th>
                            <th>{getLang === "UZ" ? "Viloyat / hudud" : getLang === "RU" ? "Регион / район" : "Region / district"}</th>
                            <th>
                                <div
                                    style={{
                                        position: "relative",
                                        width: "100%",
                                        height: "100%",
                                        display: "flex",
                                        alignItems: "center",
                                        justifyContent: "center"
                                    }}
                                    onClick={() => {
                                        if (getSortInfo.name === "") {
                                            setSortInfo({
                                                name: "fire_date",
                                                dir: "ASC"
                                            })
                                            return
                                        }
                                        if (getSortInfo.dir === "ASC") {
                                            setSortInfo({
                                                name: "fire_date",
                                                dir: "DESC"
                                            })
                                            return
                                        }
                                        if (getSortInfo.dir === "DESC") {
                                            setSortInfo({
                                                name: "",
                                                dir: ""
                                            })
                                        }
                                    }}
                                >
                                    {Translations["sana"][getLang]}
                                    <div
                                        className="arrowTop"
                                        style={{ opacity: `${getSortInfo.dir === "ASC" ? "1" : "0.4"}` }}
                                    >
                                        <ArrowIcon size="12px" color={`rgb(${Theme[getTheme]["--color"]})`} />
                                    </div>
                                    <div
                                        className="arrowBottom"
                                        style={{ opacity: `${getSortInfo.dir === "DESC" ? "1" : "0.4"}` }}
                                    >
                                        <ArrowIcon size="12px" color={`rgb(${Theme[getTheme]["--color"]})`} />
                                    </div>
                                </div>
                            </th>
                            <th>{Translations["area"][getLang]}, (ga)</th>
                            <th onClick={() => setLong(!isLong)}>
                                <div className={`cellCenter ${"active"}`}>
                                    <div className={`statusAnimationBlock ${isLong && "left"}`}>
                                        UZCOSMOS
                                    </div>
                                    <div className="statusAnimationBlock" style={{ opacity: "1" }}>
                                        {isLong ? "EKOLOGIYA" : Translations["status"][getLang]}
                                    </div>
                                    <div className={`statusAnimationBlock ${isLong && "right"}`}>
                                        PROKURATURA
                                    </div>
                                </div>
                            </th>
                        </tr>
                    </thead>

                    <tbody>
                        {getTableData.map((item: TableRow, index: number) => {
                            const id = item.uniqueid
                            return (
                                <tr
                                    key={index}
                                    className={getSelected === id ? "active" : ""}
                                    onClick={() => {
                                        if (id === getSelected) setSelected(null)
                                        else setSelected(id)
                                    }}
                                >
                                    <td>{item.rn}</td>
                                    <td>{isLong ? (Translations[item.mfy_id][getLang] || id) : id}</td>
                                    <td>
                                        <div className="tableLocationCell">
                                            <div className="tableRegionName">
                                                {Translations[item.region_id as LangKey]?.[getLang] ?? item.region_id}
                                            </div>
                                            <div className="tableDistrictName">
                                                {Translations[item.distric_id as LangKey]?.[getLang] ?? item.distric_id}
                                            </div>
                                        </div>
                                    </td>
                                    <td>{item.fire_date}</td>
                                    <td>{Number.isFinite(item.areaha) ? item.areaha.toFixed(4) : "0.0000"}</td>
                                    <td>{statusContent(item.fire_present as "0" | "1" | "2" | "3")}</td>
                                </tr>
                            )
                        })}
                    </tbody>
                </table>
            </CustomScroll>

            <div className="tablePagination">
                <div className="pageInfo">
                    {Translations["page"][getLang]} {getPaginationInfo.page} / {MAX_PAGE}
                </div>
                <div className="paginationBtns">
                    <div
                        className={`btn ${getPaginationInfo.page === 1 ? "disable" : ""}`}
                        onClick={() => goToPage(MIN_PAGE)}
                    >
                        ⏮
                    </div>
                    <div
                        className={`btn ${getPaginationInfo.page === 1 ? "disable" : ""}`}
                        onClick={() => goToPage(getPaginationInfo.page - 3)}
                    >
                        ◀
                    </div>
                    {renderPages()}
                    <div
                        className={`btn ${getPaginationInfo.page === MAX_PAGE ? "disable" : ""}`}
                        onClick={() => goToPage(getPaginationInfo.page + 3)}
                    >
                        ▶
                    </div>
                    <div
                        className={`btn ${getPaginationInfo.page === MAX_PAGE ? "disable" : ""}`}
                        onClick={() => goToPage(MAX_PAGE)}
                    >
                        ⏭
                    </div>
                </div>
            </div>
        </div>
    )
}