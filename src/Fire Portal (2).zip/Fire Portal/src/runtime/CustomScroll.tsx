import { React } from "jimu-core"

interface CustomScrollProps {
    children: React.ReactNode
    className?: string
    style?: React.CSSProperties
}

export default function CustomScroll({ children, className = "", style = {} }: CustomScrollProps) {
    const containerRef = React.useRef<HTMLDivElement>(null)
    const vThumbRef = React.useRef<HTMLDivElement>(null)

    const [showTrack, setShowTrack] = React.useState(false)

    const vDragging = React.useRef(false)
    const dragStartY = React.useRef(0)
    const dragStartScrollTop = React.useRef(0)

    const updateThumb = React.useCallback(() => {
        const c = containerRef.current
        const vt = vThumbRef.current
        if (!c) return

        const needScroll = c.scrollHeight > c.clientHeight
        setShowTrack(needScroll)

        if (!vt || !needScroll) return

        const ratio = c.clientHeight / c.scrollHeight
        const thumbH = Math.max(ratio * c.clientHeight, 28)

        const maxScroll = c.scrollHeight - c.clientHeight
        const scrollRatio = maxScroll > 0 ? c.scrollTop / maxScroll : 0
        const maxThumbTop = c.clientHeight - thumbH

        vt.style.height = `${thumbH}px`
        vt.style.top = `${scrollRatio * maxThumbTop}px`
    }, [])

    React.useEffect(() => {
        const c = containerRef.current
        if (!c) return

        c.addEventListener("scroll", updateThumb, { passive: true })

        const ro = new ResizeObserver(updateThumb)
        ro.observe(c)

        const mo = new MutationObserver(updateThumb)
        mo.observe(c, { childList: true, subtree: true })

        updateThumb()

        return () => {
            c.removeEventListener("scroll", updateThumb)
            ro.disconnect()
            mo.disconnect()
        }
    }, [updateThumb])

    React.useEffect(() => {
        if (showTrack) {
            requestAnimationFrame(updateThumb)
        }
    }, [showTrack, updateThumb])

    const onVMouseDown = (e: React.MouseEvent) => {
        e.preventDefault()
        vDragging.current = true
        dragStartY.current = e.clientY
        dragStartScrollTop.current = containerRef.current?.scrollTop ?? 0

        const onMove = (ev: MouseEvent) => {
            if (!vDragging.current || !containerRef.current) return
            const c = containerRef.current
            const vt = vThumbRef.current
            if (!vt) return

            const maxThumbTop = c.clientHeight - vt.offsetHeight
            const maxScroll = c.scrollHeight - c.clientHeight
            const delta = ev.clientY - dragStartY.current

            c.scrollTop = dragStartScrollTop.current + delta * (maxScroll / maxThumbTop)
        }

        const onUp = () => {
            vDragging.current = false
            window.removeEventListener("mousemove", onMove)
            window.removeEventListener("mouseup", onUp)
        }

        window.addEventListener("mousemove", onMove)
        window.addEventListener("mouseup", onUp)
    }

    return (
        <div
            style={{
                position: "relative",
                overflow: "hidden",
                ...style
            }}
            className={className}
        >
            <style>{`.customScrollHide::-webkit-scrollbar{display:none}`}</style>

            <div
                ref={containerRef}
                className="customScrollHide"
                style={{
                    width: "100%",
                    height: "100%",
                    overflowY: "scroll",
                    overflowX: "hidden",
                    scrollbarWidth: "none",
                    msOverflowStyle: "none",
                }}
            >
                {children}
            </div>

            {showTrack && (
                <div style={{
                    position: "absolute",
                    top: 4,
                    bottom: 4,
                    right: 3,
                    width: 5,
                    borderRadius: 10,
                    background: "rgba(255,255,255,0.07)",
                    zIndex: 200,
                }}>
                    <div
                        ref={vThumbRef}
                        onMouseDown={onVMouseDown}
                        onMouseEnter={e => {
                            e.currentTarget.style.background = "rgba(var(--active-color), 0.9)"
                        }}
                        onMouseLeave={e => {
                            e.currentTarget.style.background = "rgba(var(--active-color), 0.5)"
                        }}
                        style={{
                            position: "absolute",
                            left: 0,
                            right: 0,
                            borderRadius: 10,
                            background: "rgba(var(--active-color), 0.5)",
                            cursor: "pointer",
                            transition: "background 0.15s",
                        }}
                    />
                </div>
            )}
        </div>
    )
}