/** @jsx jsx */
import { React, jsx } from "jimu-core";
import "./CustomMap.css";

import ArcGISMap from "@arcgis/core/Map";
import MapView from "@arcgis/core/views/MapView";
import FeatureLayer from "@arcgis/core/layers/FeatureLayer";
import GraphicsLayer from "@arcgis/core/layers/GraphicsLayer";
import ImageryLayer from "@arcgis/core/layers/ImageryLayer";
import Graphic from "@arcgis/core/Graphic";
import SketchViewModel from "@arcgis/core/widgets/Sketch/SketchViewModel";
import Polyline from "@arcgis/core/geometry/Polyline";
import geometryEngine from "@arcgis/core/geometry/geometryEngine";
import * as webMercatorUtils from "@arcgis/core/geometry/support/webMercatorUtils";
import FeatureFilter from "@arcgis/core/layers/support/FeatureFilter";
import FeatureEffect from "@arcgis/core/layers/support/FeatureEffect";

import Popup from "../Popup/Popup";

import {
    uniqueIdField,
    selectedPolyStruct,
    filterStruct,
    buildWhereQuery,
    escapeSqlString
} from "../../assets/config";
import { LangKey, Translations } from "../../assets/translations";
import { Theme, ThemeKey } from "../../assets/theme";
import { RulerIcon, MinusIcon, PlusIcon, LocationIcon, LayersIcon } from "../../assets/icons";

interface MapLayerItem {
    id: string;
    titleKey: string;
    fallbackTitle: string;
}

interface CustomMapProps {
    getTheme: ThemeKey;
    getLang: LangKey;
    getFilter: filterStruct;
    getSelected: selectedPolyStruct;
    setSelected: (value: selectedPolyStruct | ((prev: selectedPolyStruct) => selectedPolyStruct)) => void;
    mainLayerRef: React.MutableRefObject<FeatureLayer>;
    regionLayerRef: React.MutableRefObject<FeatureLayer>;
    districtLayerRef: React.MutableRefObject<FeatureLayer>;
    setMap: (value: MapView | null) => void;
}

const HOME_CENTER: [number, number] = [65.361894, 41.809956];
const HOME_ZOOM = 6;

const SAFE_MAIN_LAYER_FIELDS = [
    "objectid",
    "uniqueid",
    "coordinate",
    "region",
    "district",
    "mfy",
    "fire_date",
    "year",
    "areaha",
    "region_id",
    "distric_id",
    "mfy_id",
    "type_id",
    "search_id",
    "link",
    "raster",
    "inspection_id",
    "inspector_id",
    "inspector_name",
    "inspection_date",
    "inspection_result",
    "fire_present",
    "notes",
    "photo_paths",
    "photo_uploaded",
    "court_decision_uploaded",
    "damage_amount",
    "fine_amount",
    "dalolatnoma_path",
    "sud_qarori_path",
    "inspection_created_at",
    "inspection_updated_at",
    "inspection_uniqueid"
];

const getExistingSafeFields = (layer: FeatureLayer): string[] => {
    const existingFields = new Set((layer.fields ?? []).map((field: any) => String(field.name)));
    const fields = SAFE_MAIN_LAYER_FIELDS.filter((field) => existingFields.has(field));

    return fields.length > 0 ? fields : [uniqueIdField];
};

const RASTER_LAYERS = [
    {
        id: "republic_maxar_2024",
        title: "Maxar 2024",
        titleKey: "layerRasterMaxar2024",
        url: "https://sgm.uzspace.uz/image/rest/services/AdminRaster/republic_maxar_2024_year/ImageServer",
        visible: false,
    },
    {
        id: "republic_maxar_2025_1",
        title: "Maxar 2025 / 1-monitoring",
        titleKey: "layerRasterMaxar2025First",
        url: "https://sgm.uzspace.uz/image/rest/services/AdminRaster/republic_maxar_2025_year_1_monitoring/ImageServer",
        visible: false,
    },
    {
        id: "republic_maxar_2025_2",
        title: "Maxar 2025 / 2-monitoring",
        titleKey: "layerRasterMaxar2025Second",
        url: "https://sgm.uzspace.uz/image/rest/services/AdminRaster/republic_maxar_2025_year_2_monitoring/ImageServer",
        visible: false,
    },
    {
        id: "republic_maxar_2026_1",
        title: "Maxar 2026 / 1-monitoring",
        titleKey: "layerRasterMaxar2026First",
        url: "https://sgm.uzspace.uz/image/rest/services/AdminRaster/republic_maxar_2026_year_1_monitoring/ImageServer",
        visible: false,
    },
];


const DEFAULT_LAYER_VISIBILITY: Record<string, boolean> = {
    regionLayer: false,
    districtLayer: true,
    mainLayer: true,
};

const REGION_LABEL_FIELD = "viloyat_uz";
const DISTRICT_LABEL_FIELD = "tuman_nomi";

const hasLayerField = (layer: FeatureLayer, fieldName: string): boolean => {
    const lowerFieldName = fieldName.toLowerCase();

    return (layer.fields ?? []).some((field: any) => (
        String(field.name).toLowerCase() === lowerFieldName
    ));
};

const applyBoundaryCenterLabels = (
    layer: FeatureLayer,
    labelField: string,
    layerName: "region" | "district"
): void => {
    if (!hasLayerField(layer, labelField)) {
        console.warn(`[CustomMap] ${layerName} label field not found: ${labelField}`);
        return;
    }

    layer.outFields = [labelField];
    layer.labelsVisible = true;
    layer.labelingInfo = [
        {
            labelExpressionInfo: {
                expression: `return DefaultValue($feature["${labelField}"], "");`,
            },
            labelPlacement: "always-horizontal",
            symbol: {
                type: "text",
                color: [255, 255, 255, 1],
                haloColor: [0, 0, 0, 0.85],
                haloSize: 1.5,
                font: {
                    family: "Arial",
                    size: layerName === "region" ? 13 : 11,
                    weight: "bold",
                },
            },
            minScale: layerName === "region" ? 6000000 : 3000000,
            maxScale: 0,
        } as any,
    ] as any;
};

function getInitialLayerVisibility(): Record<string, boolean> {
    const result: Record<string, boolean> = { ...DEFAULT_LAYER_VISIBILITY };

    RASTER_LAYERS.forEach((layer) => {
        result[layer.id] = Boolean(layer.visible);
    });

    return result;
}

const LAYER_TITLE_KEYS: Record<string, string> = {
    republic_maxar_2024: "layerRasterMaxar2024",
    republic_maxar_2025_1: "layerRasterMaxar2025First",
    republic_maxar_2025_2: "layerRasterMaxar2025Second",
    republic_maxar_2026_1: "layerRasterMaxar2026First",
    regionLayer: "layerRegions",
    districtLayer: "layerDistricts",
    mainLayer: "layerFireObjects",
};

function getLayerTitleKey(layerId: string): string {
    return LAYER_TITLE_KEYS[layerId] ?? layerId;
}

function getLayerFallbackTitle(layer: any): string {
    return String(layer?.title || layer?.id || "Layer");
}

function formatDistance(meters: number): string {
    if (!isFinite(meters)) return "";
    if (meters < 1000) return `${meters.toFixed(0)} м`;
    return `${(meters / 1000).toFixed(2)} км`;
}

function rgb(value: string): string {
    return `rgb(${value})`;
}

export default function CustomMap({
    getTheme,
    getLang,
    getFilter,
    getSelected,
    setSelected,
    mainLayerRef,
    regionLayerRef,
    districtLayerRef,
    setMap,
}: CustomMapProps) {
    const [getFocus, setFocus] = React.useState<"home" | "plus" | "minus" | "ruler" | "layer" | null>(null);
    const [getPolyInfo, setPolyInfo] = React.useState<Record<string, any> | null>(null);
    const [getActive, setActive] = React.useState<string>("");
    const [getMapLayers, setMapLayers] = React.useState<MapLayerItem[]>([]);
    const [getLayerVisibility, setLayerVisibility] = React.useState<Record<string, boolean>>(() => getInitialLayerVisibility());

    const mapDivRef = React.useRef<HTMLDivElement | null>(null);
    const viewRef = React.useRef<MapView | null>(null);
    const mapRef = React.useRef<ArcGISMap | null>(null);

    const highlightLayerRef = React.useRef<GraphicsLayer | null>(null);
    const rulerLayerRef = React.useRef<GraphicsLayer | null>(null);
    const rulerLabelLayerRef = React.useRef<GraphicsLayer | null>(null);
    const sketchRef = React.useRef<SketchViewModel | null>(null);
    const mainLayerViewRef = React.useRef<any>(null);
    const rasterLayerRefs = React.useRef<Record<string, ImageryLayer>>({});

    const selectedRef = React.useRef<string>(getSelected?.[uniqueIdField] ?? "");
    const rulerActiveRef = React.useRef<boolean>(false);
    const layerVisibilityRef = React.useRef<Record<string, boolean>>(getLayerVisibility);
    const isMountedRef = React.useRef<boolean>(false);

    const themeVars = Theme[getTheme];

    React.useEffect(() => {
        isMountedRef.current = true;
        return () => {
            isMountedRef.current = false;
        };
    }, []);

    React.useEffect(() => {
        selectedRef.current = getSelected?.[uniqueIdField] ?? "";
    }, [getSelected]);

    React.useEffect(() => {
        rulerActiveRef.current = getActive === "ruler";
    }, [getActive]);

    React.useEffect(() => {
        layerVisibilityRef.current = getLayerVisibility;

        const map = mapRef.current;
        if (!map) return;

        Object.entries(getLayerVisibility).forEach(([id, visible]) => {
            const layer = map.findLayerById(id) as any;
            if (layer && !layer.destroyed) {
                layer.visible = Boolean(visible);
            }
        });
    }, [getLayerVisibility]);

    const toggleMapLayer = React.useCallback((id: string) => {
        setLayerVisibility((prev) => {
            const nextValue = !Boolean(prev[id]);

            const layer = mapRef.current?.findLayerById(id) as any;
            if (layer && !layer.destroyed) {
                layer.visible = nextValue;
            }

            return {
                ...prev,
                [id]: nextValue,
            };
        });
    }, []);

    const updateSelected = React.useCallback((nextId: string) => {
        setSelected((prev) => {
            const currentId = prev?.[uniqueIdField] ?? "";
            const normalizedNextId = nextId ?? "";

            if (currentId === normalizedNextId) {
                return prev;
            }

            return {
                [uniqueIdField]: normalizedNextId
            } as selectedPolyStruct;
        });
    }, [setSelected]);

    const polygonHighlightSymbol = React.useMemo(() => {
        return {
            type: "simple-fill" as const,
            color: [...themeVars["--active-color"].split(",").map((v) => Number(v.trim())), 0.18],
            outline: {
                type: "simple-line" as const,
                color: [...themeVars["--active-color"].split(",").map((v) => Number(v.trim())), 1],
                width: 3,
            },
        };
    }, [themeVars]);

    const rulerLineSymbol = React.useMemo(() => {
        return {
            type: "simple-line" as const,
            color: [...themeVars["--active-color"].split(",").map((v) => Number(v.trim())), 1],
            width: 2.5,
        };
    }, [themeVars]);

    const labelSymbol = React.useCallback((text: string) => {
        return {
            type: "text" as const,
            text,
            color: rgb(themeVars["--color"]),
            haloColor: rgb(themeVars["--area-bg"]),
            haloSize: 2,
            font: {
                size: 12,
                family: "sans-serif",
                weight: "bold",
            },
            yoffset: -10,
        };
    }, [themeVars]);

    const clearSelection = React.useCallback(() => {
        highlightLayerRef.current?.removeAll();
        setPolyInfo(null);
        updateSelected("");
    }, [updateSelected]);

    const clearRuler = React.useCallback(() => {
        try {
            sketchRef.current?.cancel();
        } catch (error) {
            console.error("[CustomMap] sketch cancel error:", error);
        }

        rulerLayerRef.current?.removeAll();
        rulerLabelLayerRef.current?.removeAll();
    }, []);

    const rebuildRulerLabels = React.useCallback((geometry: Polyline | null) => {
        const labelLayer = rulerLabelLayerRef.current;
        if (!labelLayer || !geometry) return;

        labelLayer.removeAll();

        const path = geometry.paths?.[0];
        if (!path || path.length < 2) return;

        for (let i = 1; i < path.length; i++) {
            const line = new Polyline({
                paths: [[path[i - 1], path[i]]],
                spatialReference: geometry.spatialReference,
            });

            const geographicLine = webMercatorUtils.webMercatorToGeographic(line) as Polyline;
            const meters = geometryEngine.geodesicLength(geographicLine, "meters") ?? 0;

            const middleX = (path[i - 1][0] + path[i][0]) / 2;
            const middleY = (path[i - 1][1] + path[i][1]) / 2;

            labelLayer.add(new Graphic({
                geometry: {
                    type: "point",
                    x: middleX,
                    y: middleY,
                    spatialReference: geometry.spatialReference,
                } as any,
                symbol: labelSymbol(formatDistance(meters)),
            }));
        }
    }, [labelSymbol]);

    const applySelectionEffect = React.useCallback(() => {
        const layerView = mainLayerViewRef.current;
        const selectedId = selectedRef.current;

        if (!layerView || layerView.destroyed) return;

        if (!selectedId) {
            layerView.featureEffect = null;
            return;
        }

        const escapedId = escapeSqlString(String(selectedId));

        layerView.featureEffect = new FeatureEffect({
            filter: new FeatureFilter({
                where: `${uniqueIdField} = '${escapedId}'`
            }),
            includedEffect: "opacity(100%)",
            excludedEffect: "opacity(80%)"
        });
    }, []);

    const polygonHighlightSymbolRef = React.useRef<any>(polygonHighlightSymbol);
    const rulerLineSymbolRef = React.useRef<any>(rulerLineSymbol);
    const rebuildRulerLabelsRef = React.useRef<(geometry: Polyline | null) => void>(rebuildRulerLabels);
    const clearRulerRef = React.useRef<() => void>(clearRuler);
    const applySelectionEffectRef = React.useRef<() => void>(applySelectionEffect);

    React.useEffect(() => {
        polygonHighlightSymbolRef.current = polygonHighlightSymbol;
    }, [polygonHighlightSymbol]);

    React.useEffect(() => {
        rulerLineSymbolRef.current = rulerLineSymbol;

        if (sketchRef.current) {
            sketchRef.current.polylineSymbol = rulerLineSymbol as any;
        }

        if (rulerLayerRef.current) {
            rulerLayerRef.current.graphics.forEach((graphic: any) => {
                graphic.symbol = rulerLineSymbol as any;
            });
        }
    }, [rulerLineSymbol]);

    React.useEffect(() => {
        rebuildRulerLabelsRef.current = rebuildRulerLabels;
    }, [rebuildRulerLabels]);

    React.useEffect(() => {
        clearRulerRef.current = clearRuler;
    }, [clearRuler]);

    React.useEffect(() => {
        applySelectionEffectRef.current = applySelectionEffect;
    }, [applySelectionEffect]);

    React.useEffect(() => {
        if (highlightLayerRef.current) {
            highlightLayerRef.current.graphics.forEach((g: any) => {
                g.symbol = polygonHighlightSymbol as any;
            });
        }

        if (rulerLabelLayerRef.current) {
            rulerLabelLayerRef.current.graphics.forEach((g: any) => {
                const text = g.symbol?.text ?? "";
                g.symbol = labelSymbol(text) as any;
            });
        }
    }, [polygonHighlightSymbol, labelSymbol]);

    React.useEffect(() => {
        if (!mapDivRef.current || viewRef.current) return;

        const mainLayer = mainLayerRef.current;

        if (!mainLayer) {
            console.error("[CustomMap] mainLayerRef is empty");
            return;
        }

        mainLayer.id = "mainLayer";
        mainLayer.title = mainLayer.title || "Fire objects";
        mainLayer.visible = layerVisibilityRef.current.mainLayer ?? DEFAULT_LAYER_VISIBILITY.mainLayer;
        mainLayer.popupEnabled = false;
        mainLayer.outFields = SAFE_MAIN_LAYER_FIELDS;

        const regionLayer = regionLayerRef.current;
        regionLayer.id = "regionLayer";
        regionLayer.title = regionLayer.title || "Regions";
        regionLayer.visible = layerVisibilityRef.current.regionLayer ?? DEFAULT_LAYER_VISIBILITY.regionLayer;

        const districtLayer = districtLayerRef.current;
        districtLayer.id = "districtLayer";
        districtLayer.title = districtLayer.title || "Districts";
        districtLayer.visible = layerVisibilityRef.current.districtLayer ?? DEFAULT_LAYER_VISIBILITY.districtLayer;

        const highlightLayer = new GraphicsLayer({
            id: "fieldfire-highlight",
            listMode: "hide"
        });

        const rulerLayer = new GraphicsLayer({
            id: "fieldfire-ruler",
            listMode: "hide"
        });

        const rulerLabelLayer = new GraphicsLayer({
            id: "fieldfire-ruler-labels",
            listMode: "hide"
        });

        const rasterLayers = RASTER_LAYERS.map((item) => {
            return new ImageryLayer({
                id: item.id,
                title: item.title,
                url: item.url,
                visible: layerVisibilityRef.current[item.id] ?? Boolean(item.visible),
            });
        });

        rasterLayerRefs.current = rasterLayers.reduce((result, layer) => {
            result[layer.id] = layer;
            return result;
        }, {} as Record<string, ImageryLayer>);

        const map = new ArcGISMap({
            basemap: "hybrid",
            layers: [
                ...rasterLayers,
                regionLayer,
                districtLayer,
                mainLayer,
                highlightLayer,
                rulerLayer,
                rulerLabelLayer,
            ],
        });

        const refreshLayerItems = () => {
            const items: MapLayerItem[] = [];

            map.layers.forEach((layer: any) => {
                if (!layer || layer.listMode === "hide" || !layer.id) return;

                items.push({
                    id: layer.id,
                    titleKey: getLayerTitleKey(layer.id),
                    fallbackTitle: getLayerFallbackTitle(layer),
                });
            });

            setMapLayers(items);
            setLayerVisibility((prev) => {
                const next = { ...prev };

                items.forEach((item) => {
                    const layer = map.findLayerById(item.id) as any;
                    if (!layer || layer.destroyed) return;

                    if (next[item.id] == null) {
                        next[item.id] = Boolean(layer.visible);
                    } else {
                        layer.visible = Boolean(next[item.id]);
                    }
                });

                return next;
            });
        };

        refreshLayerItems();
        const layerChangeHandle = map.layers.on("change", refreshLayerItems);

        const view = new MapView({
            container: mapDivRef.current,
            map,
            center: HOME_CENTER,
            zoom: HOME_ZOOM,
            constraints: {
                minZoom: 5,
                maxZoom: 17,
            },
            ui: {
                components: [],
            },
            popup: {
                dockEnabled: false,
            },
        });

        view.popupEnabled = false;

        const sketch = new SketchViewModel({
            view,
            layer: rulerLayer,
            polylineSymbol: rulerLineSymbolRef.current as any,
            updateOnGraphicClick: false,
            defaultCreateOptions: {
                mode: "click",
            },
        });

        sketch.on("create", (event: any) => {
            if (event.state === "start") {
                rulerLabelLayer.removeAll();
            }

            if (event.graphic?.geometry?.type === "polyline") {
                rebuildRulerLabelsRef.current(event.graphic.geometry as Polyline);
            }

            if (event.state === "cancel") {
                clearRulerRef.current();
            }
        });

        view.on("click", async (event) => {
            if (rulerActiveRef.current) return;

            try {
                const hit = await view.hitTest(event);

                const result = hit.results.find((item: any) => {
                    return item.graphic?.layer === mainLayer;
                }) as any;

                if (!result?.graphic) {
                    updateSelected("");
                    return;
                }

                const attrs = result.graphic.attributes ?? {};
                const clickedId = attrs?.[uniqueIdField] != null
                    ? String(attrs[uniqueIdField])
                    : "";

                if (!clickedId) {
                    updateSelected("");
                    return;
                }

                if (clickedId === selectedRef.current) {
                    updateSelected("");
                    return;
                }

                updateSelected(clickedId);
            } catch (error) {
                console.error("[CustomMap] click/hitTest error:", error);
            }
        });

        viewRef.current = view;
        mapRef.current = map;
        highlightLayerRef.current = highlightLayer;
        rulerLayerRef.current = rulerLayer;
        rulerLabelLayerRef.current = rulerLabelLayer;
        sketchRef.current = sketch;

        setMap(view);

        view.when(async () => {
            if (!isMountedRef.current || view.destroyed) return;

            try {
                await mainLayer.load();
            } catch (error) {
                console.error("[CustomMap] layer load error:", error);
                return;
            }

            // Не блокируем старт виджета ожиданием слоёв границ.
            // Они догружаются отдельно, а основной слой и popup становятся доступными быстрее.
            void regionLayer.load().then(() => {
                if (!isMountedRef.current || view.destroyed || regionLayer.destroyed) return;
                applyBoundaryCenterLabels(regionLayer, REGION_LABEL_FIELD, "region");
            }).catch((error) => {
                console.warn("[CustomMap] region FeatureLayer load warning:", error);
            });

            void districtLayer.load().then(() => {
                if (!isMountedRef.current || view.destroyed || districtLayer.destroyed) return;
                applyBoundaryCenterLabels(districtLayer, DISTRICT_LABEL_FIELD, "district");
            }).catch((error) => {
                console.warn("[CustomMap] district FeatureLayer load warning:", error);
            });

            if (!isMountedRef.current || view.destroyed) return;

            if (mainLayer.destroyed) {
                console.error("[CustomMap] mainLayer is destroyed before layerview creation");
                return;
            }

            try {
                const mainLayerView = await view.whenLayerView(mainLayer);

                if (!isMountedRef.current || view.destroyed) return;

                mainLayerViewRef.current = mainLayerView;
                applySelectionEffectRef.current();
            } catch (error) {
                console.error("[CustomMap] layerview error:", error);
            }
        });

        return () => {
            setMap(null);

            try {
                layerChangeHandle?.remove();
            } catch (error) {
                console.error("[CustomMap] layer change handle remove error:", error);
            }

            try {
                clearRulerRef.current();
            } catch (error) {
                console.error("[CustomMap] cleanup clearRuler error:", error);
            }

            if (mainLayerViewRef.current && !mainLayerViewRef.current.destroyed) {
                try {
                    mainLayerViewRef.current.featureEffect = null;
                } catch (error) {
                    console.error("[CustomMap] cleanup featureEffect reset error:", error);
                }
            }

            mainLayerViewRef.current = null;

            if (sketchRef.current) {
                try {
                    sketchRef.current.destroy();
                } catch (error) {
                    console.error("[CustomMap] sketch destroy error:", error);
                }
            }
            sketchRef.current = null;

            try {
                map.removeAll();
            } catch (error) {
                console.error("[CustomMap] map removeAll error:", error);
            }

            try {
                view.destroy();
            } catch (error) {
                console.error("[CustomMap] view destroy error:", error);
            }

            viewRef.current = null;
            mapRef.current = null;
            highlightLayerRef.current = null;
            rulerLayerRef.current = null;
            rulerLabelLayerRef.current = null;
            rasterLayerRefs.current = {};
        };
    }, [mainLayerRef, regionLayerRef, districtLayerRef, setMap, updateSelected]);

    React.useEffect(() => {
        const mainLayer = mainLayerRef.current;
        if (!mainLayer || mainLayer.destroyed) return;

        const where = buildWhereQuery(getFilter, "map");
        mainLayer.definitionExpression = where;

        const selectedId = getSelected?.[uniqueIdField] ?? "";
        if (!selectedId) {
            return;
        }

        let cancelled = false;

        (async () => {
            try {
                const query = mainLayer.createQuery();
                query.where = `${where} AND ${uniqueIdField} = '${escapeSqlString(selectedId)}'`;
                query.returnGeometry = false;
                query.outFields = [uniqueIdField];
                query.num = 1;

                const result = await mainLayer.queryFeatures(query);
                if (cancelled) return;

                if (!result.features?.length) {
                    clearSelection();
                }
            } catch (error) {
                console.error("[CustomMap] filter validation error:", error);
            }
        })();

        return () => {
            cancelled = true;
        };
    }, [getFilter, getSelected, mainLayerRef, clearSelection]);

    React.useEffect(() => {
        if (getActive !== "ruler") {
            clearRuler();
            return;
        }

        clearSelection();

        try {
            sketchRef.current?.create("polyline");
        } catch (error) {
            console.error("[CustomMap] sketch create error:", error);
        }
    }, [getActive, clearRuler, clearSelection]);

    React.useEffect(() => {
        const view = viewRef.current;
        if (!view || view.destroyed || getActive !== "ruler") return;

        const container = view.container as HTMLDivElement | null;
        if (!container) return;

        const onContextMenu = (event: MouseEvent) => {
            event.preventDefault();
            event.stopPropagation();

            clearRuler();

            try {
                sketchRef.current?.create("polyline");
            } catch (error) {
                console.error("[CustomMap] recreate ruler after right click error:", error);
            }
        };

        const onPointerDown = (event: PointerEvent) => {
            if (event.button !== 2) return;

            event.preventDefault();
            event.stopPropagation();

            clearRuler();

            try {
                sketchRef.current?.create("polyline");
            } catch (error) {
                console.error("[CustomMap] recreate ruler after pointerdown error:", error);
            }
        };

        const onKeyDown = (event: KeyboardEvent) => {
            if (event.key === "Escape") {
                clearRuler();
                setActive("");
            }
        };

        container.addEventListener("contextmenu", onContextMenu);
        container.addEventListener("pointerdown", onPointerDown, true);
        window.addEventListener("keydown", onKeyDown);

        return () => {
            container.removeEventListener("contextmenu", onContextMenu);
            container.removeEventListener("pointerdown", onPointerDown, true);
            window.removeEventListener("keydown", onKeyDown);
        };
    }, [getActive, clearRuler]);

    React.useEffect(() => {
        applySelectionEffect();
    }, [getSelected, applySelectionEffect]);

    React.useEffect(() => {
        const view = viewRef.current;
        const layer = mainLayerRef.current;
        const highlightLayer = highlightLayerRef.current;

        if (!view || view.destroyed || !layer || layer.destroyed || !highlightLayer) return;

        const selectedId = getSelected?.[uniqueIdField] ?? "";

        if (!selectedId) {
            highlightLayer.removeAll();
            setPolyInfo(null);
            applySelectionEffect();
            return;
        }

        let cancelled = false;

        (async () => {
            try {
                const query = layer.createQuery();
                query.where = `${uniqueIdField} = '${escapeSqlString(selectedId)}'`;
                query.outFields = getExistingSafeFields(layer);
                query.returnGeometry = true;
                query.num = 1;

                const result = await layer.queryFeatures(query);
                if (cancelled) return;
                if (!isMountedRef.current || !viewRef.current || viewRef.current.destroyed) return;

                const feature = result.features?.[0];
                highlightLayer.removeAll();

                if (!feature) {
                    setPolyInfo(null);
                    applySelectionEffect();
                    return;
                }

                const graphic = new Graphic({
                    geometry: feature.geometry,
                    attributes: feature.attributes,
                    symbol: polygonHighlightSymbolRef.current as any,
                });

                setPolyInfo(feature.attributes);

                highlightLayer.add(graphic);
                applySelectionEffect();

                if (feature.geometry) {
                    try {
                        await view.goTo(
                            {
                                target: feature.geometry,
                            },
                            {
                                duration: 350,
                                maxZoom: 15,
                            }
                        );
                    } catch (error) {
                        console.error("[CustomMap] goTo error:", error);
                    }
                }
            } catch (error) {
                console.error("[CustomMap] highlight query error:", error);
                highlightLayer.removeAll();
                setPolyInfo(null);
                applySelectionEffect();
            }
        })();

        return () => {
            cancelled = true;
        };
    }, [getSelected, mainLayerRef, applySelectionEffect]);

    const onHome = () => {
        const view = viewRef.current;
        if (!view || view.destroyed) return;

        view.goTo({
            center: HOME_CENTER,
            zoom: HOME_ZOOM,
        }, {
            duration: 300,
        });
    };

    const onZoom = (delta: number) => {
        const view = viewRef.current;
        if (!view || view.destroyed) return;

        view.goTo({
            zoom: (view.zoom ?? HOME_ZOOM) + delta,
        }, {
            duration: 150,
        });
    };

    return (
        <div className="customMapArea">
            {getPolyInfo && (
                <Popup
                    key="popup"
                    getTheme={getTheme}
                    setSelected={setSelected as any}
                    getLang={getLang}
                    getPolyInfo={getPolyInfo}
                />
            )}

            <div className="customMapBlock" ref={mapDivRef} />

            <div className="customMapLayerControl">
                <div
                    className={`customMapBtn ${getActive === "layer" ? "active" : ""}`}
                    role="button"
                    onClick={() => setActive((prev: string) => prev !== "layer" ? "layer" : "")}
                    onMouseEnter={() => setFocus("layer")}
                    onMouseLeave={() => setFocus(null)}
                >
                    <LayersIcon
                        size="16px"
                        color={rgb(
                            themeVars[getActive === "layer" || getFocus === "layer" ? "--active-color" : "--color"]
                        )}
                    />
                </div>

                {getActive === "layer" && (
                    <div className="customMapLayerList">
                        <div className="customMapLayerTitle">
                            {Translations.mapLayersTitle?.[getLang] ?? "Map layers"}
                        </div>

                        <div className="customMapLayerItems">
                            {getMapLayers.map((item) => {
                                const checked = Boolean(getLayerVisibility[item.id]);
                                const title = Translations[item.titleKey]?.[getLang] ?? item.fallbackTitle;

                                return (
                                    <button
                                        type="button"
                                        className={`customMapLayerItem ${checked ? "active" : ""}`}
                                        key={item.id}
                                        onClick={() => toggleMapLayer(item.id)}
                                    >
                                        <span className="customMapLayerText">{title}</span>
                                        <span className="customMapLayerSwitch" aria-hidden="true">
                                            <span className="customMapLayerSwitchDot" />
                                        </span>
                                    </button>
                                );
                            })}
                        </div>
                    </div>
                )}
            </div>

            <div className="customMapBtns">
                <div
                    className="customMapBtn"
                    onClick={onHome}
                    onMouseEnter={() => setFocus("home")}
                    onMouseLeave={() => setFocus(null)}
                >
                    <LocationIcon
                        size="16px"
                        color={rgb(themeVars[getFocus === "home" ? "--active-color" : "--color"])}
                    />
                </div>

                <div
                    className="customMapBtn"
                    onClick={() => onZoom(1)}
                    onMouseEnter={() => setFocus("plus")}
                    onMouseLeave={() => setFocus(null)}
                >
                    <PlusIcon
                        size="16px"
                        color={rgb(themeVars[getFocus === "plus" ? "--active-color" : "--color"])}
                    />
                </div>

                <div
                    className="customMapBtn"
                    onClick={() => onZoom(-1)}
                    onMouseEnter={() => setFocus("minus")}
                    onMouseLeave={() => setFocus(null)}
                >
                    <MinusIcon
                        size="16px"
                        color={rgb(themeVars[getFocus === "minus" ? "--active-color" : "--color"])}
                    />
                </div>

                <div
                    className={`customMapBtn ${getActive === "ruler" ? "active" : ""}`}
                    role="button"
                    onClick={() => setActive((prev: string) => prev !== "ruler" ? "ruler" : "")}
                    onMouseEnter={() => setFocus("ruler")}
                    onMouseLeave={() => setFocus(null)}
                >
                    <RulerIcon
                        size="16px"
                        color={rgb(
                            themeVars[getActive === "ruler" || getFocus === "ruler" ? "--active-color" : "--color"]
                        )}
                    />
                </div>
            </div>
        </div>
    );
}