import { React } from "jimu-core";
import "./Popup.css";

import CustomScroll from "../CustomScroll";
import {
    uniqueIdField,
    selectedPolyStruct,
} from "../../assets/config";
import { LangKey, Translations } from "../../assets/translations";
import { Theme, ThemeKey } from "../../assets/theme";

import { PlusIcon } from "../../assets/icons";

interface PopupProps {
    getPolyInfo: Record<string, any>;
    getLang: LangKey;
    getTheme: ThemeKey;
    setSelected: (value: selectedPolyStruct) => void;
}

type FieldFormatter =
    | "text"
    | "translation"
    | "area"
    | "date"
    | "datetime"
    | "fireStatus"
    | "boolean"
    | "number"
    | "coordinateLat"
    | "coordinateLon"
    | "cropType";

interface FieldFormat {
    name: string;
    label?: string;
    formatter?: FieldFormatter;
    hideEmpty?: boolean;
}

type FileKind = "pdf" | "doc" | "image";

interface PopupFileItem {
    title: string;
    type: string;
    path: string;
    url: string;
    kind: FileKind;
    download: boolean;
}

// Данные самого полигона. Чтобы добавить новое поле в верхний блок,
// достаточно добавить сюда объект { name, label, formatter }.
const POLYGON_INFO_FIELDS: FieldFormat[] = [
    {
        name: "mfy_id",
        label: "mfy_id",
        formatter: "translation",
    },
    {
        name: "areaha",
        label: "area",
        formatter: "area",
    },
    {
        name: "type_id",
        label: "type",
        formatter: "cropType",
    },
    {
        name: "fire_date",
        label: "fire_date",
        formatter: "text",
    },
    {
        name: "coordinate",
        label: "coordinate_lat",
        formatter: "coordinateLat",
    },
    {
        name: "coordinate",
        label: "coordinate_lon",
        formatter: "coordinateLon",
    },
];

// Данные из таблицы инспектора. Чтобы добавить новое поле в нижний блок
// Inspektor, достаточно добавить сюда объект { name, label, formatter }.
const INSPECTOR_INFO_FIELDS: FieldFormat[] = [
    {
        name: "inspector_name",
        label: "ins_name",
        formatter: "text",
        hideEmpty: true,
    },
    {
        name: "inspection_date",
        label: "ins_date",
        formatter: "datetime",
        hideEmpty: true,
    },
    {
        name: "inspection_result",
        label: "ins_result",
        formatter: "text",
        hideEmpty: true,
    },
    {
        name: "fire_present",
        label: "status",
        formatter: "fireStatus",
    },
    {
        name: "notes",
        label: "comment",
        formatter: "text",
        hideEmpty: true,
    },
    {
        name: "damage_amount",
        label: "damage_amount",
        formatter: "number",
        hideEmpty: true,
    },
    {
        name: "fine_amount",
        label: "fine_amount",
        formatter: "number",
        hideEmpty: true,
    },
    {
        name: "photo_uploaded",
        label: "photo_uploaded",
        formatter: "boolean",
        hideEmpty: true,
    },
    {
        name: "court_decision_uploaded",
        label: "court_decision_uploaded",
        formatter: "boolean",
        hideEmpty: true,
    },
    {
        name: "inspection_created_at",
        label: "inspection_created_at",
        formatter: "datetime",
        hideEmpty: true,
    },
    {
        name: "inspection_updated_at",
        label: "inspection_updated_at",
        formatter: "datetime",
        hideEmpty: true,
    },
    {
        name: "inspection_uniqueid",
        label: "inspection_uniqueid",
        formatter: "text",
        hideEmpty: true,
    },
];

function isEmptyValue(value: any): boolean {
    const raw = String(value ?? "").trim();
    return raw === "" || raw === "null" || raw === "undefined" || raw === "[null]";
}

function translateValue(value: any, lang: LangKey, other: string = "-"): string {
    const key = String(value ?? "").trim();
    if (!key) return other;
    return Translations[key]?.[lang] ?? key;
}

function getAreaValue(info: Record<string, any>): number | null {
    const direct = info["areaha"];
    if (direct != null && direct !== "") {
        const n = Number(direct);
        return Number.isFinite(n) ? n : null;
    }

    return null;
}

function getCoordinatePart(value: unknown, index: 0 | 1): string {
    const raw = String(value ?? "").trim();

    if (!raw) return "-";

    const coordinates = raw
        .split(/[,\s;]+/)
        .map((part) => Number(part.trim()))
        .filter((part) => Number.isFinite(part));

    const coordinate = coordinates[index];

    return coordinate !== undefined
        ? coordinate.toFixed(6)
        : "-";
}

function normalizeFirePresentStatus(value: any): "0" | "1" | "2" {
    if (value === null || value === undefined || String(value).trim() === "") {
        return "0";
    }

    const normalized = String(value).trim().toLowerCase();

    if (value === true || value === 1 || normalized === "true" || normalized === "1") {
        return "1";
    }

    if (value === false || value === 0 || normalized === "false" || normalized === "0") {
        return "2";
    }

    return "0";
}

function formatDateValue(value: any, withTime: boolean): string {
    if (isEmptyValue(value)) return "-";

    const date = new Date(value);

    if (Number.isNaN(date.getTime())) {
        return String(value);
    }

    return withTime
        ? date.toLocaleString("ru-RU")
        : date.toLocaleDateString("ru-RU");
}

function areDateTimesEqual(firstValue: any, secondValue: any): boolean {
    if (isEmptyValue(firstValue) || isEmptyValue(secondValue)) return false;

    const firstDate = new Date(firstValue);
    const secondDate = new Date(secondValue);

    if (!Number.isNaN(firstDate.getTime()) && !Number.isNaN(secondDate.getTime())) {
        return firstDate.getTime() === secondDate.getTime();
    }

    return String(firstValue).trim() === String(secondValue).trim();
}

function formatBooleanValue(value: any, lang: LangKey): string {
    if (isEmptyValue(value)) return "-";

    const normalized = String(value).trim().toLowerCase();
    const result = value === true || normalized === "true" || normalized === "1";

    return result
        ? (Translations["yes"]?.[lang] ?? "Yes")
        : (Translations["no"]?.[lang] ?? "No");
}

function formatNumberValue(value: any): string {
    if (isEmptyValue(value)) return "-";

    const n = Number(value);
    if (!Number.isFinite(n)) return String(value);

    return n.toLocaleString(undefined, {
        minimumFractionDigits: 0,
        maximumFractionDigits: 2,
    });
}


function formatCropType(value: any, lang: LangKey): string {
    const id = String(value ?? "").trim();
    if (!id) return "-";

    const labels: Record<string, Record<LangKey, string>> = {
        "6": { UZ: "Bug‘doy", RU: "Пшеница", EN: "Wheat" },
        "13": { UZ: "Sholi", RU: "Рис", EN: "Rice" },
    };

    return labels[id]?.[lang] ?? `${Translations["type"]?.[lang] ?? "Type"} ID: ${id}`;
}

function getFormattedValue(
    info: Record<string, any>,
    field: FieldFormat,
    lang: LangKey,
): string | number {
    const rawValue = info?.[field.name];

    switch (field.formatter ?? "text") {
        case "translation":
            return translateValue(rawValue, lang);

        case "area": {
            const area = getAreaValue(info);
            return area == null ? "-" : `${area.toFixed(4)} ga`;
        }

        case "date":
            return formatDateValue(rawValue, false);

        case "datetime":
            return formatDateValue(rawValue, true);

        case "fireStatus":
            return Translations[normalizeFirePresentStatus(rawValue)]?.[lang] ?? "-";

        case "boolean":
            return formatBooleanValue(rawValue, lang);

        case "number":
            return formatNumberValue(rawValue);

        case "coordinateLat":
            return getCoordinatePart(rawValue, 0);

        case "coordinateLon":
            return getCoordinatePart(rawValue, 1);

        case "cropType":
            return formatCropType(rawValue, lang);

        case "text":
        default:
            return isEmptyValue(rawValue) ? "-" : String(rawValue);
    }
}

function getFilePath(info: Record<string, any>, fieldName: string): string {
    const value = info?.[fieldName];
    if (value == null) return "";

    const raw = String(value).trim();
    if (!raw || raw === "null" || raw === "[null]") return "";

    return raw;
}

function getPublicFileUrl(path: string): string {
    if (!path) return "";
    if (/^https?:\/\//i.test(path)) return path;

    return `https://minio.uzspace.uz/upload/ekologiya/${path}`;
}

function getFileExt(path: string): string {
    const clearPath = path.split("?")[0].split("#")[0];
    const name = clearPath.split("/").pop() ?? "";
    const ext = name.includes(".") ? name.split(".").pop() : "";

    return String(ext ?? "").toUpperCase();
}

function FileIcon({ kind }: { kind: FileKind }) {
    if (kind === "pdf") {
        return (
            <svg className="popupFileSvg popupFileSvgPdf" viewBox="0 0 24 24" aria-hidden="true">
                <path d="M6 2h8l4 4v16H6z" />
                <path d="M14 2v5h5" />
                <path d="M8 16h8" />
                <path d="M8 12h8" />
                <path d="M8 8h3" />
            </svg>
        );
    }

    if (kind === "doc") {
        return (
            <svg className="popupFileSvg popupFileSvgDoc" viewBox="0 0 24 24" aria-hidden="true">
                <path d="M6 2h8l4 4v16H6z" />
                <path d="M14 2v5h5" />
                <path d="M8 17h8" />
                <path d="M8 13h8" />
                <path d="M8 9h5" />
            </svg>
        );
    }

    return (
        <svg className="popupFileSvg popupFileSvgImage" viewBox="0 0 24 24" aria-hidden="true">
            <rect x="4" y="4" width="16" height="16" rx="3" />
            <path d="M8 15l3-3 3 3 2-2 3 4" />
            <circle cx="9" cy="9" r="1.5" />
        </svg>
    );
}

function PopupFileCard({ item }: { item: PopupFileItem }) {
    if (item.kind === "image") {
        return (
            <a
                className="popupFileCard popupFileCard-image popupFileCardImagePreview"
                href={item.url}
                target="_blank"
                rel="noreferrer"
                title={item.path}
                style={{
                    backgroundImage: `linear-gradient(180deg, rgba(var(--main-bg), 0.12), rgba(var(--main-bg), 0.82)), url(${item.url})`,
                }}
            >
                <div className="popupFileTextBox popupFileTextBoxImage">
                    <div className="popupFileTitle">{item.title}</div>
                    <div className="popupFileType">{item.type}</div>
                </div>
            </a>
        );
    }

    return (
        <a
            className={`popupFileCard popupFileCard-${item.kind}`}
            href={item.url}
            target="_blank"
            rel="noreferrer"
            download={item.download ? "" : undefined}
            title={item.path}
        >
            <div className="popupFileIconBox">
                <FileIcon kind={item.kind} />
            </div>

            <div className="popupFileTextBox">
                <div className="popupFileTitle">{item.title}</div>
                <div className="popupFileType">{item.type}</div>
            </div>
        </a>
    );
}

export default function Popup({
    getPolyInfo,
    getLang,
    getTheme,
    setSelected,
}: PopupProps) {
    const timeoutRef = React.useRef<ReturnType<typeof setTimeout> | null>(null);
    const [getCopyText, setCopyText] = React.useState<string>("");

    const renderFieldRows = React.useCallback((fields: FieldFormat[]) => {
        return fields
            .filter((item) => !item.hideEmpty || !isEmptyValue(getPolyInfo?.[item.name]))
            .map((item: FieldFormat, index: number) => {
                const label = Translations[item.label ?? item.name]?.[getLang] ?? (item.label ?? item.name);
                const value = getFormattedValue(getPolyInfo, item, getLang);

                if (
                    item.name === "inspection_updated_at" &&
                    areDateTimesEqual(
                        getPolyInfo?.inspection_updated_at,
                        getPolyInfo?.inspection_created_at,
                    )
                ) {
                    return null;
                }

                return (
                    <div className="popupInfoRow" key={`${item.name}-${index}`}>
                        <div className="popupInfoName">{label}</div>
                        <div className="popupInfoValue">{value}</div>
                    </div>
                );
            });
    }, [getLang, getPolyInfo]);

    React.useEffect(() => {
        if (!getCopyText) return;

        (async () => {
            try {
                await navigator.clipboard.writeText(getCopyText);

                timeoutRef.current = setTimeout(() => {
                    setCopyText("");
                }, 1000);
            } catch (error) {
                console.error("Ошибка копирования:", error);
            }
        })();

        return () => {
            if (timeoutRef.current) {
                clearTimeout(timeoutRef.current);
                timeoutRef.current = null;
            }
        };
    }, [getCopyText]);

    const uid = String(getPolyInfo?.[uniqueIdField] ?? "");
    const [isImageOpen, setIsImageOpen] = React.useState<boolean>(false);

    const photoPath = getFilePath(getPolyInfo, "photo_paths");
    const dalolatnomaPath = getFilePath(getPolyInfo, "dalolatnoma_path");
    const sudQaroriPath = getFilePath(getPolyInfo, "sud_qarori_path");

    // Космический снимок хранится в MinIO по уникальному ID полигона.
    // Сначала проверяем PNG, затем JPG:
    // screens/Screenshots/{uniqueid}.png
    // screens/Screenshots/{uniqueid}.jpg
    const [imageUrl, setImageUrl] = React.useState<string>("");

    React.useEffect(() => {
        let cancelled = false;

        setImageUrl("");

        if (!uid) {
            return () => {
                cancelled = true;
            };
        }

        const safeUid = encodeURIComponent(uid);
        const candidates = [
            getPublicFileUrl(`screens/Screenshots/${safeUid}.png`),
            getPublicFileUrl(`screens/Screenshots/${safeUid}.jpg`),
        ];

        const checkCandidate = (index: number): void => {
            if (cancelled || index >= candidates.length) return;

            const testImage = new Image();

            testImage.onload = () => {
                if (!cancelled) setImageUrl(candidates[index]);
            };

            testImage.onerror = () => {
                checkCandidate(index + 1);
            };

            testImage.src = candidates[index];
        };

        checkCandidate(0);

        return () => {
            cancelled = true;
        };
    }, [uid]);

    const fileItems = React.useMemo(() => {
        const items: PopupFileItem[] = [];

        const addDocument = (
            path: string,
            titles: Record<LangKey, string>,
        ) => {
            if (!path) return;

            const extension = getFileExt(path) || "FILE";
            const normalizedExtension = extension.toLowerCase();

            items.push({
                title: titles[getLang],
                type: extension,
                path,
                url: getPublicFileUrl(path),
                kind: normalizedExtension === "pdf" ? "pdf" : "doc",
                download: normalizedExtension !== "pdf",
            });
        };

        addDocument(dalolatnomaPath, {
            UZ: "Dalolatnoma",
            RU: "Акт",
            EN: "Inspection report",
        });

        addDocument(sudQaroriPath, {
            UZ: "Sud qarori",
            RU: "Решение суда",
            EN: "Court decision",
        });

        if (photoPath) {
            items.push({
                title: getLang === "RU" ? "Изображение" : getLang === "EN" ? "Image" : "Rasm",
                type: getFileExt(photoPath) || "JPG",
                path: photoPath,
                url: getPublicFileUrl(photoPath),
                kind: "image",
                download: false,
            });
        }

        return items;
    }, [dalolatnomaPath, sudQaroriPath, photoPath, getLang]);

    return (
        <>
            <div className="mainPopupArea">
                <div className="popupTitle">
                    {Translations["malumot"]?.[getLang] ?? "Информация"}
                    <div
                        className="popupBtn"
                        onClick={() =>
                            setSelected({
                                [uniqueIdField]: ""
                            })
                        }
                    >
                        <PlusIcon
                            size="22px"
                            color={`rgba(${Theme[getTheme]["--color"]}, 0.5)`}
                        />
                    </div>
                </div>

                <CustomScroll className="popupInfoBlock">
                    <div className="popupLocationBlock">
                        <div className="popupRegionName">
                            {translateValue(getPolyInfo?.region_id, getLang)}
                        </div>
                        <div className="popupDistrictName">
                            {translateValue(getPolyInfo?.distric_id, getLang)}
                        </div>
                    </div>

                    {renderFieldRows(POLYGON_INFO_FIELDS)}

                    <div className="popupSectionTitle popupInspectorTitle">
                        {Translations["inspectorSection"]?.[getLang] ?? "Inspektor"}
                    </div>
                    {renderFieldRows(INSPECTOR_INFO_FIELDS)}
                </CustomScroll>

                <div className={`popupFilesArea ${fileItems.length === 0 ? "popupFilesAreaEmpty" : ""}`}>
                    {fileItems.map((item) => (
                        <PopupFileCard
                            key={`${item.kind}-${item.path}`}
                            item={item}
                        />
                    ))}
                </div>

                <div className="popupUniqueIdArea">
                    <div
                        className="popupUniqueIBlock"
                        onClick={() => {
                            if (uid) setCopyText(uid);
                        }}
                    >
                        <div className={`copyBlock ${getCopyText === "" ? "top" : "bottom"}`}>
                            <div className="popupUniqueIdTitle">UID:</div>
                            <div className="popupUniqueId">{uid || "-"}</div>
                        </div>

                        <div className={`completeBlock ${getCopyText === "" ? "bottom" : "top"}`}>
                            {Translations["copiedText"]?.[getLang] ?? "Скопировано"}!
                        </div>
                    </div>
                </div>
            </div>

            {imageUrl && (
                <div
                    className="imageArea"
                    key="image"
                    onClick={() => setIsImageOpen(true)}
                >
                    <div
                        className="imageTitle"
                        style={{
                            backgroundImage: `radial-gradient(ellipse 100% 70px at 50% 100%, rgba(var(--area-bg), 0.8) 30%, transparent 60%), url(${imageUrl})`,
                        }}
                    >
                        {Translations["imgTitle"]?.[getLang] ?? "Kosmik surat"}
                    </div>
                </div>
            )}

            {isImageOpen && imageUrl && (
                <div
                    className="imageModalOverlay"
                    onClick={() => setIsImageOpen(false)}
                >
                    <div
                        className="imageModal"
                        onClick={(event) => event.stopPropagation()}
                    >
                        <div
                            className="imageModalContent"
                            style={{
                                backgroundImage: `radial-gradient(ellipse 100% 90px at 50% 100%, rgba(var(--area-bg), 0.85) 30%, transparent 65%), url(${imageUrl})`,
                            }}
                        >
                            <div className="imageModalTitle">
                                {Translations["imgTitle"]?.[getLang] ?? "Kosmik surat"}
                            </div>
                        </div>

                        <div
                            className="imageModalClose"
                            onClick={() => setIsImageOpen(false)}
                        >
                            <PlusIcon
                                size="28px"
                                color={`rgba(${Theme[getTheme]["--color"]}, 0.8)`}
                            />
                        </div>
                    </div>
                </div>
            )}
        </>
    );
}
