import { React } from "jimu-core"
import FeatureLayer from "@arcgis/core/layers/FeatureLayer"
import Query from "@arcgis/core/rest/support/Query"
import "./StatusBarChart.css"

import {
    filterStruct,
    buildWhereQuery
} from "../../assets/config"
import {
    LangKey,
    Translations
} from "../../assets/translations"
import { Theme, ThemeKey } from "../../assets/theme"

interface StatusBarChartProps {
    getLang: LangKey
    getTheme: ThemeKey
    getFilter: filterStruct
    setFilter: (value: any) => void
    mainLayerRef: React.MutableRefObject<FeatureLayer>
}

type StatusKey = "0" | "1" | "2" | "3"

type StatusData = Record<StatusKey, number>

const emptyData: StatusData = {
    "0": 0,
    "1": 0,
    "2": 0,
    "3": 0
}

const statusKeys: StatusKey[] = ["3", "1", "2", "0"]

function pickExistingField(layer: FeatureLayer, candidates: string[]): string | null {
    const layerFields = (layer.fields ?? []).map((field) => String(field.name))

    for (const candidate of candidates) {
        if (layerFields.includes(candidate)) return candidate
    }

    return null
}

function normalizeFirePresent(value: any): StatusKey {
    if (value === null || value === undefined || String(value).trim() === "") {
        return "0" // в процессе
    }

    if (value === true || value === 1 || String(value).toLowerCase() === "true") {
        return "1" // подтверждено
    }

    if (value === false || value === 0 || String(value).toLowerCase() === "false") {
        return "2" // не подтверждено
    }

    return "0"
}

function setColor(value: StatusKey) {
    switch (value) {
        case "0": return "--in-process"
        case "1": return "--confirmed-color"
        case "2": return "--no-confirmed-color"
        case "3": return "--checked-color"
        default: return "--in-process"
    }
}

export default function StatusBarChart({
    getLang,
    getTheme,
    getFilter,
    setFilter,
    mainLayerRef
}: StatusBarChartProps) {
    const [getStatusBarChartData, setStatusBarChartData] = React.useState<StatusData>(emptyData)
    const [getStatusBarMaxCount, setStatusBarMaxCount] = React.useState<number>(0)
    const [getStatusMaxCount, setStatusMaxCount] = React.useState<number>(0)

    const activeStatus = getFilter.fire_present

    const clickHandler = React.useCallback((value: StatusKey) => {
        setFilter((prev: filterStruct) => ({
            ...prev,
            fire_present: value === prev.fire_present ? "" : value
        }))
    }, [setFilter])

    React.useEffect(() => {
        let cancelled = false

            ; (async () => {
                const layer = mainLayerRef?.current
                if (!layer) return

                try {
                    await layer.load()

                    const firePresentField = pickExistingField(layer, ["fire_present"])
                    const countField =
                        pickExistingField(layer, ["objectid", "OBJECTID", "uniqueid", "area", "areaha"]) ||
                        firePresentField

                    if (!firePresentField || !countField) {
                        console.error("[StatusBarChart] required fields not found:", {
                            firePresentField,
                            countField,
                            fields: (layer.fields ?? []).map((f) => f.name)
                        })

                        if (!cancelled) {
                            setStatusBarChartData(emptyData)
                            setStatusBarMaxCount(0)
                        }

                        return
                    }

                    const filterWithoutFirePresent: filterStruct = {
                        ...getFilter,
                        fire_present: ""
                    }

                    const query = new Query({
                        where: buildWhereQuery(filterWithoutFirePresent, "status"),
                        returnGeometry: false,
                        groupByFieldsForStatistics: [firePresentField],
                        orderByFields: ["count_area DESC"],
                        outStatistics: [
                            {
                                statisticType: "count",
                                onStatisticField: countField,
                                outStatisticFieldName: "count_area"
                            }
                        ],
                        outFields: [firePresentField]
                    })

                    const result = await layer.queryFeatures(query)
                    if (cancelled) return

                    setStatusMaxCount(0)
                    const dataStruct: StatusData = { ...emptyData }

                        ; (result.features ?? []).forEach((feature: any) => {
                            const attrs = feature.attributes ?? {}
                            const count = Number(attrs.count_area ?? 0)
                            const key = normalizeFirePresent(attrs[firePresentField])

                            dataStruct[key] += count

                            if (key === "1" || key === "2") {
                                dataStruct["3"] += count
                            }

                            setStatusMaxCount((prev: number) => prev + count)
                        })


                    if (!cancelled) {
                        setStatusBarChartData(dataStruct)
                        setStatusBarMaxCount(Math.max(...Object.values(dataStruct), 0))
                    }
                } catch (error) {
                    console.error("[StatusBarChart] query error:", error)

                    if (!cancelled) {
                        setStatusBarChartData(emptyData)
                        setStatusBarMaxCount(0)
                        setStatusMaxCount(0)
                    }
                }
            })()

        return () => {
            cancelled = true
        }
    }, [getFilter, mainLayerRef])

    return (
        <div className="statusBarChartArea">
            <div className="statusBarChartTitle">
                {Translations["statusBarChart"][getLang]}
            </div>

            {statusKeys.map((item) => {
                const isActive = item === activeStatus

                return (
                    <div
                        key={item}
                        style={{
                            backgroundImage: `linear-gradient(180deg, rgba(var(${setColor(item)}), 0.3) 0%, #00000000 50%)`,
                            borderTop: `3px solid rgb(var(${setColor(item)}))`
                        }}
                        className={`statusBarChartRow ${isActive ? "active" : ""}`}
                        onClick={() => clickHandler(item)}
                    >
                        <div className="statusBarChartInfo">
                            <div
                                className="statusBarChartName"
                                style={{
                                    color: `rgba(${isActive ? Theme[getTheme]["--active-color"] : Theme[getTheme]["--color"]}, 0.6)`
                                }}
                            >
                                {Translations[item][getLang]} ( {((getStatusBarChartData[item] / getStatusMaxCount) * 100).toFixed(2)}% )
                            </div>

                            <div
                                className="statusBarChartValue"
                                style={{
                                    color: `rgb(${isActive ? Theme[getTheme]["--active-color"] : Theme[getTheme]["--color"]})`
                                }}
                            >
                                {getStatusBarChartData[item]} {Translations["countPrefix"][getLang]}
                            </div>
                        </div>

                        <div
                            className="statusBarChartBar"
                            style={{
                                width: `${getStatusBarMaxCount > 0
                                    ? (getStatusBarChartData[item] / getStatusBarMaxCount) * 100
                                    : 0}%`,
                                backgroundColor: `rgba(var(${setColor(item)}), 0.7)`
                            }}
                        />
                    </div>
                )
            })}
        </div>
    )
}