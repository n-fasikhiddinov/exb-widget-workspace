import { React } from "jimu-core"
import "./Selector.css"

export interface SelectorOption {
    value: string | number
    label: string
}

interface SelectorProps {
    name: string
    value: string | number | null
    options: Array<string | number | SelectorOption>
    onChange: (value: string | number | null) => void
}

const normalizeOption = (option: string | number | SelectorOption): SelectorOption => {
    if (typeof option === "object") return option
    return { value: option, label: String(option) }
}

export default function Selector({
    name,
    value,
    options,
    onChange
}: SelectorProps) {
    const [isSelectorOpen, toggleSelectorShow] = React.useState<boolean>(false)
    const rootRef = React.useRef<HTMLDivElement>(null)
    const [getRootInfo, setRootInfo] = React.useState<DOMRect>()

    React.useEffect(() => {
        if (rootRef.current) setRootInfo(rootRef.current.getBoundingClientRect())
    }, [])

    React.useEffect(() => {
        if (!isSelectorOpen) return

        const onPointerDown = (e: PointerEvent) => {
            if (!rootRef.current) return
            if (!rootRef.current.contains(e.target as Node)) toggleSelectorShow(false)
        }

        const onKeyDown = (e: KeyboardEvent) => {
            if (e.key === "Escape") toggleSelectorShow(false)
        }

        document.addEventListener("pointerdown", onPointerDown, true)
        document.addEventListener("keydown", onKeyDown)

        return () => {
            document.removeEventListener("pointerdown", onPointerDown, true)
            document.removeEventListener("keydown", onKeyDown)
        }
    }, [isSelectorOpen])

    const normalizedOptions = options.map(normalizeOption)
    const selectedOption = normalizedOptions.find(
        option => String(option.value) === String(value ?? "")
    )

    function onClick(option: SelectorOption) {
        if (String(value ?? "") === String(option.value)) onChange(null)
        else onChange(option.value)
        toggleSelectorShow(false)
    }

    return (
        <div className="mainSelectorArea" ref={rootRef}>
            <div
                className="selectorBtnArea"
                onClick={() => toggleSelectorShow(!isSelectorOpen)}
            >
                {selectedOption?.label || name}
            </div>

            {isSelectorOpen && (
                <div className="selectorOptionsArea">
                    {normalizedOptions.map((option) => (
                        <div
                            key={`selector-option-${String(option.value)}`}
                            className={`selectorOptions ${
                                String(value ?? "") === String(option.value) ? "active" : ""
                            }`}
                            style={{ height: getRootInfo?.height }}
                            onClick={() => onClick(option)}
                        >
                            {option.label}
                        </div>
                    ))}
                </div>
            )}
        </div>
    )
}
