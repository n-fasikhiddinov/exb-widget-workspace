import { React, SessionManager, getAppStore } from "jimu-core"
import * as XLSX from "xlsx"
import { buildWhereQuery, filterStruct, selectedPolyStruct, uniqueIdField } from "../../assets/config"
import { LangKey, Translations } from "../../assets/translations"
import { LogoIcon, UserAvatarIcon } from "../../assets/icons"
import DownloadSvg from "../../assets/Dowload.svg"
import FrameSvg from "../../assets/Frame.svg"
import GridSvg from "../../assets/Grid.svg"
import MoonSvg from "../../assets/Moon.svg"
import NotificationSvg from "../../assets/Notification.svg"
import SearchSvg from "../../assets/Search.svg"
import SunSvg from "../../assets/Sun.svg"
import { Theme, ThemeKey } from "../../assets/theme"
import "./Header.css"
import FeatureLayer from "@arcgis/core/layers/FeatureLayer"
import { logoutFromAccount } from "./logout"
import CustomScroll from "../CustomScroll"

type ContentType = "notification" | "download" | "content" | "theme" | "language" | "profile" | null
type ToggleContentType = Exclude<ContentType, "download" | "theme" | null>

interface HeaderProps {
    mainDateRef: React.RefObject<FeatureLayer>
    getLang: LangKey
    setLang: (value: LangKey) => void
    getTheme: ThemeKey
    setTheme: (value: ThemeKey) => void
    setSelected: (value: selectedPolyStruct) => void
    getFilter: filterStruct
    getTotal: number
}

type ColumnDef = { key: string | "*"; label: string; format?: (v: any) => string | number }
type NotificationItem = Record<string, any>

type NotificationRegionGroup = {
    key: string
    regionId: string
    regionName: string
    count: number
    totalArea: number
    notificationTime: number
    notificationDate: string
    rows: NotificationItem[]
}

type NotificationDateGroup = {
    key: string
    label: string
    time: number
    regions: NotificationRegionGroup[]
}

const NOTIFICATION_LIMIT = 10
const NOTIFICATION_DAYS = 5
const NOTIFICATION_DATE_FIELD = "created_date"

// Сколько строк читать за один запрос к FeatureLayer.
const NOTIFICATION_PAGE_SIZE = 1000

// Максимум строк, которые можно просканировать для уведомлений.
// 0 = читать все строки слоя. Для текстовой даты лучше оставлять 0, иначе новые записи могут не попасть в первые N строк слоя.
const NOTIFICATION_MAX_SCAN_COUNT = 0

// Задержка перед запросом, чтобы быстрые повторные клики не спамили сервер.
const NOTIFICATION_REQUEST_DELAY_MS = 500
const RECENT_NOTIFICATION_MS = 24 * 60 * 60 * 1000

function parseDateParts(year: number, month: number, day: number, hour = 0, minute = 0, second = 0): number {
    if (!year || !month || !day) return 0
    if (month < 1 || month > 12) return 0
    if (day < 1 || day > 31) return 0

    const date = new Date(year, month - 1, day, hour, minute, second)

    // Защита от автоматического переноса JS Date, например 32/01 -> февраль.
    if (
        date.getFullYear() !== year ||
        date.getMonth() !== month - 1 ||
        date.getDate() !== day
    ) {
        return 0
    }

    const time = date.getTime()
    return Number.isFinite(time) ? time : 0
}

function getDateValue(value: any): number {
    if (value === null || value === undefined || value === "") return 0

    if (typeof value === "number") {
        // ArcGIS Date обычно приходит в миллисекундах. Если вдруг пришли секунды — переводим в ms.
        return value < 100000000000 ? value * 1000 : value
    }

    const raw = String(value).trim()
    if (!raw) return 0

    // 1718793600000 или 1718793600
    if (/^\d+$/.test(raw)) {
        const num = Number(raw)
        return num < 100000000000 ? num * 1000 : num
    }

    // 2026-06-19, 2026-06-19 14:30:00, 2026/06/19 14:30
    const ymd = raw.match(/^(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})(?:[ T](\d{1,2}):(\d{1,2})(?::(\d{1,2}))?)?/)
    if (ymd) {
        return parseDateParts(
            Number(ymd[1]),
            Number(ymd[2]),
            Number(ymd[3]),
            Number(ymd[4] ?? 0),
            Number(ymd[5] ?? 0),
            Number(ymd[6] ?? 0),
        )
    }

    // 19.06.2026, 19.06.2026 14:30:00, 19/06/2026 14:30
    const dmy = raw.match(/^(\d{1,2})[-/.](\d{1,2})[-/.](\d{4})(?:[ T](\d{1,2}):(\d{1,2})(?::(\d{1,2}))?)?/)
    if (dmy) {
        return parseDateParts(
            Number(dmy[3]),
            Number(dmy[2]),
            Number(dmy[1]),
            Number(dmy[4] ?? 0),
            Number(dmy[5] ?? 0),
            Number(dmy[6] ?? 0),
        )
    }

    const parsed = new Date(raw).getTime()
    return Number.isFinite(parsed) ? parsed : 0
}

function formatDateTime(value: any): string {
    const time = getDateValue(value)
    if (!time) return String(value ?? "")

    return new Date(time).toLocaleString("ru-RU", {
        year: "numeric",
        month: "2-digit",
        day: "2-digit",
        hour: "2-digit",
        minute: "2-digit",
    })
}

function formatNotificationDate(value: any): string {
    const time = getDateValue(value)
    if (!time) return String(value ?? "")

    return new Date(time).toLocaleDateString("ru-RU", {
        year: "numeric",
        month: "2-digit",
        day: "2-digit",
    })
}

function getNotificationDateKey(time: number): string {
    if (!time) return "unknown"
    const date = new Date(time)
    const year = date.getFullYear()
    const month = String(date.getMonth() + 1).padStart(2, "0")
    const day = String(date.getDate()).padStart(2, "0")
    return `${year}-${month}-${day}`
}

function getNotificationRegionName(regionId: any, lang: LangKey): string {
    const value = regionId ?? ""
    const translated = Translations?.[value]?.[lang] ?? value
    const result = String(translated).trim()
    return result || "Регион не указан"
}

function groupNotifications(rows: NotificationItem[], lang: LangKey): NotificationDateGroup[] {
    const dateGroups = new Map<string, NotificationDateGroup>()

    for (const row of rows) {
        const time = getDateValue(row[NOTIFICATION_DATE_FIELD])
        const dateKey = getNotificationDateKey(time)
        const regionId = String(row.region_id ?? "unknown")
        const regionKey = `${dateKey}::${regionId}`

        let dateGroup = dateGroups.get(dateKey)
        if (!dateGroup) {
            dateGroup = {
                key: dateKey,
                label: formatNotificationDate(row[NOTIFICATION_DATE_FIELD]),
                time,
                regions: [],
            }
            dateGroups.set(dateKey, dateGroup)
        }

        let regionGroup = dateGroup.regions.find(item => item.key === regionKey)
        if (!regionGroup) {
            regionGroup = {
                key: regionKey,
                regionId,
                regionName: getNotificationRegionName(row.region_id, lang),
                count: 0,
                totalArea: 0,
                notificationTime: time,
                notificationDate: formatDateTime(row[NOTIFICATION_DATE_FIELD]),
                rows: [],
            }
            dateGroup.regions.push(regionGroup)
        }

        regionGroup.count += 1
        const area = Number(row.areaha)
        if (Number.isFinite(area)) regionGroup.totalArea += area
        if (time > regionGroup.notificationTime) {
            regionGroup.notificationTime = time
            regionGroup.notificationDate = formatDateTime(row[NOTIFICATION_DATE_FIELD])
        }
        regionGroup.rows.push(row)
        dateGroup.time = Math.max(dateGroup.time, time)
    }

    return Array.from(dateGroups.values())
        .sort((a, b) => b.time - a.time)
        .map(group => ({
            ...group,
            regions: group.regions.sort((a, b) => b.count - a.count || b.totalArea - a.totalArea),
        }))
}

function formatNotificationArea(value: any): string {
    const area = Number(value)
    return Number.isFinite(area) ? String(Math.round(area * 10000) / 10000) : ""
}

function getNotificationAddress(row: NotificationItem, lang: LangKey): string {
    const parts = [row.region_id, row.distric_id, row.mfy_id]
        .map(value => Translations?.[value]?.[lang] ?? value ?? "")
        .map(value => String(value).trim())
        .filter(Boolean)

    return parts.length ? parts.join(" / ") : "Ничего не найдено"
}

function translateLabel(label: string, lang: LangKey): string {
    return Translations[label]?.[lang] ?? label
}

function buildSheetRow(
    row: Record<string, any>,
    columns: ColumnDef[],
    lang: LangKey,
): Record<string, any> {
    const result: Record<string, any> = {}

    for (const col of columns) {
        if (col.key === "*") {
            for (const [k, v] of Object.entries(row)) {
                result[translateLabel(k, lang)] = v ?? ""
            }
        } else {
            const header = translateLabel(col.label, lang)
            result[header] = col.format ? col.format(row[col.key]) : (row[col.key] ?? "")
        }
    }

    return result
}

function colWidths(sheetData: Record<string, any>[]): XLSX.ColInfo[] {
    if (!sheetData.length) return []
    return Object.keys(sheetData[0]).map(k => ({
        wch: Math.max(k.length, ...sheetData.map(r => String(r[k] ?? "").length)) + 2,
    }))
}

// function SearchIcon({ color, size = "22px" }: { color: string; size?: string }) {
//     return (
//         <svg width={size} height={size} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
//             <circle cx="11" cy="11" r="7" stroke={color} strokeWidth="2.2" />
//             <path d="M20 20L16.65 16.65" stroke={color} strokeWidth="2.2" strokeLinecap="round" />
//         </svg>
//     )
// }

export default function Header({
    mainDateRef,
    getLang,
    setLang,
    getTheme,
    setTheme,
    setSelected,
    getFilter,
    getTotal
}: HeaderProps) {
    const userRef = React.useRef(getAppStore().getState())

    const [getAvatar, setAvatar] = React.useState<string | null>(null)
    const [getContent, setContent] = React.useState<ContentType>(null)
    const [searchValue, setSearchValue] = React.useState("")
    const [notifications, setNotifications] = React.useState<NotificationItem[]>([])
    const [notificationsLoading, setNotificationsLoading] = React.useState(false)
    const [notificationsError, setNotificationsError] = React.useState("")
    const [hasRecentNotification, setHasRecentNotification] = React.useState(false)
    const [isDownloading, setIsDownloading] = React.useState(false)

    const notificationDelayTimerRef = React.useRef<number | null>(null)
    const notificationRequestInProgressRef = React.useRef(false)

    const additionalAreaRef = React.useRef<HTMLDivElement | null>(null)

    const triggerRefs = React.useRef<Record<ToggleContentType, HTMLDivElement | null>>({
        notification: null,
        content: null,
        language: null,
        profile: null,
    })

    const setTriggerRef = React.useCallback(
        (type: ToggleContentType) => (node: HTMLDivElement | null) => {
            triggerRefs.current[type] = node
        },
        []
    )

    const COLUMNS: ColumnDef[] = [
        { key: "uniqueid", label: "uniqueid" },
        {
            key: "region_id",
            label: "region_id",
            format: v => {
                return Translations?.[v]?.[getLang] ?? v ?? ""
            },
        },
        {
            key: "distric_id",
            label: "distric_id",
            format: v => {
                return Translations?.[v]?.[getLang] ?? v ?? ""
            },
        },
        {
            key: "mfy_id",
            label: "mfy_id",
            format: v => {
                return Translations?.[v]?.[getLang] ?? v ?? ""
            },
        },
        {
            key: "fire_date",
            label: "fire_date",
        },
        {
            key: "areaha",
            label: "area",
            format: v => {
                const n = Number(v)
                return Number.isFinite(n) ? Math.round(n * 100) / 100 : ""
            },
        },
        {
            key: "fire_present",
            label: "status",
            format: v => {
                return Translations?.[v ?? 0]?.[getLang] ?? v ?? ""
            },
        },
        {
            key: "coordinate",
            label: "coordinate"
        },
    ]

    React.useEffect(() => {
        let cancelled = false

            ; (async () => {
                const session = SessionManager.getInstance().getMainSession()
                if (!session) {
                    if (!cancelled) setAvatar(null)
                    return
                }

                const user = await session.getUser()
                if (!user?.thumbnail) {
                    if (!cancelled) setAvatar(null)
                    return
                }

                const base = session.portal.replace(/\/+$/, "")
                const path = `${base}/community/users/${encodeURIComponent(user.username)}/info/${encodeURIComponent(user.thumbnail)}`
                const url = session.token ? `${path}?token=${encodeURIComponent(session.token)}` : path

                if (!cancelled) setAvatar(url)
            })()

        return () => { cancelled = true }
    }, [])

    React.useEffect(() => {
        if (
            getContent === null ||
            getContent === "download"
        ) {
            return
        }

        const handlePointerDown = (event: MouseEvent) => {
            const target = event.target as Node | null
            if (!target) return

            const activeTrigger = triggerRefs.current[getContent]
            const popup = additionalAreaRef.current

            const clickedInsideTrigger = !!activeTrigger && activeTrigger.contains(target)
            const clickedInsidePopup = !!popup && popup.contains(target)

            if (!clickedInsideTrigger && !clickedInsidePopup) {
                setContent(null)
            }
        }

        document.addEventListener("mousedown", handlePointerDown)
        return () => {
            document.removeEventListener("mousedown", handlePointerDown)
        }
    }, [getContent])

    const onSearchSubmit = React.useCallback(() => {
        const v = searchValue.trim()
        setSelected({
            [uniqueIdField]: v
        })
    }, [searchValue, setSelected])

    const ExcelDownload = React.useCallback(async () => {
        const layer = mainDateRef.current
        if (!layer || isDownloading) return

        setIsDownloading(true)
        try {
            await layer.load()

            const where = buildWhereQuery(getFilter, "map")
            const COUNT = layer.capabilities?.query?.maxRecordCount ?? 2000

            const countQuery = layer.createQuery()
            countQuery.where = where
            countQuery.returnGeometry = false

            const totalCount = await layer.queryFeatureCount(countQuery)
            if (!totalCount) return

            const totalPages = Math.ceil(totalCount / COUNT)

            const layerFieldNames = layer.fields.map((field: any) => field.name)

            const outFields = Array.from(
                new Set(
                    COLUMNS
                        .filter(col => col.key !== "*")
                        .map(col => col.key as string)
                        .filter(key => layerFieldNames.includes(key))
                )
            )

            const pages = await Promise.all(
                Array.from({ length: totalPages }, async (_, i) => {
                    const query = layer.createQuery()

                    query.where = where
                    query.outFields = outFields
                    query.returnGeometry = false
                    query.num = COUNT
                    query.start = i * COUNT

                    const result = await layer.queryFeatures(query)

                    return result.features.map(
                        (feature: any) => feature.attributes as Record<string, any>
                    )
                })
            )

            const rows = pages.flat()

            if (!rows.length) return

            const sheetData = rows.map((row: Record<string, any>) => buildSheetRow(row, COLUMNS, getLang))

            const downloadedAt = new Date().toLocaleString(
                getLang === "RU" ? "ru-RU" : getLang === "UZ" ? "uz-UZ" : "en-US",
                {
                    year: "numeric",
                    month: "2-digit",
                    day: "2-digit",
                    hour: "2-digit",
                    minute: "2-digit",
                    second: "2-digit",
                }
            )

            const downloadDateLabel = getLang === "RU"
                ? "Дата скачивания"
                : getLang === "UZ"
                    ? "Yuklab olingan sana"
                    : "Download date"

            const wb = XLSX.utils.book_new()
            const ws = XLSX.utils.aoa_to_sheet([
                [`${downloadDateLabel}: ${downloadedAt}`],
                [],
            ])

            XLSX.utils.sheet_add_json(ws, sheetData, {
                origin: "A3",
                skipHeader: false,
            })

            ws["!cols"] = colWidths(sheetData)

            XLSX.utils.book_append_sheet(wb, ws, Translations["tableTitle"][getLang])

            const title = Translations["headerTitle"][getLang].split(" ").join("_")
            const subtitle = Translations["headerParagraph"][getLang].split(" ").join("_")

            XLSX.writeFile(
                wb,
                `${title}_${subtitle}_${new Date().toISOString().slice(0, 10)}.xlsx`
            )
            setContent(null)
        } catch (error) {
            console.error("[Header] ExcelDownload error:", error)
        } finally {
            setIsDownloading(false)
        }
    }, [mainDateRef, getFilter, getLang, isDownloading])

    const clearNotificationDelayTimer = React.useCallback(() => {
        if (notificationDelayTimerRef.current !== null) {
            window.clearTimeout(notificationDelayTimerRef.current)
            notificationDelayTimerRef.current = null
        }
    }, [])

    React.useEffect(() => {
        return () => {
            clearNotificationDelayTimer()
        }
    }, [clearNotificationDelayTimer])

    const loadNotifications = React.useCallback(async () => {
        const layer = mainDateRef.current
        if (!layer) return
        if (notificationRequestInProgressRef.current) return

        notificationRequestInProgressRef.current = true
        setNotificationsLoading(true)
        setNotificationsError("")

        try {
            await layer.load()

            const minDate = new Date()
            minDate.setDate(minDate.getDate() - NOTIFICATION_DAYS)
            const minTime = minDate.getTime()

            const layerFieldNames = layer.fields.map((field: any) => field.name)
            const outFields = Array.from(
                new Set(
                    [
                        "objectid",
                        uniqueIdField,
                        "region_id",
                        "distric_id",
                        "mfy_id",
                        NOTIFICATION_DATE_FIELD,
                        "areaha",
                        "status",
                        "fire_present",
                    ].filter(fieldName => layerFieldNames.includes(fieldName))
                )
            )

            const countQuery = layer.createQuery()
            countQuery.where = "1=1"
            countQuery.returnGeometry = false

            const totalCount = await layer.queryFeatureCount(countQuery)
            const scanCount = NOTIFICATION_MAX_SCAN_COUNT > 0
                ? Math.min(totalCount, NOTIFICATION_MAX_SCAN_COUNT)
                : totalCount

            const totalPages = Math.ceil(scanCount / NOTIFICATION_PAGE_SIZE)

            const pages = await Promise.all(
                Array.from({ length: totalPages }, async (_, pageIndex) => {
                    const query = layer.createQuery()

                    query.where = "1=1"
                    query.outFields = outFields.length ? outFields : ["*"]
                    query.returnGeometry = false
                    query.num = Math.min(NOTIFICATION_PAGE_SIZE, scanCount - pageIndex * NOTIFICATION_PAGE_SIZE)
                    query.start = pageIndex * NOTIFICATION_PAGE_SIZE

                    const result = await layer.queryFeatures(query)

                    return result.features.map(
                        (feature: any) => feature.attributes as NotificationItem
                    )
                })
            )

            const parsedRows = pages
                .flat()
                .map(row => ({
                    row,
                    time: getDateValue(row[NOTIFICATION_DATE_FIELD]),
                }))

            const filteredRows = parsedRows
                .filter(item => item.time >= minTime)
                .sort((a, b) => b.time - a.time)
                .map(item => item.row)

            console.log("[Header] notifications scan", {
                totalCount,
                scanCount,
                parsedCount: parsedRows.length,
                matchedCount: parsedRows.filter(item => item.time >= minTime).length,
                minDate,
                newestDates: parsedRows
                    .filter(item => item.time > 0)
                    .sort((a, b) => b.time - a.time)
                    .slice(0, 5)
                    .map(item => item.row[NOTIFICATION_DATE_FIELD]),
            })

            const recentThreshold = Date.now() - RECENT_NOTIFICATION_MS
            setHasRecentNotification(
                parsedRows.some(item => item.time > 0 && item.time >= recentThreshold)
            )

            setNotifications(filteredRows)
        } catch (error) {
            console.error("[Header] loadNotifications error:", error)
            setNotifications([])
            setHasRecentNotification(false)
            setNotificationsError("Не удалось загрузить уведомления")
        } finally {
            notificationRequestInProgressRef.current = false
            setNotificationsLoading(false)
        }
    }, [mainDateRef])

    React.useEffect(() => {
        const timer = window.setTimeout(() => {
            void loadNotifications()
        }, 800)

        return () => window.clearTimeout(timer)
    }, [loadNotifications])

    const scheduleNotificationsLoad = React.useCallback(() => {
        clearNotificationDelayTimer()

        setNotificationsLoading(true)
        setNotificationsError("")

        notificationDelayTimerRef.current = window.setTimeout(() => {
            notificationDelayTimerRef.current = null
            void loadNotifications()
        }, NOTIFICATION_REQUEST_DELAY_MS)
    }, [clearNotificationDelayTimer, loadNotifications])

    const groupedNotifications = React.useMemo(
        () => groupNotifications(notifications, getLang)
            .map(dateGroup => ({
                ...dateGroup,
                regions: dateGroup.regions.slice(0, NOTIFICATION_LIMIT),
            })),
        [notifications, getLang]
    )

    const contents = (type: ContentType) => {
        switch (type) {
            case "notification":
                if (notificationsLoading) {
                    return (
                        <div className="notificationBlock notificationEmpty">
                            Загрузка уведомлений...
                        </div>
                    )
                }

                if (notificationsError) {
                    return (
                        <div className="notificationBlock notificationEmpty">
                            {notificationsError}
                        </div>
                    )
                }

                if (!notifications.length) {
                    return (
                        <div className="notificationBlock notificationEmpty">
                            Нет новых уведомлений за последние {NOTIFICATION_DAYS} дней
                        </div>
                    )
                }

                return groupedNotifications.map(dateGroup => (
                    <div className="notificationDateGroup" key={dateGroup.key}>
                        <div className="notificationDateGroupTitle">{dateGroup.label}</div>

                        {dateGroup.regions.map(region => (
                            <div
                                className="notificationBlock"
                                key={region.key}
                            >
                                <div className="notificationCard">
                                    <div className="notificationRow notificationRowTop">
                                        <div className="notificationRegion">
                                            <span>{region.regionName}</span>
                                            <span className="notificationCount">{region.count}</span>
                                        </div>

                                        <div className="notificationArea">
                                            {formatNotificationArea(region.totalArea)} ( {Translations["areaPrefix"][getLang]} )
                                        </div>
                                    </div>

                                    <div className="notificationRow notificationRowBottom">
                                        <div className="notificationAlertLabel">{Translations["notificationDate"][getLang]}</div>

                                        <div className="notificationDate">
                                            {region.notificationDate}
                                        </div>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                ))


            case "content":
                return ["c1", "c2", "c3", "c4", "c5"].map(k => (
                    <div className="contentBlock" key={k}>
                        contentBlock
                    </div>
                ))

            case "language":
                return Object.entries(Translations["langs"]).map(([key, value], i) => (
                    <div
                        key={i}
                        className={`language ${key === getLang ? "active" : ""}`}
                        onClick={() => {
                            setLang(key as LangKey)
                            localStorage.setItem("getLang", key)
                        }}
                    >
                        {value}
                    </div>
                ))

            case "profile":
                return (
                    <div className="profileBlock">
                        <div className="profileImgBlock">
                            <div className="profileAvatar">
                                {
                                    getAvatar !== "" ?
                                        <img src={getAvatar} alt="avatar" />
                                        :
                                        <UserAvatarIcon
                                            size="70px"
                                            color={`rgb(${Theme[getTheme]["--text-color"]})`}
                                        />
                                }
                            </div>
                        </div>
                        <div className="userInfoBlock">
                            <div className="userFullName">
                                {userRef.current.user.lastName} {userRef.current.user.firstName[0]}.
                            </div>
                            <div className="username">{userRef.current.user.username}</div>
                            <div className="logOutBtn" onClick={logoutFromAccount}>
                                {Translations["logOut"][getLang]}
                            </div>
                        </div>
                    </div>
                )

            default:
                return null
        }
    }

    const filterLabels: Partial<Record<keyof filterStruct, string>> = {
        type: "Тип",
        region_id: "Регион",
        distric_id: "Район",
        year: "Год",
        month: "Месяц",
        day: "День",
        fire_present: "Статус",
    }

    const activeFilters = Object.entries(getFilter)
        .filter(([, value]) => value !== "" && value !== null && value !== undefined)
        .map(([key, value]) => ({
            key,
            label: filterLabels[key as keyof filterStruct] ?? translateLabel(key, getLang),
            value: Translations?.[String(value)]?.[getLang] ?? String(value),
        }))

    const iconByType = {
        notification: NotificationSvg,
        download: DownloadSvg,
        content: GridSvg,
        language: FrameSvg,
        theme: getTheme === "dark" ? MoonSvg : SunSvg,
    } as const

    return (
        <div className="headerArea">
            <div className="blurCard" />

            <div className="headerTitleArea">
                <LogoIcon size={["120px", "60px"]} color={`rgb(${Theme[getTheme]["--color"]})`} />
                <span />
                <div className="headerTitleBlock">
                    <div className="headerTitle">{Translations["headerTitle"][getLang]}</div>
                    <div className="headerParagraph">{Translations["headerParagraph"][getLang]}<span style={{ opacity: 0.6 }}>{" (Demo)"}</span></div>
                </div>
            </div>

            <div className="headerSearchArea">
                <div className="headerSearch">
                    <div className="headerSearchInputWrap">
                        <div className="headerSearchIcon">
                            <img className="headerSvgIcon" src={SearchSvg} alt="" aria-hidden="true" style={{ filter: getTheme === "light" ? "invert(1)" : "none" }} />
                        </div>
                        <input
                            className="headerSearchInput"
                            type="text"
                            value={searchValue}
                            placeholder={Translations["headerSearch"][getLang]}
                            onChange={e => setSearchValue(e.target.value)}
                            onKeyDown={e => e.key === "Enter" && onSearchSubmit()}
                        />
                    </div>
                </div>
            </div>

            <div className="headerBtns">
                {(["notification", "download", "content", "language", "theme"] as const).map(type => {
                    const isActive = getContent === type

                    return (
                        <div
                            key={type}
                            ref={type === "download" || type === "theme" ? undefined : setTriggerRef(type)}
                            className={`headerBtn ${isActive ? "active" : ""} ${type === "download" && isDownloading ? "loading" : ""}`}
                            onClick={() => {
                                if (type === "theme") {
                                    const nextTheme: ThemeKey = getTheme === "dark" ? "light" : "dark"
                                    setTheme(nextTheme)
                                    localStorage.setItem("getTheme", nextTheme)
                                    setContent(null)
                                    return
                                }

                                if (type === "download") {
                                    setContent(isActive ? null : "download")
                                    return
                                }

                                const nextContent = isActive ? null : type
                                setContent(nextContent)

                                if (nextContent === "notification") {
                                    scheduleNotificationsLoad()
                                } else if (type === "notification") {
                                    clearNotificationDelayTimer()
                                    setNotificationsLoading(false)
                                }
                            }}
                            role="button"
                            aria-label={type === "theme" ? (getTheme === "dark" ? "Включить светлую тему" : "Включить тёмную тему") : type}
                            title={type === "theme" ? (getTheme === "dark" ? "Светлая тема" : "Тёмная тема") : undefined}
                        >
                            <img
                                className="headerSvgIcon"
                                src={iconByType[type]}
                                alt=""
                                aria-hidden="true"
                                style={{ filter: type !== "theme" && getTheme === "light" ? "invert(1)" : "none" }}
                            />
                            {type === "notification" && hasRecentNotification && (
                                <span className="notificationBadge" aria-hidden="true" />
                            )}
                        </div>
                    )
                })}

                <div
                    ref={setTriggerRef("profile")}
                    className="userAvatar"
                    onClick={() => setContent(getContent === "profile" ? null : "profile")}
                >
                    {
                        getAvatar !== "" ?
                            <img src={getAvatar} alt="avatar" />
                            :
                            <UserAvatarIcon
                                size="25px"
                                color={`rgb(${Theme[getTheme]["--text-color"]})`}
                            />
                    }
                </div>

                {getContent && getContent !== "download" && (
                    <div
                        ref={additionalAreaRef}
                        className={`additionalArea ${getContent === "notification" ? "notificationAdditionalArea" : ""}`}
                    >
                        {getContent === "notification" ? (
                            <CustomScroll className="notificationScroll">
                                <div className="notificationScrollContent">
                                    {contents(getContent)}
                                </div>
                            </CustomScroll>
                        ) : contents(getContent)}
                    </div>
                )}
            </div>

            {getContent === "download" && (
                <div className="downloadModalBackdrop" onMouseDown={() => !isDownloading && setContent(null)}>
                    <div className="downloadModal" onMouseDown={event => event.stopPropagation()}>
                        <div className="downloadModalHeader">
                            <div>
                                <div className="downloadModalTitle">Действующие фильтры</div>
                                <div className="downloadModalSubtitle">Будет выгружено записей: {getTotal}</div>
                            </div>
                            <button
                                type="button"
                                className="downloadModalClose"
                                onClick={() => setContent(null)}
                                disabled={isDownloading}
                                aria-label="Закрыть"
                            >
                                ×
                            </button>
                        </div>

                        <div className="downloadFilterList">
                            {activeFilters.length ? activeFilters.map(filter => (
                                <div className="downloadFilterRow" key={filter.key}>
                                    <span>{filter.label}</span>
                                    <strong>{filter.value}</strong>
                                </div>
                            )) : (
                                <div className="downloadNoFilters">Фильтры не выбраны</div>
                            )}
                        </div>

                        <button
                            type="button"
                            className="downloadConfirmBtn"
                            onClick={ExcelDownload}
                            disabled={isDownloading || getTotal === 0}
                        >
                            {isDownloading ? "Подготовка..." : "Скачать"}
                        </button>
                    </div>
                </div>
            )}
        </div>
    )
}