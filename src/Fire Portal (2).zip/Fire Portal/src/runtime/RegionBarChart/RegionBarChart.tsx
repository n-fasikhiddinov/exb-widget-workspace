/** @jsx jsx */
import { React, jsx } from "jimu-core";
import "./RegionBarChart.css";

import FeatureLayer from "@arcgis/core/layers/FeatureLayer";
import Query from "@arcgis/core/rest/support/Query";

import {
    buildWhereQuery,
    filterStruct,
    getDataValue,
    fullAccess
} from "../../assets/config";
import { LangKey, Translations } from "../../assets/translations";
import { Theme, ThemeKey } from "../../assets/theme";
import { ArrowIcon } from "../../assets/icons";
import CustomScroll from "../CustomScroll";
import MapView from "@arcgis/core/views/MapView";
import Extent from "@arcgis/core/geometry/Extent";
import { borders } from "../../assets/border";

interface RegionBarChartProps {
    getMap: MapView;
    getLang: LangKey;
    getTheme: ThemeKey;
    getFilter: filterStruct;
    setFilter: (value: any) => void;

    mainLayerRef: React.MutableRefObject<FeatureLayer>;
}

export default function RegionBarChart({
    getMap,
    getLang,
    getTheme,
    getFilter,
    setFilter,
    mainLayerRef,
}: RegionBarChartProps) {
    const [getRegionBarChartData, setRegionBarChartData] = React.useState<getDataValue[]>([]);
    const [getParentInfo, setParentInfo] = React.useState<DOMRect | null>(null);
    const [getRegionBarMaxCount, setRegionBarMaxCount] = React.useState<number>(0);

    const mainRegionBarDivRef = React.useRef<HTMLDivElement | null>(null);

    const currentField = React.useMemo<"region_id" | "distric_id">(() => {
        return getFilter.region_id === "" ? "region_id" : "distric_id";
    }, [getFilter.region_id]);

    const currentTitle = React.useMemo(() => {
        return Translations[
            `regionBarChart${getFilter.region_id ? "District" : "Region"}`
        ]?.[getLang] ?? "";
    }, [getFilter.region_id, getLang]);

    const toExtent = (value: string) => {
        const region = borders[value];
        if (!region) return;

        const extent = new Extent({
            xmin: region.extent[0],
            ymin: region.extent[1],
            xmax: region.extent[2],
            ymax: region.extent[3],
            spatialReference: { wkid: 4326 }
        });
        getMap.goTo(extent.expand(1.2));
    }

    React.useEffect(() => {
        if (!mainRegionBarDivRef.current) return;
        setParentInfo(mainRegionBarDivRef.current.getBoundingClientRect());
    }, []);

    React.useEffect(() => {
        const onResize = () => {
            if (!mainRegionBarDivRef.current) return;
            setParentInfo(mainRegionBarDivRef.current.getBoundingClientRect());
        };

        onResize();
        window.addEventListener("resize", onResize);

        return () => {
            window.removeEventListener("resize", onResize);
        };
    }, []);

    React.useEffect(() => {
        const layer: FeatureLayer = mainLayerRef.current;
        if (!layer) return;

        let cancelled = false;

        (async () => {
            try {
                await layer.load();
                const where = buildWhereQuery(getFilter, "region");
                const statField = "areaha";
                const groupField = currentField;

                const query = new Query({
                    where,
                    returnGeometry: true,
                    groupByFieldsForStatistics: [groupField],
                    orderByFields: ["count_area DESC"],
                    outStatistics: [
                        {
                            statisticType: "count",
                            onStatisticField: statField,
                            outStatisticFieldName: "count_area",
                        },
                        {
                            statisticType: "sum",
                            onStatisticField: statField,
                            outStatisticFieldName: "sum_area",
                        }
                    ],
                    outFields: [groupField],
                });

                const result = await layer.queryFeatures(query);
                if (cancelled) return;

                const rows: getDataValue[] = (result.features ?? [])
                    .map((feature: any) => {
                        const attrs = feature.attributes ?? {};
                        return {
                            name: String(attrs[groupField] ?? ""),
                            count_area: Number(attrs.count_area ?? 0),
                            sum_area: Number(attrs.sum_area ?? 0),
                        } as getDataValue;
                    })
                    .filter((item: any) => item.name !== "");

                const max = rows.reduce((acc, item) => {
                    return item.count_area > acc ? item.count_area : acc;
                }, 0);

                setRegionBarChartData(rows);
                setRegionBarMaxCount(max);
            } catch (error) {
                console.error("[RegionBarChart] query error:", error);
                setRegionBarChartData([]);
                setRegionBarMaxCount(0);
            }
        })();

        return () => {
            cancelled = true;
        };
    }, [getFilter, currentField, mainLayerRef]);

    const clickHandler = React.useCallback((item: getDataValue) => {
        const regionId = String(getFilter.region_id ?? "");
        const districtId = String(getFilter.distric_id ?? "");
        const itemName = String(item.name ?? "");

        if (!itemName) return;

        toExtent(itemName);

        if (regionId === "") {
            setFilter((prev: filterStruct) => ({
                ...prev,
                region_id: itemName,
                distric_id: "",
                day: "",
            }));
            return;
        }

        if (districtId !== itemName) {
            setFilter((prev: filterStruct) => ({
                ...prev,
                distric_id: itemName,
                day: "",
            }));
            return;
        }

        setFilter((prev: filterStruct) => ({
            ...prev,
            distric_id: "",
            day: "",
        }));
    }, [getFilter, setFilter, getMap]);

    const onBack = React.useCallback(() => {
        if (!getFilter.region_id) return;

        if (getFilter.distric_id) {
            toExtent(getFilter.region_id);
            setFilter((prev: filterStruct) => ({
                ...prev,
                distric_id: "",
            }));
            return;
        }

        setFilter((prev: filterStruct) => ({
            ...prev,
            region_id: fullAccess ? "" : prev["region_id"],
            distric_id: "",
            month: "",
            day: "",
        }));
        getMap.goTo({
            center: [65.361894, 41.809956],
            zoom: 6,
        });
    }, [getFilter, setFilter]);

    return (
        <div className="mainRegionBarChartArea" ref={mainRegionBarDivRef}>
            <div className="regionBarChartTitle">
                {currentTitle}

                {getFilter.region_id && (
                    <span>( {Translations[getFilter.region_id][getLang]} {Translations["regionPrefix"][getLang]} )</span>
                )}

                {getFilter.region_id !== "" && fullAccess && (
                    <div className="regionBarChartPrevBtn" onClick={onBack}>
                        <ArrowIcon
                            size="10px"
                            color={`rgb(${Theme[getTheme]["--color"]})`}
                        />
                    </div>
                )}
            </div>

            <CustomScroll
                className="regionBarChartScroll"
                style={{ width: "100%", flex: 1, minHeight: 0 }}
            >
                <div className="regionBarChartBlock">
                {getRegionBarChartData.map((item: getDataValue, index: number, arr: getDataValue[]) => {
                    const labelWidth = 140;
                    const valueWidth = 72;
                    const rowGap = 10;
                    const rowPaddingReserve = 36;

                    const widthBase = Math.max(
                        (getParentInfo?.width ?? 400) - labelWidth - valueWidth - rowGap - rowPaddingReserve,
                        80
                    );

                    const width =
                        getRegionBarMaxCount > 0
                            ? 10 + (Number(item.count_area) / getRegionBarMaxCount) * widthBase
                            : 10;

                    const translatedName =
                        Translations[item.name as LangKey]?.[getLang] ?? item.name;

                    return (
                        <div
                            className="regionBarChartRow"
                            key={`${item.name}-${index}`}
                            style={{ animationDelay: `${index * 15}ms` }}
                        >
                            <div className="regionBarChartValue">
                                {translatedName}
                            </div>

                            <div
                                title={`${translatedName}\n${Translations["indicatorCount"][getLang]}: ${item.count_area} ${Translations["countPrefix"][getLang]}\n${Translations["indicatorSum"][getLang]}: ${item.sum_area.toFixed(2)} ${Translations["areaPrefix"][getLang]}`}
                                style={{
                                    width: `${width}px`,
                                    backgroundColor: `hsl(${Theme[getTheme]["--main-color-hsl"]},
                                        ${currentField === "distric_id" && getFilter.distric_id !== "" ?
                                            item.name === getFilter.distric_id
                                                ? 60
                                                : 20
                                            : 35 + ((index + 1) / arr.length) * 55
                                        }%)
                                    `,
                                }}
                                className="regionBarChartBar"
                                onClick={() => clickHandler(item)}
                            />

                            <div className="regionBarChartOption">
                                {item.count_area} {Translations["countPrefix"][getLang]}
                            </div>
                        </div>
                    );
                })}
                </div>
            </CustomScroll>

            {Boolean(getRegionBarChartData.length) &&
                [6].map((item: number) => {
                    const labelWidth = 140;
                    const valueWidth = 72;
                    const rowPaddingReserve = 56;
                    const totalWidth = Math.max(
                        (getParentInfo?.width ?? 400) - labelWidth - valueWidth - rowPaddingReserve,
                        80
                    );
                    const gap = totalWidth / item;

                    const result = [];

                    for (let index = 0; index <= item; index++) {
                        result.push(
                            <div
                                key={index}
                                className="regionBarChartLines"
                                style={{ left: `${labelWidth + index * gap}px` }}
                            />
                        );
                    }

                    return result;
                })}
        </div>
    );
}