/** @jsx jsx */
import { React, jsx } from "jimu-core"
import FeatureLayer from "@arcgis/core/layers/FeatureLayer"
import Query from "@arcgis/core/rest/support/Query"

import { filterStruct, buildWhereQuery, parseFireDateText } from "../../assets/config"
import { Translations, LangKey } from "../../assets/translations"
import { ArrowIcon } from "../../assets/icons"
import { Theme, ThemeKey } from "../../assets/theme"
import "./LineChart.css"

interface LineChartProps {
    getLang: LangKey
    getTheme: ThemeKey
    getFilter: filterStruct
    setFilter: (value: any) => void
    mainLayerRef: React.MutableRefObject<FeatureLayer>
}

type GraphRow = {
    id: number
    date: string
    area_count: number
    area_sum: number
    [k: string]: any
}

type ViewMode = "months" | "days"
type ParsedDate = { year?: string; month?: string; day?: string }
type Pt = { x: number; y: number }

const ANIM_DURATION = 900

const CHART = {
    padding: { left: 56, right: 28, top: 5, bottom: 0 },

    dotted: { enabled: true, width: 1.6, dashLen: 6, gap: 8 },
    dotRing: { enabled: false },

    hover: { activeHoverAlpha: 0.7, innerScale: 1.25, ringScale: 1.18, dottedWidthScale: 1.25 },

    infoBox: {
        enabled: true,
        mode: "near" as "global" | "near",
        paddingX: 12, paddingY: 10, gap: 6, radius: 12,
        titleFont: "700 13px system-ui, -apple-system, Segoe UI, Roboto, Arial",
        itemFont: "600 12px system-ui, -apple-system, Segoe UI, Roboto, Arial",
        bg: "rgba(0,0,0,0.55)",
        maxWidthPct: 0.58, anchorPadding: 10, nearGap: 20, edgePad: 10,
    },

    curve: { smoothFactor: 1.0, clampControls: true },
    topText: { enabled: true, font: "700 12px system-ui, -apple-system, Segoe UI, Roboto, Arial", yOffset: 25, safeTop: 22 },

    lineWidth: 3,

    dot: {
        innerRadius: 9,
        activeScale: 1.42,
        gap: 2,
        ringWidth: 1,
        ringRadiusHoverAdd: 1,
        centerScale: 0.42,
    },

    label: {
        font: "600 12px system-ui, -apple-system, Segoe UI, Roboto, Arial",
        yOffset: 12,
        minBottomSpace: 82,
        activeFont: "700 13px system-ui, -apple-system, Segoe UI, Roboto, Arial",
    },

    axis: {
        xFont: "700 13px system-ui, -apple-system, Segoe UI, Roboto, Arial",
        yFont: "700 13px system-ui, -apple-system, Segoe UI, Roboto, Arial",
        xBottomGap: 44,
        yLeftGap: 22,
    },

    grid: { rows: 5, lineWidth: 1, alpha: 0.15, dash: [4, 8] as number[] },

    hitRadius: 18,

    region: {
        lineAlpha: 0.95,
        glowAlpha: 0.55,
        dottedAlpha: 0.25,
        areaTopAlpha: 0.22,
        areaBottomAlpha: 0.0,
        labelActiveAlpha: 1.0,
        labelDimAlpha: 0.55,
        activeLightness: 50,
        inactiveLightness: 12,
    },
} as const

const MONTHS_BY_LANG: Record<LangKey, Record<string, string>> = {
    RU: {
        "01": "Январь",
        "02": "Февраль",
        "03": "Март",
        "04": "Апрель",
        "05": "Май",
        "06": "Июнь",
        "07": "Июль",
        "08": "Август",
        "09": "Сентябрь",
        "10": "Октябрь",
        "11": "Ноябрь",
        "12": "Декабрь",
    },
    EN: {
        "01": "January",
        "02": "February",
        "03": "March",
        "04": "April",
        "05": "May",
        "06": "June",
        "07": "July",
        "08": "August",
        "09": "September",
        "10": "October",
        "11": "November",
        "12": "December",
    },
    UZ: {
        "01": "Yanvar",
        "02": "Fevral",
        "03": "Mart",
        "04": "Aprel",
        "05": "May",
        "06": "Iyun",
        "07": "Iyul",
        "08": "Avgust",
        "09": "Sentabr",
        "10": "Oktabr",
        "11": "Noyabr",
        "12": "Dekabr",
    },
}

const UI_TEXT: Record<LangKey, {
    xMonths: string
    xDays: string
    yCount: string
    count: string
    area: string
}> = {
    RU: {
        xMonths: "Месяцы",
        xDays: "Дни",
        yCount: "Количество",
        count: "Количество",
        area: "Площадь",
    },
    EN: {
        xMonths: "Months",
        xDays: "Days",
        yCount: "Count",
        count: "Count",
        area: "Area",
    },
    UZ: {
        xMonths: "Oylar",
        xDays: "Kunlar",
        yCount: "Soni",
        count: "Soni",
        area: "Maydon",
    },
}

const isNonEmpty = (v: any) => String(v ?? "").trim().length > 0

const pad2 = (v: string | number) => {
    const s = String(v)
    return s.length >= 2 ? s : `0${s}`
}

const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v))

const easeInOutCubic = (t: number) => {
    return t < 0.5
        ? 4 * t * t * t
        : 1 - Math.pow(-2 * t + 2, 3) / 2
}

function normalizeFilter(filter: filterStruct): Record<string, string> {
    const f: any = { ...filter }
    if (isNonEmpty(f.month)) f.month = pad2(f.month)
    if (isNonEmpty(f.day)) f.day = pad2(f.day)
    return f
}

function getViewMode(filter: filterStruct): ViewMode {
    return isNonEmpty((filter as any)?.month) ? "days" : "months"
}

function daysInMonth(year: number, month1to12: number) {
    return new Date(year, month1to12, 0).getDate()
}

function rgbCsvToRgba(csv: string, a: number) {
    const [r = 0, g = 0, b = 0] = csv.split(",").map(x => Number(x.trim()))
    return `rgba(${r},${g},${b},${a})`
}

function rgbCsvToRgb(csv: string) {
    const [r = 0, g = 0, b = 0] = csv.split(",").map(x => Number(x.trim()))
    return `rgb(${r},${g},${b})`
}

function withAlpha(color: string, a: number) {
    const s = color.replace(/\s+/g, "")
    const m = s.match(/^rgba?\((\d+),(\d+),(\d+)(?:,[0-9.]+)?\)$/i)
    return m ? `rgba(${m[1]},${m[2]},${m[3]},${a})` : color
}

function regionHsla(hsl: string, lightness: number, alpha: number) {
    return `hsla(${hsl}, ${lightness}%, ${alpha})`
}

function getMonthName(month: string, lang: LangKey): string {
    const safeLang: LangKey = MONTHS_BY_LANG[lang] ? lang : "RU"
    return MONTHS_BY_LANG[safeLang][month] ?? month
}

function getUIText(lang: LangKey) {
    return UI_TEXT[UI_TEXT[lang] ? lang : "RU"]
}

function parseRowDate(raw: string): ParsedDate {
    return parseFireDateText(raw)
}

function formatXLabel(p: ParsedDate, mode: ViewMode, lang: LangKey): string {
    if (mode === "months") {
        const mm = p.month ?? "01"
        return getMonthName(mm, lang)
    }

    const dd = p.day ?? "01"
    const n = Number(dd)
    return Number.isFinite(n) ? String(n) : dd
}

function buildFullDateText(p: ParsedDate, mode: ViewMode, filter: filterStruct, lang: LangKey): string {
    const fy = String((filter as any)?.year ?? "").trim()
    const fm = String((filter as any)?.month ?? "").trim()
    const y = fy || p.year || ""

    if (mode === "months") {
        const mm = p.month ?? "01"
        const name = getMonthName(mm, lang)
        return y ? `${name} ${y}` : name
    }

    const mm = pad2(fm || p.month || "01")
    const dd = p.day ?? "01"
    const monthName = getMonthName(mm, lang)

    return y ? `${Number(dd)} ${monthName} ${y}` : `${Number(dd)} ${monthName}`
}

function buildInfoItems(row: GraphRow, lang: LangKey) {
    const t = getUIText(lang)

    return [
        {
            label: t.count,
            value: Math.round(Number(row.area_count ?? 0)).toLocaleString(),
        },
        {
            label: t.area,
            value: Number(row.area_sum ?? 0).toLocaleString(undefined, {
                minimumFractionDigits: 0,
                maximumFractionDigits: 2,
            }),
        },
    ]
}

function pickExistingField(layer: FeatureLayer, candidates: string[]): string | null {
    const layerFields = (layer.fields ?? []).map(field => String(field.name))
    for (const candidate of candidates) {
        if (layerFields.includes(candidate)) {
            return candidate
        }
    }
    return null
}

function aggregateRows(
    features: any[],
    filter: filterStruct,
    mode: ViewMode,
    dateField: string,
    areaField: string,
): GraphRow[] {
    const normalized = normalizeFilter(filter)

    if (mode === "months") {
        const bucket = new Map<string, { area_count: number; area_sum: number }>()

        for (let i = 1; i <= 12; i++) {
            bucket.set(pad2(i), { area_count: 0, area_sum: 0 })
        }

        for (const feature of features) {
            const attrs = feature.attributes ?? {}
            const parsed = parseRowDate(String(attrs[dateField] ?? ""))
            const mm = parsed.month

            if (!mm) continue

            const prev = bucket.get(mm) ?? { area_count: 0, area_sum: 0 }
            prev.area_count += 1
            prev.area_sum += Number(attrs[areaField] ?? 0)
            bucket.set(mm, prev)
        }

        return Array.from({ length: 12 }, (_, i) => {
            const key = pad2(i + 1)
            const stat = bucket.get(key) ?? { area_count: 0, area_sum: 0 }

            return {
                id: i + 1,
                date: key,
                area_count: stat.area_count,
                area_sum: stat.area_sum,
            }
        })
    }

    const yearNum = Number(normalized.year || new Date().getFullYear())
    const monthNum = Number(normalized.month || 1)
    const dim = daysInMonth(
        Number.isFinite(yearNum) ? yearNum : new Date().getFullYear(),
        Number.isFinite(monthNum) ? monthNum : 1,
    )

    const bucket = new Map<string, { area_count: number; area_sum: number }>()

    for (let i = 1; i <= dim; i++) {
        bucket.set(pad2(i), { area_count: 0, area_sum: 0 })
    }

    for (const feature of features) {
        const attrs = feature.attributes ?? {}
        const rawDate = String(attrs[dateField] ?? "")
        const parsed = parseRowDate(rawDate)
        const dd = parsed.day

        if (!dd) continue

        const prev = bucket.get(dd) ?? { area_count: 0, area_sum: 0 }
        prev.area_count += 1
        prev.area_sum += Number(attrs[areaField] ?? 0)
        bucket.set(dd, prev)
    }

    return Array.from({ length: dim }, (_, i) => {
        const key = pad2(i + 1)
        const stat = bucket.get(key) ?? { area_count: 0, area_sum: 0 }

        return {
            id: i + 1,
            date: key,
            area_count: stat.area_count,
            area_sum: stat.area_sum,
        }
    })
}

function remapRowsForAnimation(prevRows: GraphRow[], nextRows: GraphRow[]): GraphRow[] {
    if (!prevRows.length) {
        return nextRows.map(row => ({
            ...row,
            area_count: 0,
            area_sum: 0,
        }))
    }

    if (prevRows.length === nextRows.length) {
        return prevRows.map(row => ({ ...row }))
    }

    const prevLastIndex = Math.max(prevRows.length - 1, 1)
    const nextLastIndex = Math.max(nextRows.length - 1, 1)

    return nextRows.map((nextRow, nextIndex) => {
        const position = (nextIndex / nextLastIndex) * prevLastIndex
        const leftIndex = Math.floor(position)
        const rightIndex = Math.min(prevRows.length - 1, Math.ceil(position))
        const mix = position - leftIndex

        const left = prevRows[leftIndex] ?? prevRows[prevRows.length - 1]
        const right = prevRows[rightIndex] ?? left

        const areaCount = Number(left.area_count) + (Number(right.area_count) - Number(left.area_count)) * mix
        const areaSum = Number(left.area_sum) + (Number(right.area_sum) - Number(left.area_sum)) * mix

        return {
            ...nextRow,
            area_count: areaCount,
            area_sum: areaSum,
        }
    })
}

function aggregateStatRows(
    features: any[],
    filter: filterStruct,
    mode: ViewMode,
    dateField: string,
): GraphRow[] {
    const normalized = normalizeFilter(filter)

    if (mode === "months") {
        const bucket = new Map<string, { area_count: number; area_sum: number }>()

        for (let i = 1; i <= 12; i++) {
            bucket.set(pad2(i), { area_count: 0, area_sum: 0 })
        }

        for (const feature of features) {
            const attrs = feature.attributes ?? {}
            const parsed = parseRowDate(String(attrs[dateField] ?? ""))
            const mm = parsed.month

            if (!mm) continue

            const prev = bucket.get(mm) ?? { area_count: 0, area_sum: 0 }
            prev.area_count += Number(attrs.area_count ?? 0)
            prev.area_sum += Number(attrs.area_sum ?? 0)
            bucket.set(mm, prev)
        }

        return Array.from({ length: 12 }, (_, i) => {
            const key = pad2(i + 1)
            const stat = bucket.get(key) ?? { area_count: 0, area_sum: 0 }

            return {
                id: i + 1,
                date: key,
                area_count: stat.area_count,
                area_sum: stat.area_sum,
            }
        })
    }

    const yearNum = Number(normalized.year || new Date().getFullYear())
    const monthNum = Number(normalized.month || 1)
    const dim = daysInMonth(
        Number.isFinite(yearNum) ? yearNum : new Date().getFullYear(),
        Number.isFinite(monthNum) ? monthNum : 1,
    )

    const bucket = new Map<string, { area_count: number; area_sum: number }>()

    for (let i = 1; i <= dim; i++) {
        bucket.set(pad2(i), { area_count: 0, area_sum: 0 })
    }

    for (const feature of features) {
        const attrs = feature.attributes ?? {}
        const parsed = parseRowDate(String(attrs[dateField] ?? ""))
        const dd = parsed.day

        if (!dd) continue

        const prev = bucket.get(dd) ?? { area_count: 0, area_sum: 0 }
        prev.area_count += Number(attrs.area_count ?? 0)
        prev.area_sum += Number(attrs.area_sum ?? 0)
        bucket.set(dd, prev)
    }

    return Array.from({ length: dim }, (_, i) => {
        const key = pad2(i + 1)
        const stat = bucket.get(key) ?? { area_count: 0, area_sum: 0 }

        return {
            id: i + 1,
            date: key,
            area_count: stat.area_count,
            area_sum: stat.area_sum,
        }
    })
}

async function fetchRowsArcGIS(
    layer: FeatureLayer,
    filter: filterStruct,
    mode: ViewMode,
): Promise<GraphRow[]> {
    await layer.load()

    const where = buildWhereQuery(filter, "graph")
    const dateField = pickExistingField(layer, ["fire_date", "date", "detected_date"])
    const areaField = pickExistingField(layer, ["areaha", "area", "area_ha", "area_m2"])

    if (!dateField || !areaField) return []

    const query = new Query({
        where,
        returnGeometry: false,
        groupByFieldsForStatistics: [dateField],
        outFields: [dateField],
        orderByFields: [`${dateField} ASC`],
        outStatistics: [
            {
                statisticType: "count",
                onStatisticField: areaField,
                outStatisticFieldName: "area_count",
            },
            {
                statisticType: "sum",
                onStatisticField: areaField,
                outStatisticFieldName: "area_sum",
            },
        ],
    })

    const result = await layer.queryFeatures(query)

    return aggregateStatRows(result.features ?? [], filter, mode, dateField)
}

function addMonotoneCurvePath(
    ctx: CanvasRenderingContext2D,
    pts: Pt[],
    smoothFactor: number,
    clampY?: { top: number; bottom: number },
) {
    if (pts.length < 2) return

    const n = pts.length
    const sf = clamp(smoothFactor, 0, 1)

    const d = pts.slice(0, -1).map((p, i) => {
        const dx = pts[i + 1].x - p.x
        return dx !== 0 ? (pts[i + 1].y - p.y) / dx : 0
    })

    const m: number[] = new Array(n)
    m[0] = d[0]
    m[n - 1] = d[n - 2]

    for (let i = 1; i < n - 1; i++) {
        m[i] = (d[i - 1] === 0 || d[i] === 0 || (d[i - 1] > 0) !== (d[i] > 0))
            ? 0
            : (d[i - 1] + d[i]) / 2
    }

    for (let i = 0; i < n - 1; i++) {
        if (d[i] === 0) {
            m[i] = 0
            m[i + 1] = 0
            continue
        }

        const a = m[i] / d[i]
        const b = m[i + 1] / d[i]
        const s = a * a + b * b

        if (s > 9) {
            const t = 3 / Math.sqrt(s)
            m[i] = t * a * d[i]
            m[i + 1] = t * b * d[i]
        }
    }

    for (let i = 0; i < n; i++) m[i] *= sf

    ctx.beginPath()
    ctx.moveTo(pts[0].x, pts[0].y)

    for (let i = 0; i < n - 1; i++) {
        const p1 = pts[i]
        const p2 = pts[i + 1]
        const dx = p2.x - p1.x

        const cp1y = p1.y + (m[i] * dx) / 3
        const cp2y = p2.y - (m[i + 1] * dx) / 3
        const c1y = clampY ? clamp(cp1y, clampY.top, clampY.bottom) : cp1y
        const c2y = clampY ? clamp(cp2y, clampY.top, clampY.bottom) : cp2y

        ctx.bezierCurveTo(p1.x + dx / 3, c1y, p2.x - dx / 3, c2y, p2.x, p2.y)
    }
}

function computeNearBoxXY(args: {
    px: number
    py: number
    boxW: number
    boxH: number
    canvasW: number
    canvasH: number
    plotTop: number
    plotBottom: number
    edgePad: number
    gap: number
}) {
    const { px, py, boxW, boxH, canvasW, canvasH, plotTop, plotBottom, edgePad, gap } = args

    let bx = px - boxW / 2
    let by = py - gap - boxH

    if (by < plotTop + 8) by = py + gap
    if (bx < edgePad) bx = px + gap
    if (bx + boxW > canvasW - edgePad) bx = px - gap - boxW

    bx = clamp(bx, edgePad, canvasW - boxW - edgePad)
    by = clamp(by, edgePad, canvasH - boxH - edgePad)
    by = clamp(by, edgePad, plotBottom - 6)

    return { bx, by }
}

function buildLineGradient(args: {
    ctx: CanvasRenderingContext2D
    plotLeft: number
    plotRight: number
    activeX: number | null
    activeColor: string
    inactiveColor: string
    spread: number
}) {
    const { ctx, plotLeft, plotRight, activeX, activeColor, inactiveColor, spread } = args

    const grad = ctx.createLinearGradient(plotLeft, 0, plotRight, 0)

    if (activeX === null || plotRight <= plotLeft) {
        grad.addColorStop(0, activeColor)
        grad.addColorStop(1, activeColor)
        return grad
    }

    const range = plotRight - plotLeft
    const center = clamp((activeX - plotLeft) / range, 0, 1)
    const left = clamp(center - spread, 0, 1)
    const right = clamp(center + spread, 0, 1)

    grad.addColorStop(0, inactiveColor)

    if (left > 0) grad.addColorStop(left, inactiveColor)
    grad.addColorStop(center, activeColor)
    if (right < 1) grad.addColorStop(right, inactiveColor)

    grad.addColorStop(1, inactiveColor)

    return grad
}

export default function LineChart({ getLang, getTheme, getFilter, setFilter, mainLayerRef }: LineChartProps) {
    const wrapRef = React.useRef<HTMLDivElement | null>(null)
    const canvasRef = React.useRef<HTMLCanvasElement | null>(null)
    const lastMouseRef = React.useRef<{ x: number; y: number } | null>(null)

    const targetRowsRef = React.useRef<GraphRow[]>([])
    const displayRowsRef = React.useRef<GraphRow[]>([])

    const [size, setSize] = React.useState({ w: 0, h: 0 })
    const [hoverIdx, setHoverIdx] = React.useState(-1)
    const [tick, setTick] = React.useState(0)
    const [renderMode, setRenderMode] = React.useState<ViewMode>(getViewMode(getFilter))

    const targetMode = getViewMode(getFilter)

    const colors = React.useMemo(() => {
        const t = Theme[getTheme]
        const activeCsv = String(t["--active-color"] ?? "54, 96, 231")
        const textCsv = String(t["--color"] ?? "255, 255, 255")
        const regionVal = String(t["--main-color-hsl"] ?? "194, 84.9%")

        return {
            activeSolid: rgbCsvToRgb(activeCsv),
            activeHover: rgbCsvToRgba(activeCsv, CHART.hover.activeHoverAlpha),

            line: regionHsla(regionVal, CHART.region.activeLightness, CHART.region.lineAlpha),
            lineInactive: regionHsla(regionVal, CHART.region.inactiveLightness, CHART.region.lineAlpha),

            lineGlow: regionHsla(regionVal, CHART.region.activeLightness, CHART.region.glowAlpha),
            lineGlowInactive: regionHsla(regionVal, CHART.region.inactiveLightness, CHART.region.glowAlpha),

            dotted: regionHsla(regionVal, CHART.region.activeLightness, CHART.region.dottedAlpha),
            dottedInactive: regionHsla(regionVal, CHART.region.inactiveLightness, CHART.region.dottedAlpha),

            areaTop: regionHsla(regionVal, CHART.region.activeLightness, CHART.region.areaTopAlpha),
            areaBottom: regionHsla(regionVal, CHART.region.activeLightness, CHART.region.areaBottomAlpha),

            text: rgbCsvToRgb(textCsv),
            textDim: rgbCsvToRgba(textCsv, CHART.region.labelDimAlpha),
            dotCenter: rgbCsvToRgba(textCsv, 0.85),
            dotCenterHover: rgbCsvToRgba(textCsv, 0.95),
        }
    }, [getTheme])

    React.useEffect(() => {
        if (!wrapRef.current) return

        const ro = new ResizeObserver(entries => {
            const cr = entries[0]?.contentRect
            if (cr) {
                setSize({
                    w: Math.max(0, Math.floor(cr.width)),
                    h: Math.max(0, Math.floor(cr.height)),
                })
            }
        })

        ro.observe(wrapRef.current)
        return () => ro.disconnect()
    }, [])

    React.useEffect(() => {
        let cancelled = false
        let rafId = 0

            ; (async () => {
                const layer = mainLayerRef?.current
                if (!layer) return

                let newRows: GraphRow[]

                try {
                    newRows = await fetchRowsArcGIS(layer, getFilter, targetMode)
                } catch (e) {
                    console.error("[LineChart] fetch error:", e)
                    return
                }

                if (cancelled) return

                targetRowsRef.current = newRows
                const fromRows = remapRowsForAnimation(displayRowsRef.current, newRows)

                setRenderMode(targetMode)

                const start = performance.now()

                const step = (now: number) => {
                    if (cancelled) return

                    const progress = Math.min((now - start) / ANIM_DURATION, 1)
                    const eased = easeInOutCubic(progress)

                    displayRowsRef.current = newRows.map((row, i) => {
                        const from = fromRows[i] ?? { ...row, area_count: 0, area_sum: 0 }

                        return {
                            ...row,
                            area_count: Number(from.area_count) + (Number(row.area_count) - Number(from.area_count)) * eased,
                            area_sum: Number(from.area_sum) + (Number(row.area_sum) - Number(from.area_sum)) * eased,
                        }
                    })

                    setTick(t => t + 1)

                    if (progress < 1) {
                        rafId = requestAnimationFrame(step)
                    }
                }

                rafId = requestAnimationFrame(step)
            })()

        return () => {
            cancelled = true
            cancelAnimationFrame(rafId)
        }
    }, [getFilter, targetMode, mainLayerRef])

    const points = React.useMemo(() => {
        const rows = displayRowsRef.current
        const { w, h: h0 } = size
        const n = rows.length

        const empty = {
            real: [] as Array<{ x: number; y: number; row: GraphRow; i: number; p: ParsedDate }>,
            curvePts: [] as Pt[],
            plot: { left: 0, right: 0, top: 0, bottom: 0, pw: 0, ph: 0 },
            labelY: 0,
            xAxisTitleY: 0,
            yAxisTitleX: 0,
            yAxisTitleY: 0,
            maxY: 0,
        }

        if (w <= 2 || h0 <= 2 || !n) return empty

        const pad = CHART.padding
        const bottomPad = Math.max(pad.bottom, CHART.label.minBottomSpace)

        const left = pad.left
        const right = w - pad.right
        const top = pad.top + (CHART.topText.enabled ? CHART.topText.safeTop : 0)
        const bottomPlot = h0 - bottomPad
        const pw = Math.max(1, right - left)
        const ph = Math.max(1, bottomPlot - top)
        const step = pw / n

        const vals = rows.map(r => Number(r.area_count ?? 0))
        const allZero = vals.every(v => v === 0)

        let yMin = 0
        let yMax = 1

        if (!allZero) {
            const rawMax = Math.max(...vals)
            yMin = 0
            yMax = rawMax > 0 ? rawMax : 1

            const yPad = yMax * 0.08
            yMax += yPad > 0 ? yPad : 1
        }

        const yScale = (v: number) => bottomPlot - ((v - yMin) / (yMax - yMin)) * ph

        const real = rows.map((row, i) => {
            const x = left + (i + 0.5) * step
            const y = yScale(Number(row.area_count ?? 0))
            const p = parseRowDate(row.date)

            if (renderMode === "days") p.day = pad2(row.date)
            else p.month = pad2(row.date)

            return { x, y, row, i, p }
        })

        const curvePts: Pt[] = [
            { x: left, y: real[0].y },
            ...real.map(rp => ({ x: rp.x, y: rp.y })),
            { x: left + n * step, y: real[real.length - 1].y },
        ]

        return {
            real,
            curvePts,
            plot: { left, right, top, bottom: bottomPlot, pw, ph },
            labelY: bottomPlot + CHART.label.yOffset,
            xAxisTitleY: bottomPlot + CHART.axis.xBottomGap,
            yAxisTitleX: CHART.axis.yLeftGap,
            yAxisTitleY: top + ph / 2,
            maxY: Math.min(...real.map(p => p.y)),
        }
    }, [size, renderMode, tick])

    const pickPoint = React.useCallback((mx: number, my: number) => {
        const { real } = points
        if (!real.length) return -1

        let best = -1
        let bestD = Infinity

        for (let i = 0; i < real.length; i++) {
            const dx = real[i].x - mx
            const dy = real[i].y - my
            const d = Math.sqrt(dx * dx + dy * dy)

            if (d < bestD) {
                bestD = d
                best = i
            }
        }

        return bestD <= CHART.hitRadius ? best : -1
    }, [points])

    React.useEffect(() => {
        if (!lastMouseRef.current) return
        setHoverIdx(pickPoint(lastMouseRef.current.x, lastMouseRef.current.y))
    }, [points, pickPoint])

    React.useEffect(() => {
        const canvas = canvasRef.current
        if (!canvas) return

        const ctx = canvas.getContext("2d")
        if (!ctx) return

        const { w, h } = size
        if (w <= 2 || h <= 2) return

        const dpr = Math.max(1, Math.floor(window.devicePixelRatio || 1))
        canvas.width = w * dpr
        canvas.height = h * dpr
        canvas.style.width = `${w}px`
        canvas.style.height = `${h}px`
        ctx.setTransform(dpr, 0, 0, dpr, 0, 0)

        const C = colors
        const T = getUIText(getLang)
        const { real, curvePts, plot, labelY, xAxisTitleY, yAxisTitleX, yAxisTitleY, maxY } = points
        const n = real.length

        ctx.clearRect(0, 0, w, h)

        if (!n || curvePts.length < 2) return

        const curveOpts = CHART.curve.clampControls
            ? { top: plot.top, bottom: plot.bottom }
            : undefined

        const selectedMonth = String((getFilter as any)?.month ?? "").trim()
        const selectedDay = String((getFilter as any)?.day ?? "").trim()

        const hasDaySelection = renderMode === "days" && selectedDay !== ""

        let activeDayIndex = -1
        if (hasDaySelection) {
            for (let i = 0; i < real.length; i++) {
                if (pad2(real[i].row.date) === pad2(selectedDay)) {
                    activeDayIndex = i
                    break
                }
            }
        }

        const activeDayX = activeDayIndex >= 0 ? real[activeDayIndex].x : null
        const gradientSpread = n > 1 ? Math.min(0.18, 1.6 / n) : 0.18

        const lineStrokeStyle = hasDaySelection
            ? buildLineGradient({
                ctx,
                plotLeft: plot.left,
                plotRight: plot.right,
                activeX: activeDayX,
                activeColor: C.line,
                inactiveColor: C.lineInactive,
                spread: gradientSpread,
            })
            : C.line

        const lineGlowStyle = hasDaySelection
            ? buildLineGradient({
                ctx,
                plotLeft: plot.left,
                plotRight: plot.right,
                activeX: activeDayX,
                activeColor: C.lineGlow,
                inactiveColor: C.lineGlowInactive,
                spread: gradientSpread,
            })
            : C.lineGlow

        ctx.save()
        ctx.lineWidth = CHART.grid.lineWidth
        ctx.setLineDash(CHART.grid.dash)
        ctx.strokeStyle = withAlpha(C.text, CHART.grid.alpha)
        for (let r = 0; r <= CHART.grid.rows; r++) {
            const y = plot.top + (plot.ph * r) / CHART.grid.rows
            ctx.beginPath()
            ctx.moveTo(plot.left, y)
            ctx.lineTo(plot.right, y)
            ctx.stroke()
        }
        ctx.restore()

        const areaGrad = ctx.createLinearGradient(0, maxY, 0, plot.bottom)
        areaGrad.addColorStop(0, C.areaTop)
        areaGrad.addColorStop(1, C.areaBottom)

        ctx.save()
        addMonotoneCurvePath(ctx, curvePts, CHART.curve.smoothFactor, curveOpts)
        ctx.lineTo(curvePts[curvePts.length - 1].x, plot.bottom)
        ctx.lineTo(curvePts[0].x, plot.bottom)
        ctx.closePath()
        ctx.clip()
        ctx.fillStyle = areaGrad
        ctx.fillRect(plot.left, plot.top, plot.pw, plot.ph)
        ctx.restore()

        ctx.save()
        ctx.globalAlpha = 0.55
        ctx.lineWidth = Math.max(1, CHART.lineWidth + 2)
        ctx.strokeStyle = lineGlowStyle
        ctx.lineJoin = "round"
        ctx.lineCap = "round"
        addMonotoneCurvePath(ctx, curvePts, CHART.curve.smoothFactor, curveOpts)
        ctx.stroke()
        ctx.restore()

        ctx.save()
        ctx.lineWidth = CHART.lineWidth
        ctx.lineJoin = "round"
        ctx.lineCap = "round"
        ctx.strokeStyle = lineStrokeStyle
        addMonotoneCurvePath(ctx, curvePts, CHART.curve.smoothFactor, curveOpts)
        ctx.stroke()
        ctx.restore()

        if (CHART.dotted.enabled) {
            for (let i = 0; i < n; i++) {
                const p = real[i]
                const isHover = i === hoverIdx
                const isActiveDay = renderMode === "days" && selectedDay !== "" && pad2(selectedDay) === pad2(p.row.date)
                const isActive = isActiveDay

                const lw = CHART.dotted.width * ((isHover || isActive) ? CHART.hover.dottedWidthScale : 1)

                ctx.save()
                ctx.globalAlpha = 1
                ctx.strokeStyle = hasDaySelection
                    ? (isHover || isActive ? C.line : C.lineInactive)
                    : C.line
                ctx.lineWidth = lw

                let y = p.y + 1
                while (y < plot.bottom) {
                    const yNext = y + CHART.dotted.dashLen
                    ctx.beginPath()
                    ctx.moveTo(p.x, y)
                    ctx.lineTo(p.x, Math.min(yNext, plot.bottom))
                    ctx.stroke()
                    y += CHART.dotted.dashLen + CHART.dotted.gap
                }

                ctx.restore()
            }
        }

        for (let i = 0; i < n; i++) {
            const { x, y } = real[i]
            const isHover = i === hoverIdx
            const isActiveDay = renderMode === "days" && selectedDay !== "" && pad2(selectedDay) === pad2(real[i].row.date)
            const isActive = isActiveDay

            const innerR = CHART.dot.innerRadius * (
                isHover
                    ? CHART.hover.innerScale
                    : isActive
                        ? CHART.dot.activeScale
                        : 1
            )

            ctx.save()
            ctx.globalAlpha = 1

            if (CHART.dotRing.enabled) {
                const ringR = (innerR + CHART.dot.gap + CHART.dot.ringWidth + (isHover ? CHART.dot.ringRadiusHoverAdd : 0))
                    * (isHover ? CHART.hover.ringScale : isActive ? 1.08 : 1)

                ctx.beginPath()
                ctx.arc(x, y, ringR, 0, Math.PI * 2)
                ctx.strokeStyle = hasDaySelection
                    ? (isHover || isActive ? C.line : C.lineInactive)
                    : C.line
                ctx.lineWidth = CHART.dot.ringWidth * (isHover ? 1.05 : 1)
                ctx.stroke()

                ctx.globalCompositeOperation = "destination-out"
                ctx.beginPath()
                ctx.arc(x, y, innerR + CHART.dot.gap, 0, Math.PI * 2)
                ctx.fill()
                ctx.globalCompositeOperation = "source-over"
            }

            ctx.beginPath()
            ctx.arc(x, y, innerR, 0, Math.PI * 2)
            ctx.fillStyle = hasDaySelection
                ? (isHover || isActive ? C.line : C.lineInactive)
                : C.line
            ctx.fill()

            ctx.beginPath()
            ctx.arc(x, y, Math.max(2.2, innerR * CHART.dot.centerScale), 0, Math.PI * 2)
            ctx.fillStyle = isHover || isActive ? C.dotCenterHover : C.dotCenter
            ctx.fill()

            ctx.restore()
        }

        if (CHART.topText.enabled) {
            ctx.save()
            ctx.textAlign = "center"
            ctx.textBaseline = "middle"

            for (let i = 0; i < n; i++) {
                const p = real[i]
                const txt = Math.round(Number(p.row.area_count ?? 0)).toLocaleString()

                const isActiveDay = renderMode === "days" && selectedDay !== "" && pad2(selectedDay) === pad2(p.row.date)
                const dim = renderMode === "days" ? (selectedDay !== "" && !isActiveDay) : false

                ctx.font = isActiveDay ? CHART.label.activeFont : CHART.topText.font
                ctx.fillStyle = C.text
                ctx.globalAlpha = hasDaySelection
                    ? (i === hoverIdx || isActiveDay ? 1 : (dim ? 0.42 : 0.62))
                    : 1
                ctx.fillText(txt, p.x, clamp(p.y - CHART.topText.yOffset, 10, plot.bottom - 10))
                ctx.globalAlpha = 1
            }

            ctx.restore()
        }

        {
            ctx.save()
            ctx.textAlign = "center"
            ctx.textBaseline = "middle"

            for (let i = 0; i < n; i++) {
                const p = real[i]
                const lbl = formatXLabel(p.p, renderMode, getLang)

                const isActiveDay = renderMode === "days" && selectedDay !== "" && pad2(selectedDay) === pad2(p.row.date)
                const dim = renderMode === "days" ? (selectedDay !== "" && !isActiveDay) : false

                ctx.font = isActiveDay ? CHART.label.activeFont : CHART.label.font
                ctx.fillStyle = C.text
                ctx.globalAlpha = hasDaySelection
                    ? (i === hoverIdx || isActiveDay ? 1 : (dim ? 0.38 : 0.62))
                    : 1
                ctx.fillText(lbl, p.x, clamp(labelY, plot.bottom + 14, h - 10))
                ctx.globalAlpha = 1
            }

            ctx.restore()
        }

        ctx.save()
        ctx.textAlign = "center"
        ctx.textBaseline = "middle"
        ctx.font = CHART.axis.xFont
        ctx.fillStyle = C.text
        ctx.fillText(renderMode === "months" ? T.xMonths : T.xDays, plot.left + plot.pw / 2, xAxisTitleY)
        ctx.restore()

        ctx.save()
        ctx.translate(yAxisTitleX, yAxisTitleY)
        ctx.rotate(-Math.PI / 2)
        ctx.textAlign = "center"
        ctx.textBaseline = "middle"
        ctx.font = CHART.axis.yFont
        ctx.fillStyle = C.text
        ctx.fillText(T.yCount, 0, 0)
        ctx.restore()

        if (CHART.infoBox.enabled && hoverIdx >= 0 && hoverIdx < n) {
            const hp = real[hoverIdx]
            const title = buildFullDateText(hp.p, renderMode, getFilter, getLang)
            const items = buildInfoItems(hp.row, getLang)
            const ib = CHART.infoBox

            ctx.save()

            const maxW = Math.floor(w * ib.maxWidthPct)
            ctx.font = ib.titleFont
            let contentW = Math.min(maxW, Math.ceil(ctx.measureText(title).width))

            ctx.font = ib.itemFont
            for (const it of items) {
                contentW = Math.min(maxW, Math.max(contentW, Math.ceil(ctx.measureText(`${it.label}: ${it.value}`).width)))
            }

            const boxW = ib.paddingX * 2 + contentW
            const boxH = ib.paddingY * 2 + 18 + (items.length ? ib.gap + items.length * 16 : 0)

            let bx: number
            let by: number

            if (ib.mode === "global") {
                bx = clamp(plot.right - boxW - ib.anchorPadding, 8, w - boxW - 8)
                by = clamp(plot.top - (CHART.topText.enabled ? CHART.topText.safeTop : 0), 8, h - boxH - 8)
            } else {
                const near = computeNearBoxXY({
                    px: hp.x,
                    py: hp.y,
                    boxW,
                    boxH,
                    canvasW: w,
                    canvasH: h,
                    plotTop: plot.top,
                    plotBottom: plot.bottom,
                    edgePad: ib.edgePad,
                    gap: ib.nearGap,
                })
                bx = near.bx
                by = near.by
            }

            const r = ib.radius
            ctx.fillStyle = ib.bg
            ctx.beginPath()
            ctx.moveTo(bx + r, by)
            ctx.arcTo(bx + boxW, by, bx + boxW, by + boxH, r)
            ctx.arcTo(bx + boxW, by + boxH, bx, by + boxH, r)
            ctx.arcTo(bx, by + boxH, bx, by, r)
            ctx.arcTo(bx, by, bx + boxW, by, r)
            ctx.closePath()
            ctx.fill()

            ctx.textAlign = "left"
            ctx.textBaseline = "middle"

            let ty = by + ib.paddingY + 9
            ctx.font = ib.titleFont
            ctx.fillStyle = "rgba(255,255,255,0.95)"
            ctx.fillText(title, bx + ib.paddingX, ty)

            ty += 18 + (items.length ? ib.gap : 0)
            ctx.font = ib.itemFont
            ctx.fillStyle = "rgba(255,255,255,0.9)"

            for (const it of items) {
                ctx.fillText(`${it.label}: ${it.value}`, bx + ib.paddingX, ty)
                ty += 16
            }

            ctx.restore()
        }

        void selectedMonth
    }, [points, size, hoverIdx, getFilter, renderMode, colors, getLang])

    const onMouseMove = React.useCallback((e: React.MouseEvent) => {
        const rect = (e.currentTarget as HTMLCanvasElement).getBoundingClientRect()
        const x = e.clientX - rect.left
        const y = e.clientY - rect.top
        lastMouseRef.current = { x, y }
        setHoverIdx(pickPoint(x, y))
    }, [pickPoint])

    const onMouseLeave = React.useCallback(() => setHoverIdx(-1), [])

    const onClick = React.useCallback((e: React.MouseEvent) => {
        const rect = (e.currentTarget as HTMLCanvasElement).getBoundingClientRect()
        const x = e.clientX - rect.left
        const y = e.clientY - rect.top
        lastMouseRef.current = { x, y }

        const idx = pickPoint(x, y)
        if (idx < 0 || idx >= points.real.length) return

        setHoverIdx(idx)

        const row = points.real[idx].row

        if (renderMode === "months") {
            const mm = pad2(row.date)
            setFilter((prev: filterStruct) => {
                const cur = pad2(String((prev as any).month ?? "").trim())
                return cur === mm
                    ? { ...(prev as any), month: "", day: "" }
                    : { ...(prev as any), month: mm, day: "" }
            })
        } else {
            const dd = pad2(row.date)
            setFilter((prev: filterStruct) => {
                const cur = pad2(String((prev as any).day ?? "").trim())
                return cur === dd
                    ? { ...(prev as any), day: "" }
                    : { ...(prev as any), day: dd }
            })
        }
    }, [pickPoint, points.real, renderMode, setFilter])

    return (
        <div className="lineChartArea">
            <div className="lineChartHeader">
                <div
                    className={`lineChartTitlePrevBtn ${getFilter["month"] !== "" ? "enter" : ""}`}
                    onClick={() => setFilter((prev: filterStruct) => ({ ...prev, month: "", day: "" } as filterStruct))}
                >
                    <ArrowIcon size="20px" color={`rgb(${Theme[getTheme]["--color"]})`} />
                </div>

                <div className="lineChartTitle">
                    {Translations[getFilter["month"] === "" ? "graphicTitleMonths" : "graphicTitleDays"][getLang as LangKey]}
                </div>
            </div>

            <div ref={wrapRef} className="lineChartCanvasArea">
                <canvas
                    ref={canvasRef}
                    onMouseMove={onMouseMove}
                    onMouseLeave={onMouseLeave}
                    onClick={onClick}
                    style={{ cursor: hoverIdx >= 0 ? "pointer" : "default" }}
                    className="lineChartBlock"
                />
            </div>
        </div>
    )
}