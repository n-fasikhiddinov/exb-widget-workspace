/** @jsx jsx */
import { React, jsx, AllWidgetProps, DataSourceManager } from "jimu-core";
import type { FeatureLayerDataSource } from "jimu-core";
import MapView from "@arcgis/core/views/MapView";
import FeatureLayer from "@arcgis/core/layers/FeatureLayer";
import Query from "@arcgis/core/rest/support/Query.js";

import "./style.css";

import {
    otherColors,
    Theme,
    ThemeKey,
} from "../assets/theme";
import {
    buildWhereQuery,
    filterStruct,
    selectedPolyStruct,
    uniqueIdField,
    region,
    setAccessConfig
} from "../assets/config";
import { LangKey, Translations } from "../assets/translations";

import Header from "./Header/Header";
import Selector, { SelectorOption } from "./Selector/Selector";
import CustomMap from "./CustomMap/CustomMap";
import RegionBarChart from "./RegionBarChart/RegionBarChart";
import Indicators from "./Indicators/Indicators";
import LineChart from "./LineChart/LineChart";
import Table from "./Table/Table";
import StatusBarChart from "./StatusBarChart/StatusBarChart";

export default function Widget(props: AllWidgetProps<any>) {
    setAccessConfig(props.config?.accessConfig);

    const selectedLayerDataSourceId = props.useDataSources?.[0]?.dataSourceId ?? "";
    const getSymbol = (rgb: string) => {
        const color = rgb.split(",").map(Number);

        return {
            type: "simple-fill" as const,
            color: [...color, 0.1],
            outline: {
                type: "simple-line" as const,
                color: [...color, 1],
                width: 3,
            },
        };
    };

    const fireStatuses = [
        ["in_process", otherColors["--in-process"]],
        ["not_confirmed", otherColors["--no-confirmed-color"]],
        ["confirmed", otherColors["--confirmed-color"]],
    ] as const;

    const layerRenderer = React.useMemo<any>(() => ({
        type: "unique-value",
        valueExpression: `
            var v = $feature.fire_present;

            return When(
                IsEmpty(v), "in_process",
                v == true || v == 1, "confirmed",
                v == false || v == 0, "not_confirmed",
                "in_process"
            );
        `,
        uniqueValueInfos: fireStatuses.map(([value, color]) => ({
            value,
            symbol: getSymbol(color),
        })),
        defaultSymbol: getSymbol(otherColors["--in-process"]),
    }), []);

    const mainDateRef = React.useRef<FeatureLayer>(
        null as unknown as FeatureLayer
    );

    const [isDataLayerReady, setIsDataLayerReady] = React.useState<boolean>(false);
    const [dataLayerError, setDataLayerError] = React.useState<string>("");

    const regionLayerRef = React.useRef<FeatureLayer>(new FeatureLayer({
        id: "fieldfire-region",
        url: "https://sgm.uzspace.uz/server/rest/services/Viloyat_chegara/FeatureServer/0",
        renderer: {
            type: "simple" as const,
            symbol: {
                type: "simple-fill" as const,
                color: [255, 255, 255, 0.1],
                outline: {
                    type: "simple-line" as const,
                    color: [255, 255, 255, 0.95],
                    width: 2,
                },
            },
        },

        visible: true,
        opacity: 1,

        minScale: 0,
        maxScale: 3000000,
    }));

    const districtLayerRef = React.useRef<FeatureLayer>(new FeatureLayer({
        id: "fieldfire-district",
        url: "https://sgm.uzspace.uz/server/rest/services/Tuman_Chegara/FeatureServer/0",
        renderer: {
            type: "simple" as const,
            symbol: {
                type: "simple-fill" as const,
                color: [255, 255, 255, 0.1],
                outline: {
                    type: "simple-line" as const,
                    color: [255, 255, 255, 0.95],
                    width: 2,
                },
            },
        },

        visible: true,
        opacity: 1,

        minScale: 3000000,
        maxScale: 0,
    }));

    React.useEffect(() => {
        let isActive = true;

        const applySelectedFeatureLayer = async (): Promise<void> => {
            setIsDataLayerReady(false);
            setDataLayerError("");

            if (selectedLayerDataSourceId === "") {
                setDataLayerError("Выберите Feature Layer в настройках виджета.");
                return;
            }

            try {
                const dataSource = await DataSourceManager
                    .getInstance()
                    .createDataSourceByUseDataSource(props.useDataSources[0]);

                const selectedLayer = await (
                    dataSource as FeatureLayerDataSource
                ).createJSAPILayerByDataSource(
                    dataSource,
                    false,
                    true
                ) as FeatureLayer;

                if (!isActive || !selectedLayer) {
                    return;
                }

                selectedLayer.id = "mainLayer";
                selectedLayer.title = selectedLayer.title || "Fire objects";
                selectedLayer.outFields = [
                    "objectid",
                    "uniqueid",
                    "coordinate",
                    "region",
                    "district",
                    "mfy",
                    "fire_date",
                    "year",
                    "areaha",
                    "region_id",
                    "distric_id",
                    "mfy_id",
                    "type_id",
                    "search_id",
                    "link",
                    "raster",
                    "inspection_id",
                    "inspector_id",
                    "inspector_name",
                    "inspection_date",
                    "inspection_result",
                    "fire_present",
                    "notes",
                    "photo_paths",
                    "photo_uploaded",
                    "court_decision_uploaded",
                    "damage_amount",
                    "fine_amount",
                    "dalolatnoma_path",
                    "sud_qarori_path",
                    "inspection_created_at",
                    "inspection_updated_at",
                    "inspection_uniqueid"
                ];
                selectedLayer.renderer = layerRenderer;
                selectedLayer.visible = true;
                selectedLayer.opacity = 1;

                mainDateRef.current = selectedLayer;
                setIsDataLayerReady(true);
            } catch (error) {
                if (!isActive) {
                    return;
                }

                console.error("[Widget data source]:", error);
                setDataLayerError("Не удалось загрузить выбранный Feature Layer.");
            }
        };

        void applySelectedFeatureLayer();

        return () => {
            isActive = false;
        };
    }, [selectedLayerDataSourceId, layerRenderer]);

    const [getMap, setMap] = React.useState<MapView | null>(null);
    // const [getLang, setLang] = React.useState<LangKey>("RU" as LangKey);
    const [getLang, setLang] = React.useState<LangKey>(localStorage.getItem("getLang") ?? "RU" as LangKey);
    // const [getTheme, setTheme] = React.useState<ThemeKey>("darker" as ThemeKey);
    const [getTheme, setTheme] = React.useState<ThemeKey>(localStorage.getItem("getTheme") ?? "dark" as ThemeKey);


    const getTypeLabel = React.useCallback((typeId: string | number): string => {
        const id = String(typeId);
        const labels: Record<string, Record<LangKey, string>> = {
            "6": { UZ: "Bug‘doy", RU: "Пшеница", EN: "Wheat" },
            "13": { UZ: "Sholi", RU: "Рис", EN: "Rice" },
        };

        return labels[id]?.[getLang] ?? `${Translations["type"][getLang]} ID: ${id}`;
    }, [getLang]);

    const [getSelected, setSelected] = React.useState<selectedPolyStruct>({
        [uniqueIdField]: ""
    });

    const [getFilter, setFilter] = React.useState<filterStruct>({
        type_id: "",
        region_id: region === "1=0" ? "" : region,
        distric_id: "",
        year: "2026",
        month: "",
        day: "",
        fire_present: "",
    } as filterStruct);

    const [getSummary, setSummary] = React.useState({
        count: 0,
        sum: 0
    });

    const [filterSelector, setFilterSelector] = React.useState<{
        year: string[];
        type_id: Array<string | number>;
    }>({
        year: [],
        type_id: [],
    });
    console.log(getFilter);
    
    React.useEffect(() => {
        if (!isDataLayerReady || !mainDateRef.current) return;

        mainDateRef.current.queryFeatures(new Query({
            // where: buildWhereQuery(getFilter, "map"),
            where: "1=1",
            returnGeometry: false,
            groupByFieldsForStatistics: ["year", "type_id"],
            outStatistics: [
                {
                    statisticType: "count",
                    onStatisticField: "areaha",
                    outStatisticFieldName: "count",
                }
            ]
        }))
            .then((result: any) => {
                setFilterSelector({
                    year: [...new Set(result.features.map((item: any) => item.attributes.year).filter(Boolean))],
                    type_id: [...new Set(result.features.map((item: any) => item.attributes.type_id).filter(Boolean))],
                });
            })
            .catch((error: any) => {
                console.error("[Widget] selector query error:", error);
            });
    }, [isDataLayerReady]);

    React.useEffect(() => {
        if (!isDataLayerReady || !mainDateRef.current) return;

        const where = buildWhereQuery(getFilter, "map");

        mainDateRef.current.queryFeatures(new Query({
            where,
            returnGeometry: false,
            outStatistics: [
                {
                    statisticType: "count",
                    onStatisticField: "areaha",
                    outStatisticFieldName: "count",
                },
                {
                    statisticType: "sum",
                    onStatisticField: "areaha",
                    outStatisticFieldName: "sum",
                },
            ]
        }))
            .then((result: any) => {
                setSummary({
                    count: result.features?.[0]?.attributes?.count ?? 0,
                    sum: result.features?.[0]?.attributes?.sum ?? 0,
                });
            })
            .catch((error: any) => {
                console.error("[Widget] summary query error:", error);
                setSummary({ count: 0, sum: 0 });
            });
    }, [getFilter, isDataLayerReady]);

    const typeOptions: SelectorOption[] = filterSelector.type_id
        .map((typeId) => ({
            value: typeId,
            label: getTypeLabel(typeId),
        }))
        .sort((a, b) => a.label.localeCompare(b.label));

    if (!isDataLayerReady) {
        return (
            <div
                className="mainArea"
                style={{
                    ...Theme[getTheme as ThemeKey],
                    backgroundImage: `url(${Theme[getTheme as ThemeKey]["--background-img"]})`
                }}
            >
                <div className="dataLayerMessage">
                    {dataLayerError || "Загрузка выбранного слоя..."}
                </div>
            </div>
        );
    }

    return (
        <div
            className="mainArea"
            style={{
                ...Theme[getTheme as ThemeKey],
                backgroundImage: `url(${Theme[getTheme as ThemeKey]["--background-img"]})`
            }}
        >
            <Header
                mainDateRef={mainDateRef}
                getLang={getLang}
                setLang={(value: LangKey) => setLang(value)}
                getTheme={getTheme}
                setTheme={(value: ThemeKey) => setTheme(value)}
                setSelected={setSelected}
                getFilter={getFilter}
                getTotal={getSummary.count}
            />

            <div className="section1">
                <div className="filterBlock">
                    <div className="selectors">
                        <Selector
                            name={Translations["yearsSelector"][getLang as LangKey]}
                            value={getFilter["year"]}
                            options={filterSelector["year"]}
                            onChange={(value: string | number | null) => {
                                setFilter((prev: any) => ({
                                    ...prev,
                                    year: value,
                                }));
                            }}
                        />

                        <Selector
                            name={Translations["typesSelector"][getLang as LangKey]}
                            value={getFilter["type_id"]}
                            options={typeOptions}
                            onChange={(value: string | number | null) => {
                                setFilter((prev: any) => ({
                                    ...prev,
                                    type_id: value == null ? "" : value,
                                }));
                            }}
                        />
                    </div>
                    <RegionBarChart
                        getLang={getLang}
                        getTheme={getTheme}
                        getFilter={getFilter}
                        setFilter={setFilter}
                        getMap={getMap}
                        mainLayerRef={mainDateRef}
                    />
                    <Indicators
                        getFilter={getFilter}
                        getLang={getLang}
                        getIndicatorsData={getSummary}
                    />
                </div>

                <CustomMap
                    getLang={getLang}
                    getTheme={getTheme}
                    getFilter={getFilter}
                    getSelected={getSelected}
                    setMap={setMap}
                    setSelected={setSelected}
                    mainLayerRef={mainDateRef}
                    regionLayerRef={regionLayerRef}
                    districtLayerRef={districtLayerRef}
                />
            </div>
            <div className="section2">
                <LineChart
                    getLang={getLang}
                    getTheme={getTheme}
                    getFilter={getFilter}
                    setFilter={setFilter}
                    mainLayerRef={mainDateRef}
                />
                <Table
                    getTheme={getTheme}
                    getLang={getLang}
                    getFilter={getFilter}
                    getSelected={getSelected?.uniqueid ?? null}
                    setSelected={(value) => {
                        setSelected(value ? { uniqueid: value } : { uniqueid: "" })
                    }}
                    getTotal={getSummary.count}
                    mainLayerRef={mainDateRef}
                />
                <StatusBarChart
                    getLang={getLang}
                    getTheme={getTheme}
                    getFilter={getFilter}
                    setFilter={setFilter}
                    mainLayerRef={mainDateRef}
                />
            </div>
        </div>
    );
}