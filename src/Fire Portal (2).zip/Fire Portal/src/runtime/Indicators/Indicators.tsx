import { React } from "jimu-core";
import { filterStruct } from "../../assets/config";
import { Translations, LangKey } from "../../assets/translations";
import "./Indicators.css";

interface IndicatorsProps {
    getFilter: filterStruct;
    getLang: LangKey;
    getIndicatorsData: any
}

export default function Indicators({ getFilter, getLang, getIndicatorsData }: IndicatorsProps) {
    const [animatedIndicatorsData, setAnimatedIndicatorsData] = React.useState({
        count: 0,
        sum: 0,
    });

    React.useEffect(() => {

    }, [getFilter]);

    React.useEffect(() => {
        const duration = 300;
        const startTime = performance.now();

        const startValues = { ...animatedIndicatorsData };
        const endValues = {
            count: Number(getIndicatorsData.count) || 0,
            sum: Number(getIndicatorsData.sum) || 0,
        };

        let frameId: number;

        const formatAnimatedValue = (
            value: number,
            keepFloat: boolean,
            digits = 2,
        ): number => {
            if (!keepFloat) {
                return Math.round(value);
            }

            return Number(value.toFixed(digits));
        };

        const updateValues = (currentTime: number) => {
            const elapsed = currentTime - startTime;
            const progress = Math.min(elapsed / duration, 1);

            const nextCountArea =
                startValues.count +
                (endValues.count - startValues.count) * progress;

            const nextSumArea =
                startValues.sum +
                (endValues.sum - startValues.sum) * progress;

            setAnimatedIndicatorsData({
                count: formatAnimatedValue(nextCountArea, false),
                sum: formatAnimatedValue(nextSumArea, true, 2),
            });

            if (progress < 1) {
                frameId = requestAnimationFrame(updateValues);
            }
        };

        frameId = requestAnimationFrame(updateValues);

        return () => cancelAnimationFrame(frameId);
    }, [getIndicatorsData]);

    return (
        <div className="IndicatorsArea">
            <div className="IndicatorsBlock">
                <div className="IndicatorsTitle">
                    {Translations["indicatorTitle"][getLang]}
                </div>

                <div className="IndicatorsInfoBlock">
                    <div className="IndicatorsValue">
                        {animatedIndicatorsData.count} {Translations["countPrefix"][getLang]}
                    </div>
                    <div className="IndicatorsName">
                        {Translations["indicatorCount"][getLang]}
                    </div>
                </div>

                <div className="IndicatorsInfoBlock">
                    <div className="IndicatorsValue">
                        {animatedIndicatorsData.sum} {Translations["areaPrefix"][getLang]}
                    </div>
                    <div className="IndicatorsName">
                        {Translations["indicatorSum"][getLang]}
                    </div>
                </div>
            </div>
        </div>
    );
}