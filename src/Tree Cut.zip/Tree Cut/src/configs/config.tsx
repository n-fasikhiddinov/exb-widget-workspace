export const uniqueIdField = "mgrs"
export const uniqueIdQuery = (value: string) => `${uniqueIdField} = '${value}'`

export interface filterStruct {
    id_country: string
    id_region: string
    id_distric: string
    from_date: string
    to_date: string
    status: string
}

const escapeSqlString = (value: string): string => {
    if( !value ) return ""
    return value.replace(/'/g, "''")
}

export const buildWhereQuery = (filter: filterStruct): string => {
    const conditions: string[] = []

    if (filter.id_country !== "") {
        conditions.push(`id_country = ${escapeSqlString(filter.id_country)}`)
    }

    if (filter.id_region !== "") {
        conditions.push(`id_region = ${escapeSqlString(filter.id_region)}`)
    }

    if (filter.id_distric !== "") {
        conditions.push(`id_distric = ${escapeSqlString(filter.id_distric)}`)
    }

    if (filter.status !== "") {
        conditions.push(`status = ${filter.status}`)
    }

    if (filter.from_date !== "" && filter.to_date !== "") {
        conditions.push(
            `date >= DATE '${escapeSqlString(filter.from_date)}' AND date <= DATE '${escapeSqlString(filter.to_date)}'`
        )
    } else if (filter.from_date !== "") {
        conditions.push(`date >= DATE '${escapeSqlString(filter.from_date)}'`)
    } else if (filter.to_date !== "") {
        conditions.push(`date <= DATE '${escapeSqlString(filter.to_date)}'`)
    }

    return conditions.length > 0 ? conditions.join(" AND ") : "1=1"
}