export type CSSVars = Record<`--${string}`, string>;

const otherStyles: CSSVars = {
    "--main-border-radius": "20px",
    "--main-x-padding": "20px",
    "--main-y-padding": "20px",
    "--header-height": "60px",
    "--content-height": "400px",

    
    "--confirmed-color": "0, 172, 79", // #00AC4F rgb(0, 172, 79)
    "--no-confirmed-color": "225, 241, 49", // #E1F131 rgb(225, 241, 49)
    "--in-process-color": "72, 197, 66", // #48C542 rgb(72, 197, 66)

    // "--confirmed-color": "225, 241, 49", // #e1f131
    // "--no-confirmed-color": "246, 144, 109", // #F6906DCC
    // "--in-process-color": "250, 250, 238", // #f5faeecc
}

export type ThemeKey = "main" | "auto";

export const Theme: Record<ThemeKey, CSSVars> = {
    "main": {
        ...otherStyles,
        "--area-color": "217, 219, 202", // #D9DBCA
        "--main-color": "50, 59, 35", // #323b23
        "--text-color": "252, 254, 238", // #fcfeee
        "--active-text-color": "17, 24, 39", // #111827
    },
    "auto": {
        ...otherStyles,
        "--area-color": "217, 219, 202", // #D9DBCA
        "--main-color": "50, 59, 35", // #323b23
        "--text-color": "252, 254, 238", // #fcfeee
        "--active-text-color": "17, 24, 39", // #111827
    }
}

// ===== Утилиты =====

export const parseRgb = (rgb: string): [number, number, number] => {
    const m = rgb.match(/\d+/g)
    return m ? [+m[0], +m[1], +m[2]] : [0, 0, 0]
}

export const toCssVar = ([r, g, b]: [number, number, number]): string =>
    `${r}, ${g}, ${b}`

const luminance = ([r, g, b]: [number, number, number]) =>
    0.299 * r + 0.587 * g + 0.114 * b

export const buildAutoTheme = (palette: string[]): CSSVars => {
    if (!palette.length) return Theme["auto"]

    const parsed = palette.map(parseRgb)
    const sorted = [...parsed].sort((a, b) => luminance(a) - luminance(b))

    const darkest = sorted[0]
    const lightest = sorted[sorted.length - 1]

    const textColor: [number, number, number] = luminance(darkest) < 128
        ? [245, 245, 235]
        : [20, 20, 15]

    const activeText: [number, number, number] = luminance(darkest) < 128
        ? [20, 24, 15]
        : [240, 244, 228]

    return {
        ...otherStyles,
        "--main-color": toCssVar(darkest),
        "--area-color": toCssVar(lightest),
        "--text-color": toCssVar(textColor),
        "--active-text-color": toCssVar(activeText),
    }
}