/** @jsx jsx */
import { React, jsx } from "jimu-core"
import CustomScroll from "./CustomScroll"
import "./Table.css"
import FeatureLayer from "@arcgis/core/layers/FeatureLayer"
import { LangKey, Translations } from "../../configs/translation"
import { CSSVars } from "../../configs/theme"
import { filterStruct, buildWhereQuery } from "../../configs/config"
import { ArrowIcon, BottomLeftIcon } from "../../configs/icons"

// ─── Types ────────────────────────────────────────────────────────────────────

interface TableRow {
    id_region: string
    id_distric: string
    id_mahalla: string
    mgrs: string
    lattitude: number
    longitude: number
    date: string
    area: number
    status: 0 | 1 | 2
}

interface TableProps {
    polygonRef: React.MutableRefObject<FeatureLayer>
    getLang: LangKey
    themeVars: CSSVars
    setSelectedPoly: (value: string) => void
    getFilter: filterStruct
}

interface PageInfo {
    page: number
    count: number
}

interface SortInfo {
    name: string
    dir: "ASC" | "DESC" | ""
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

const PAGE_SIZE = 100
const PAGE_WINDOW = 5
const MIN_PAGE = 1

const tr = (key: string, lang: LangKey): string =>
    (Translations as any)[key]?.[lang] ?? key

const formatArea = (area: number): string =>
    area.toLocaleString("ru-RU", { minimumFractionDigits: 2, maximumFractionDigits: 2 })

const formatDate = (raw: string | number): string => {
    if (raw == null || raw === "") return "—"
    const d = new Date(raw as any)
    if (isNaN(d.getTime())) return String(raw)
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`
}

// ─── Pulsing / static dot ────────────────────────────────────────────────────

const PulsingDot: React.FC<{ rgb: string; pulse: boolean }> = ({ rgb, pulse }) => (
    <div className="dotWrapper">
        {pulse && (
            <>
                <div className="dotRing ring1" style={{
                    backgroundImage: `radial-gradient(circle at center, transparent 50%, rgba(${rgb},1) 55%, transparent)`,
                }} />
                <div className="dotRing ring2" style={{
                    backgroundImage: `radial-gradient(circle at center, transparent 50%, rgba(${rgb},1) 55%, transparent)`,
                }} />
            </>
        )}
        <div
            className="dotCore"
            style={{
                background: `rgba(${rgb}, ${pulse ? 1 : 0.4})`,
                boxShadow: pulse ? "none" : `0 0 6px rgba(${rgb}, 0.3)`,
            }}
        />
    </div>
)

// ─── Component ────────────────────────────────────────────────────────────────

export default function Table({
    polygonRef,
    getLang,
    themeVars,
    setSelectedPoly,
    getFilter,
}: TableProps) {

    // ─── Status colours ───────────────────────────────────────────────────────────
    //   0 = in-process   1 = not-confirmed   2 = confirmed

    const COLOR_CONFIRMED = themeVars["--confirmed-color"] // "225, 241, 49"   // yellow-green
    const COLOR_NO_CONFIRM = themeVars["--no-confirmed-color"] // "246, 144, 109"  // orange
    const COLOR_IN_PROCESS = themeVars["--in-process-color"] // "250, 250, 238"  // near-white

    const statusRgb = (s: 0 | 1 | 2): string =>
        s === 2 ? COLOR_CONFIRMED : s === 1 ? COLOR_NO_CONFIRM : COLOR_IN_PROCESS

    const [rows, setRows] = React.useState<TableRow[]>([])
    const [total, setTotal] = React.useState(0)
    const [loading, setLoading] = React.useState(false)
    const [selectedRow, setSelectedRow] = React.useState<string | null>(null)
    const [isExpanded, setExpanded] = React.useState(false)
    const [sortInfo, setSortInfo] = React.useState<SortInfo>({ name: "", dir: "" })
    const [pagination, setPagination] = React.useState<PageInfo>({ page: 1, count: PAGE_SIZE })
    const [inputPage, setInputPage] = React.useState("1")

    // ── theme ──
    const mainRgb = themeVars["--main-color"]
    const textRgb = themeVars["--text-color"]
    const areaRgb = themeVars["--area-color"]
    const radius = themeVars["--main-border-radius"] ?? "20px"

    const solid = (rgb: string, a = 1) => `rgba(${rgb}, ${a})`
    const mainBg = solid(mainRgb)
    const areaBg = solid(areaRgb)
    const textClr = solid(textRgb)
    const mainClr = solid(mainRgb)
    const dimClr = solid(textRgb, 0.55)

    // ── pagination math ──
    const MAX_PAGE = Math.max(1, Math.ceil(total / pagination.count))
    const clampPage = (v: number) => Math.max(MIN_PAGE, Math.min(MAX_PAGE, v))

    // ── reset page on filter change ──
    React.useEffect(() => {
        setPagination(prev => ({ ...prev, page: 1 }))
        setInputPage("1")
    }, [getFilter])

    // ── count total ──
    React.useEffect(() => {
        if (!polygonRef?.current) return
        const where = buildWhereQuery(getFilter) || "1=1"
        polygonRef.current
            .queryFeatureCount({ where })
            .then((n: number) => setTotal(n))
            .catch((e: any) => console.error("Count failed:", e))
    }, [polygonRef, getFilter])

    // ── fetch page ──
    React.useEffect(() => {
        if (!polygonRef?.current) return
        setLoading(true)

        const where = buildWhereQuery(getFilter) || "1=1"
        const start = (pagination.page - 1) * pagination.count
        const orderByFields = sortInfo.name
            ? [`${sortInfo.name} ${sortInfo.dir}`]
            : undefined

        polygonRef.current
            .queryFeatures({
                where,
                returnGeometry: false,
                outFields: ["id_region", "id_distric", "mgrs", "id_mahalla", "lattitude", "longitude", "date", "area", "status"],
                num: pagination.count,
                start: start,
                ...(orderByFields ? { orderByFields } : {}),
            })
            .then((res: any) => {
                setRows(res.features.map((f: any) => f.attributes as TableRow))
                setInputPage(String(pagination.page))
            })
            .catch((e: any) => console.error("Query failed:", e))
            .finally(() => setLoading(false))
    }, [polygonRef, getFilter, pagination, sortInfo])

    // ── handlers ──
    const handleSortDate = () => setSortInfo(prev =>
        prev.name === "" ? { name: "date", dir: "ASC" } :
            prev.dir === "ASC" ? { name: "date", dir: "DESC" } :
                { name: "", dir: "" }
    )

    const goToPage = (page: number) => {
        const p = clampPage(page)
        setPagination(prev => ({ ...prev, page: p }))
        setInputPage(String(p))
    }

    // ── page buttons ──
    const renderPageButtons = () => {
        const half = Math.floor(PAGE_WINDOW / 2)
        const btns = []

        for (let i = -half; i <= half; i++) {
            const pg = pagination.page + i

            if (i === 0) {
                btns.push(
                    <input
                        key="inp"
                        className="paginationInput"
                        type="text"
                        value={inputPage}
                        style={{ borderColor: solid(mainRgb, 0.4), color: mainClr }}
                        onChange={e => { if (/^\d*$/.test(e.target.value)) setInputPage(e.target.value) }}
                        onKeyDown={e => { if (e.key === "Enter") goToPage(inputPage === "" ? MIN_PAGE : Number(inputPage)) }}
                    />
                )
                continue
            }

            if (pg < MIN_PAGE || pg > MAX_PAGE) {
                btns.push(<div key={i} className="btn disable" style={{ borderColor: solid(mainRgb, 0.2), color: dimClr }}>-</div>)
                continue
            }

            btns.push(
                <div key={i} className="btn" style={{ borderColor: solid(mainRgb, 0.4), color: mainClr }} onClick={() => goToPage(pg)}>
                    {pg}
                </div>
            )
        }
        return btns
    }

    // ── shared styles ──
    const thSt: React.CSSProperties = {
        position: "sticky", top: 0, zIndex: 250,
        height: 44, background: mainBg, color: textClr,
        fontSize: 14, fontWeight: 700,
        textAlign: "center", verticalAlign: "middle",
        padding: "0 8px",
        whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis",
        transition: "background 0.4s, color 0.4s",
    }

    const tdSt: React.CSSProperties = {
        textAlign: "center", verticalAlign: "middle",
        color: mainClr, fontWeight: 600, fontSize: 13,
        whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis",
        padding: "0 10px",
        borderBottom: `1px solid ${solid(mainRgb, 0.15)}`,
        transition: "color 0.4s",
    }

    console.log(`1ps solid ${mainClr}`);


    // ─────────────────────────────────────────────────────────────────────────
    return (
        <div style={{
            width: "100%", height: "var(--content-height)",
            background: areaBg, borderRadius: radius,
            display: "grid", gridTemplateRows: "auto 1fr 54px",
            gap: 5, padding: 5, boxSizing: "border-box",
            overflow: "hidden", fontFamily: "'Segoe UI', system-ui, sans-serif",
            transition: "background 0.4s", userSelect: "none",
        }}>
            {/* ═══ HEADER ═══ */}
            <div style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                padding: "8px 14px",
                height: 44,
                background: solid(areaRgb, 0.6),
            }}>

                {/* TITLE */}
                <div style={{
                    fontSize: 16,
                    fontWeight: 700,
                    color: solid(mainClr, 0.85), // мягче, как на макете
                    letterSpacing: 0.2,
                }}>
                    {tr("tableTitle", getLang)}
                </div>

                {/* TOGGLE BUTTON */}
                <div
                    onClick={() => setExpanded(prev => !prev)}
                    style={{
                        width: 28,
                        height: 28,
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        cursor: "pointer",
                        transition: "all 0.2s ease",
                    }}
                >
                    <div style={{
                        transform: isExpanded
                            ? "rotate(180deg)"   // ▼ вниз когда открыто
                            : "rotate(0deg)",    // ▲ вверх по умолчанию
                        transition: "transform 0.25s ease",
                        fontSize: 16,
                        color: solid(mainClr, 0.85),
                    }}>
                        <BottomLeftIcon size="40px" color={`${mainClr}`} />
                    </div>
                </div>
            </div>

            {/* ═══ TABLE ═══ */}
            <CustomScroll style={{
                borderRadius: `calc(${radius} - 4px)`,
                minHeight: 0,
                border: `1px solid ${solid(mainRgb, 0.3)}`,
                opacity: loading ? 0.6 : 1,
                transition: "opacity 0.2s",
            }}>
                <table style={{ width: "100%", borderCollapse: "collapse", tableLayout: "fixed" }}>
                    <colgroup>
                        <col style={{ width: "25%", transition: "width 0.35s ease" }} />
                        <col style={{ width: isExpanded ? "18%" : "23%", transition: "width 0.35s ease" }} />
                        <col style={{ width: isExpanded ? "14%" : "20%", transition: "width 0.35s ease" }} />
                        <col style={{ width: isExpanded ? "16%" : "20%", transition: "width 0.35s ease" }} />
                        {isExpanded ? (
                            <>
                                <col style={{ width: "9%", transition: "width 0.35s ease" }} />
                                <col style={{ width: "9%", transition: "width 0.35s ease" }} />
                                <col style={{ width: "9%", transition: "width 0.35s ease" }} />
                            </>
                        ) : (
                            <col style={{ width: "12%", transition: "width 0.35s ease" }} />
                        )}
                    </colgroup>

                    <thead>
                        <tr>
                            <th style={thSt}>{tr("tableRegion", getLang)}</th>
                            <th style={thSt}>{tr("tableMFY", getLang)}</th>

                            <th style={{ ...thSt, cursor: "pointer" }} onClick={handleSortDate}>
                                <div style={{ position: "relative", display: "flex", alignItems: "center", justifyContent: "center", height: "100%" }}>
                                    {tr("tableDate", getLang)}
                                    <div style={{ position: "absolute", right: 2, top: 6, transform: "rotateZ(180deg)", opacity: sortInfo.dir === "ASC" ? 1 : 0.3 }}>
                                        <ArrowIcon size="11px" color={textClr} />
                                    </div>
                                    <div style={{ position: "absolute", right: 2, bottom: 6, opacity: sortInfo.dir === "DESC" ? 1 : 0.3 }}>
                                        <ArrowIcon size="11px" color={textClr} />
                                    </div>
                                </div>
                            </th>

                            <th style={thSt}>{tr("tableArea", getLang)}</th>

                            {/* ✅ ПРАВИЛЬНО: только TH */}
                            {isExpanded ? (
                                <>
                                    <th style={{ ...thSt, fontSize: 10 }}>UZCOSMOS</th>
                                    <th style={{ ...thSt, fontSize: 10 }}>EKOLOGIYA</th>
                                    <th style={{ ...thSt, fontSize: 10 }}>PROKURATURA</th>
                                </>
                            ) : (
                                <th style={thSt}>
                                    {tr("tableStatus", getLang)}
                                </th>
                            )}
                        </tr>
                    </thead>

                    <tbody>
                        {rows.length === 0 && !loading && (
                            <tr>
                                <td colSpan={isExpanded ? 7 : 5} style={{ ...tdSt, padding: "40px 20px", color: dimClr, fontSize: 14, fontWeight: 400 }}>
                                    {tr("noData", getLang)}
                                </td>
                            </tr>
                        )}

                        {rows.map((row, i) => {
                            const key = String(row.mgrs)
                            const isSelected = selectedRow === key

                            return (
                                <tr
                                    key={row.mgrs}
                                    style={{ height: 60, cursor: "pointer", background: isSelected ? solid(mainRgb, 0.18) : "transparent", transition: "background 0.15s" }}
                                    onMouseEnter={e => { if (!isSelected) (e.currentTarget as HTMLElement).style.background = solid(mainRgb, 0.08) }}
                                    onMouseLeave={e => { if (!isSelected) (e.currentTarget as HTMLElement).style.background = "transparent" }}
                                    onClick={() => {
                                        if (isSelected) { setSelectedRow(null); setSelectedPoly("") }
                                        else { setSelectedRow(key); setSelectedPoly(key) }
                                    }}
                                >
                                    {/* Region / District */}
                                    <td style={tdSt}>
                                        <div style={{ color: mainClr, fontWeight: 600, fontSize: 14, lineHeight: 1.35 }}>
                                            {tr(String(row.id_region), getLang)}
                                        </div>
                                        <div style={{ color: solid(mainRgb, 0.6), fontSize: 12, lineHeight: 1.35 }}>
                                            {tr(String(row.id_distric), getLang)}
                                        </div>
                                    </td>

                                    <td style={tdSt}>{tr(String(row.id_mahalla), getLang)}</td>
                                    <td style={tdSt}>{formatDate(row.date)}</td>
                                    <td style={{ ...tdSt, fontWeight: 500 }}>{formatArea(row.area)}</td>

                                    {/* Status cells */}
                                    {isExpanded ? (
                                        <>
                                            {/* col 1 — всегда пульсирует */}
                                            <td style={{ ...tdSt, overflow: "visible" }}>
                                                <PulsingDot rgb={COLOR_CONFIRMED} pulse={true} />
                                            </td>

                                            {/* col 2 — всегда пульсирует */}
                                            <td style={{ ...tdSt, overflow: "visible" }}>
                                                <PulsingDot rgb={statusRgb(row.status)} pulse={true} />
                                            </td>

                                            {/* col 3 — зависит от статуса 2 */}
                                            <td style={{ ...tdSt, overflow: "visible" }}>
                                                <PulsingDot rgb={COLOR_IN_PROCESS} pulse={row.status === 2} />
                                            </td>
                                        </>
                                    ) : (
                                        <td style={{ ...tdSt, overflow: "visible" }}>
                                            <PulsingDot rgb={statusRgb(row.status)} pulse={true} />
                                        </td>
                                    )}
                                </tr>
                            )
                        })}
                    </tbody>
                </table>
            </CustomScroll>

            {/* ═══ PAGINATION ═══ */}
            <div style={{
                position: "relative", display: "flex",
                alignItems: "center", justifyContent: "center",
                gap: 25, flexShrink: 0,
            }}>
                {/* Page info left */}
                <div style={{ position: "absolute", left: 10, fontSize: 13, fontWeight: 700, color: mainClr, whiteSpace: "nowrap" }}>
                    {tr("page", getLang)} {pagination.page} / {MAX_PAGE}
                    <span style={{ marginLeft: 8, opacity: 0.5, fontWeight: 500 }}>({total})</span>
                </div>

                <div className="paginationBtns">
                    <div className={`btn${pagination.page <= MIN_PAGE ? " disable" : ""}`} style={{ borderColor: solid(mainRgb, 0.4), color: mainClr }} onClick={() => goToPage(MIN_PAGE)}>⏮</div>
                    <div className={`btn${pagination.page <= MIN_PAGE ? " disable" : ""}`} style={{ borderColor: solid(mainRgb, 0.4), color: mainClr }} onClick={() => goToPage(pagination.page - 3)}>◀</div>
                    {renderPageButtons()}
                    <div className={`btn${pagination.page >= MAX_PAGE ? " disable" : ""}`} style={{ borderColor: solid(mainRgb, 0.4), color: mainClr }} onClick={() => goToPage(pagination.page + 3)}>▶</div>
                    <div className={`btn${pagination.page >= MAX_PAGE ? " disable" : ""}`} style={{ borderColor: solid(mainRgb, 0.4), color: mainClr }} onClick={() => goToPage(MAX_PAGE)}>⏭</div>
                </div>
            </div>
        </div>
    )
}