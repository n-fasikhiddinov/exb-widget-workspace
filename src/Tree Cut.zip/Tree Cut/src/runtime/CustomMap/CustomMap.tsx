import { React } from "jimu-core"
import Map from "@arcgis/core/Map"
import MapView from "@arcgis/core/views/MapView"
import FeatureLayer from "@arcgis/core/layers/FeatureLayer"
import FeatureLayerView from "@arcgis/core/views/layers/FeatureLayerView"
import FeatureEffect from "@arcgis/core/layers/support/FeatureEffect"
import FeatureFilter from "@arcgis/core/layers/support/FeatureFilter"

import { uniqueIdField, uniqueIdQuery, filterStruct, buildWhereQuery } from "../../configs/config"
import { ThemeKey } from "../../configs/theme"
import { LangKey } from "../../configs/translation"

// =============================================
// ВНЕ компонента — нет проблем с замыканиями
// =============================================

const PALETTE_CONFIG = {
    screenshotSize: 150,
    sampleStep: 16,
    quantStep: 32,
    maxColors: 6,
    ignoreLight: 240,
    alphaThreshold: 200,
    delay: 300,
}

function quantizeColors(data: Uint8ClampedArray): string[] {
    const { sampleStep, alphaThreshold, quantStep, ignoreLight, maxColors } = PALETTE_CONFIG
    const colorMap = new globalThis.Map<string, number>()

    for (let i = 0; i < data.length; i += sampleStep * 4) {
        let r = data[i]
        let g = data[i + 1]
        let b = data[i + 2]
        const a = data[i + 3]

        if (a < alphaThreshold) continue

        r = Math.round(r / quantStep) * quantStep
        g = Math.round(g / quantStep) * quantStep
        b = Math.round(b / quantStep) * quantStep

        if (r > ignoreLight && g > ignoreLight && b > ignoreLight) continue

        const key = `${r},${g},${b}`
        colorMap.set(key, (colorMap.get(key) || 0) + 1)
    }

    return [...colorMap.entries()]
        .sort((a, b) => b[1] - a[1])
        .slice(0, maxColors)
        .map(([c]) => `rgb(${c})`)
}

async function extractPalette(
    view: MapView,
    onPaletteChange: (palette: string[]) => void,
    runningRef: React.MutableRefObject<boolean>
): Promise<void> {
    if (runningRef.current) return
    runningRef.current = true

    try {
        const { screenshotSize } = PALETTE_CONFIG
        const screenshot = await view.takeScreenshot({
            width: screenshotSize,
            height: screenshotSize,
        })

        const img = new Image()
        img.src = screenshot.dataUrl

        img.onload = () => {
            const canvas = document.createElement("canvas")
            canvas.width = img.width
            canvas.height = img.height

            const ctx = canvas.getContext("2d", { willReadFrequently: true })
            if (!ctx) {
                runningRef.current = false
                return
            }

            ctx.drawImage(img, 0, 0)

            // Центральные 40% — самая репрезентативная часть карты
            const size = img.width * 0.4
            const offset = img.width * 0.3
            const imageData = ctx.getImageData(offset, offset, size, size)

            const palette = quantizeColors(imageData.data)
            onPaletteChange(palette)
            runningRef.current = false
        }

        img.onerror = () => {
            runningRef.current = false
        }

    } catch (e) {
        console.warn("Screenshot failed:", e)
        runningRef.current = false
    }
}

// =============================================

interface CustomMapProps {
    getFilter: filterStruct;
    polygonRef: React.MutableRefObject<FeatureLayer>;
    getSelectedPoly: string;
    getTheme: ThemeKey;
    getLang: LangKey;
    getMap: MapView;
    setMap: (value: MapView) => void;
    setSelectedPoly: (value: string) => void;
    onPaletteChange?: (palette: string[]) => void;
}

export default function CustomMap({
    getFilter,
    polygonRef,
    getSelectedPoly,
    setSelectedPoly,
    getTheme,
    getLang,
    getMap,
    setMap,
    onPaletteChange,
}: CustomMapProps) {
    const center = [64.9865, 41.0835]
    const mapRef = React.useRef<HTMLDivElement | null>(null)
    const layerViewRef = React.useRef<FeatureLayerView | null>(null)
    const runningRef = React.useRef<boolean>(false)

    // ===== Выбранный полигон — подсветка и goTo =====
    React.useEffect(() => {
        if (!getMap || !layerViewRef.current) return

        if (getSelectedPoly !== "") {
            layerViewRef.current.featureEffect = new FeatureEffect({
                filter: new FeatureFilter({ where: uniqueIdQuery(getSelectedPoly) }),
                excludedEffect: "opacity(60%) saturate(0.4)"
            })

            polygonRef.current.queryFeatures({
                where: uniqueIdQuery(getSelectedPoly),
                returnGeometry: true
            })
                .then((result: any) => {
                    if (result.features[0]?.geometry) {
                        getMap.goTo(
                            { center: result.features[0].geometry.extent.expand(2.5) },
                            { duration: 500, easing: "ease-in-out" }
                        )
                    } else {
                        layerViewRef.current.featureEffect = null
                    }
                })
                .catch((error: any) => console.error("Query failed CustomMap:", error))

        } else {
            layerViewRef.current.featureEffect = null
            getMap.goTo({ zoom: getMap.zoom - 2 }, { duration: 500, easing: "ease-in-out" })
        }
    }, [getSelectedPoly])

    // ===== Фильтр =====
    React.useEffect(() => {
        if (!polygonRef.current) return
        polygonRef.current.definitionExpression = buildWhereQuery(getFilter)
    }, [getFilter])

    // ===== Инициализация карты =====
    React.useEffect(() => {
        if (!mapRef.current) return

        const map = new Map({ basemap: "satellite" })
        const mapView = new MapView({
            container: mapRef.current,
            map,
            zoom: 6,
            center: center,
            ui: { components: [] }
        })

        map.add(new FeatureLayer({
            url: "https://gis.uzspace.uz/uzspacesrvr/rest/services/Hosted/Viloyat_chegara_Lot/FeatureServer",

            renderer: {
                type: "simple",
                symbol: {
                    type: "simple-fill",
                    color: [0, 0, 0, 0.3],
                    outline: {
                        type: "simple-line",
                        color: [0, 0, 0, 1],
                        width: 1.5
                    }
                }
            },

            labelingInfo: [{
                labelExpressionInfo: {
                    expression: "$feature.name"
                },
                symbol: {
                    type: "text",
                    color: "white",
                    font: {
                        size: 12,
                        weight: "bold"
                    }
                },
                labelPlacement: "always-horizontal"
            }],

            labelsVisible: true,

            maxScale: 600000
        }))

        map.add(new FeatureLayer({
            url: "https://gis.uzspace.uz/uzspacesrvr/rest/services/Hosted/Tuman_chegaralari/FeatureServer",

            renderer: {
                type: "simple",
                symbol: {
                    type: "simple-fill",
                    color: [0, 0, 0, 0.3],

                    outline: {
                        type: "simple-line",
                        color: [0, 0, 0, 1],
                        width: 1.5
                    }
                }
            },

            labelingInfo: [{
                labelExpressionInfo: {
                    expression: "$feature.tuman_uzb  "
                },
                symbol: {
                    type: "text",
                    color: "white",
                    font: {
                        size: 12,
                        weight: "bold"
                    }
                },
                labelPlacement: "always-horizontal"
            }],

            labelsVisible: true,

            minScale: 600000, // появляется когда приближаешься
            maxScale: 0        // 0 = без ограничения сверху
        }))
        map.add(polygonRef.current)

        mapView.whenLayerView(polygonRef.current).then((lv: FeatureLayerView) => {
            layerViewRef.current = lv
        })

        setMap(mapView)

        let timeout: ReturnType<typeof setTimeout> | null = null

        mapView.when(() => {
            // После каждой остановки карты — пересчитываем палитру
            mapView.watch("stationary", (isStationary: boolean) => {
                if (!isStationary) return
                if (timeout) clearTimeout(timeout)
                timeout = setTimeout(() => {
                    if (onPaletteChange) {
                        extractPalette(mapView, onPaletteChange, runningRef)
                    }
                }, PALETTE_CONFIG.delay)
            })

            // Первый запуск
            setTimeout(() => {
                if (onPaletteChange) {
                    extractPalette(mapView, onPaletteChange, runningRef)
                }
            }, 800)
        })

        mapView.on("click", (event) => {
            console.log(mapView);

            mapView.hitTest(event).then((response) => {
                const result = response.results.find(
                    (r: any) => r.graphic?.layer === polygonRef.current
                ) as any

                if (result?.graphic?.attributes) {
                    setSelectedPoly(result.graphic.attributes[uniqueIdField])
                } else {
                    setSelectedPoly("")
                }
            })
        })

        return () => {
            if (timeout) clearTimeout(timeout)
            mapView.destroy()
        }
    }, [])

    return (
        <div
            ref={mapRef}
            style={{
                position: "absolute",
                top: 0,
                left: 0,
                width: "100%",
                height: "100%"
            }}
        />
    )
}