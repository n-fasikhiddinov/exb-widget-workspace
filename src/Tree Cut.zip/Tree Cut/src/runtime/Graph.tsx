/** @jsx jsx */
import { React, jsx } from "jimu-core"
import FeatureLayer from "@arcgis/core/layers/FeatureLayer"
import { LangKey, Translations } from "../configs/translation"
import { CSSVars } from "../configs/theme"
import { filterStruct } from "../configs/config"

const { useEffect, useMemo, useRef, useState, useCallback } = React

type GraphMode = "daily" | "region"

type GraphPoint = {
    date: string
    count: number
    area: number
}

type RegionPoint = {
    id_region: string
    label: string
    count: number
    area: number
}

interface GraphProps {
    polygonRef: React.MutableRefObject<FeatureLayer>
    getLang: LangKey
    themeVars: CSSVars                  // ← вместо getTheme
    setFilter: React.Dispatch<React.SetStateAction<filterStruct>>
}

const VIEW_DAYS = 31
const DPR_LIMIT = 2

const UI = {
    radius: 22,
    paddingX: 20,
    paddingTop: 18,
    paddingBottom: 18,
    headerTitleSize: 18,
    headerMonthSize: 14,
    headerGap: 4,
    headerHeight: 56,
    chartTopGap: 8,
    chartBottomGap: 74,
    chartLineWidth: 2.2,
    areaTopAlpha: 0.1,
    areaBottomAlpha: 0,
    axisLabelSize: 14,
    monthLabelSize: 13,
    separatorDash: [5, 7],
    separatorAlpha: 0.18,
    sliderYBottomOffset: 10,
    sliderBaseWidth: 2.4,
    handleRadius: 12,
    handleIconSize: 5,
    handleBorderWidth: 1.15,
    handleHitRadius: 18,
    activeBubbleMinWidth: 34,
    activeBubbleHeight: 30,
    activeBubblePadX: 12,
    activeBubbleGap: 5,
    tooltipMinWidth: 150,
    tooltipHeight: 74,
    tooltipPadX: 12,
    tooltipPadY: 10,
    tooltipRadius: 12,
    tooltipGap: 12,
    tooltipTitleSize: 14,
    tooltipTextSize: 13,
    activePointRadius: 6,
    activePointGlow: 18,
    hoverDateRadius: 999,
    hoverDatePadX: 8,
    hoverDateHeight: 22,
    bypassOffset: 20,
    bypassHalfWidth: 40,
    bypassLineWidth: 6,
    baseLineHiddenStartRatio: 0,
    baseLineHiddenEndRatio: 1,
    toggleTop: 12,
    toggleRight: 14,
    toggleHeight: 34,
    toggleGap: 4,
    togglePadX: 14,
    toggleRadius: 11,
    regionValueTopGap: 10,
    regionLabelTopGap: 10,
    regionBarMinHeight: 18,
    regionBarRadius: 18,
    regionBarGap: 18,
    regionValueFontSize: 14,
    regionLabelFontSize: 13,
    regionBottomAxisOffset: 28,
    regionLabelMaxWidth: 90
}

const MONTHS: Record<LangKey, string[]> = {
    RU: ["Январь", "Февраль", "Март", "Апрель", "Май", "Июнь", "Июль", "Август", "Сентябрь", "Октябрь", "Ноябрь", "Декабрь"],
    EN: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
    UZ: ["Yanvar", "Fevral", "Mart", "Aprel", "May", "Iyun", "Iyul", "Avgust", "Sentabr", "Oktabr", "Noyabr", "Dekabr"]
}

const rgba = (rgb: string, alpha: number = 1): string => `rgba(${rgb}, ${alpha})`

const clamp = (value: number, min: number, max: number): number =>
    Math.max(min, Math.min(max, value))

const parseDate = (value: string): Date => {
    const parts = value.split("-").map(Number)
    return new Date(parts[0], parts[1] - 1, parts[2])
}

const toIsoDate = (date: Date): string => {
    const y = date.getFullYear()
    const m = String(date.getMonth() + 1).padStart(2, "0")
    const d = String(date.getDate()).padStart(2, "0")
    return `${y}-${m}-${d}`
}

const addDays = (date: Date, days: number): Date => {
    const next = new Date(date)
    next.setDate(next.getDate() + days)
    return next
}

const formatDate = (dateStr: string): string => {
    const d = parseDate(dateStr)
    const dd = String(d.getDate()).padStart(2, "0")
    const mm = String(d.getMonth() + 1).padStart(2, "0")
    const yyyy = d.getFullYear()
    return `${dd}.${mm}.${yyyy}`
}

const formatNumber = (value: number): string =>
    new Intl.NumberFormat("ru-RU").format(value || 0)

const buildContinuousSeries = (input: GraphPoint[]): GraphPoint[] => {
    if (!input.length) return []
    const sorted = input.slice().sort((a, b) =>
        parseDate(a.date).getTime() - parseDate(b.date).getTime()
    )
    const map = new globalThis.Map<string, GraphPoint>()
    sorted.forEach((item) => {
        map.set(item.date, { date: item.date, count: Number(item.count) || 0, area: Number(item.area) || 0 })
    })
    const start = parseDate(sorted[0].date)
    const end = parseDate(sorted[sorted.length - 1].date)
    const result: GraphPoint[] = []
    let cursor = new Date(start)
    while (cursor <= end) {
        const iso = toIsoDate(cursor)
        result.push(map.get(iso) || { date: iso, count: 0, area: 0 })
        cursor = addDays(cursor, 1)
    }
    return result
}

const roundedRectPath = (ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) => {
    const rr = Math.min(r, w / 2, h / 2)
    ctx.beginPath()
    ctx.moveTo(x + rr, y)
    ctx.lineTo(x + w - rr, y)
    ctx.quadraticCurveTo(x + w, y, x + w, y + rr)
    ctx.lineTo(x + w, y + h - rr)
    ctx.quadraticCurveTo(x + w, y + h, x + w - rr, y + h)
    ctx.lineTo(x + rr, y + h)
    ctx.quadraticCurveTo(x, y + h, x, y + h - rr)
    ctx.lineTo(x, y + rr)
    ctx.quadraticCurveTo(x, y, x + rr, y)
    ctx.closePath()
}

const createSmoothPath = (ctx: CanvasRenderingContext2D, points: Array<{ x: number; y: number }>) => {
    if (!points.length) return
    if (points.length === 1) { ctx.moveTo(points[0].x, points[0].y); return }
    if (points.length === 2) { ctx.moveTo(points[0].x, points[0].y); ctx.lineTo(points[1].x, points[1].y); return }
    ctx.moveTo(points[0].x, points[0].y)
    let i = 0
    for (i = 1; i < points.length - 1; i += 1) {
        const current = points[i]
        const next = points[i + 1]
        const midX = (current.x + next.x) / 2
        const midY = (current.y + next.y) / 2
        ctx.quadraticCurveTo(current.x, current.y, midX, midY)
    }
    const penultimate = points[points.length - 2]
    const last = points[points.length - 1]
    ctx.quadraticCurveTo(penultimate.x, penultimate.y, last.x, last.y)
}

const createAreaPath = (ctx: CanvasRenderingContext2D, points: Array<{ x: number; y: number }>, bottom: number) => {
    if (!points.length) return
    ctx.beginPath()
    createSmoothPath(ctx, points)
    ctx.lineTo(points[points.length - 1].x, bottom)
    ctx.lineTo(points[0].x, bottom)
    ctx.closePath()
}

const hitIndexByX = (x: number, left: number, width: number, count: number): number => {
    if (count <= 1) return 0
    const step = width / (count - 1)
    const raw = Math.round((x - left) / step)
    return clamp(raw, 0, count - 1)
}

const drawBypassCurve = (ctx: CanvasRenderingContext2D, centerX: number, centerY: number, offset: number, halfWidth: number) => {
    const points = [
        { x: centerX - halfWidth, y: centerY },
        { x: centerX, y: centerY - offset },
        { x: centerX + halfWidth, y: centerY }
    ]
    ctx.beginPath()
    createSmoothPath(ctx, points)
}

const fitLabel = (ctx: CanvasRenderingContext2D, text: string, maxWidth: number): string => {
    if (ctx.measureText(text).width <= maxWidth) return text
    let value = text
    while (value.length > 1 && ctx.measureText(`${value}...`).width > maxWidth) {
        value = value.slice(0, -1)
    }
    return `${value}...`
}

const getTranslationSafe = (key: string, lang: LangKey, fallback: string): string => {
    const value = (Translations as any)[key]
    if (value && typeof value === "object" && value[lang]) return value[lang]
    return fallback
}

const getRegionLabel = (idRegion: string, lang: LangKey): string => {
    const direct = (Translations as any)[idRegion]
    if (direct && typeof direct === "object" && direct[lang]) return direct[lang]
    const byKey = (Translations as any)[`region_${idRegion}`]
    if (byKey && typeof byKey === "object" && byKey[lang]) return byKey[lang]
    return idRegion
}

function useDebounce<T>(value: T, delay: number): T {
    const [debounced, setDebounced] = useState<T>(value)
    useEffect(() => {
        const timer = setTimeout(() => setDebounced(value), delay)
        return () => clearTimeout(timer)
    }, [value, delay])
    return debounced
}

export default function Graph({ polygonRef, getLang, themeVars, setFilter }: GraphProps) {
    const wrapperRef = useRef<HTMLDivElement | null>(null)
    const canvasRef = useRef<HTMLCanvasElement | null>(null)
    const draggingRef = useRef(false)
    const pointerDownOnHandleRef = useRef(false)
    const movedAfterDownRef = useRef(false)

    const [mode, setMode] = useState<GraphMode>("daily")
    const [size, setSize] = useState({ width: 0, height: 0 })
    const [hoverIndex, setHoverIndex] = useState<number | null>(null)
    const [windowStart, setWindowStart] = useState(0)
    const [innerSelectedDate, setInnerSelectedDate] = useState<string | null>(null)
    const [selectedRegionIndex, setSelectedRegionIndex] = useState<number>(0)
    const [sliderActive, setSliderActive] = useState<boolean>(false)
    const [dailyData, setDailyData] = useState<GraphPoint[]>([])
    const [regionData, setRegionData] = useState<RegionPoint[]>([])
    const [pendingDate, setPendingDate] = useState<string | null>(null)
    const [pendingRegion, setPendingRegion] = useState<string>("")

    const debouncedDate = useDebounce(pendingDate, 400)
    const debouncedRegion = useDebounce(pendingRegion, 400)

    useEffect(() => {
        if (mode !== "daily") return
        setFilter((prev) => ({ ...prev, from_date: debouncedDate ?? "", to_date: debouncedDate ?? "" }))
    }, [debouncedDate])

    useEffect(() => {
        if (mode !== "region") return
        setFilter((prev) => ({ ...prev, id_region: debouncedRegion }))
    }, [debouncedRegion])

    const valueField = "count" as const

    const countPrefix = useMemo(() => getTranslationSafe("indicatorCount", getLang, "Количество"), [getLang])
    const areaPrefix = useMemo(() => getTranslationSafe("indicatorArea", getLang, "Площадь"), [getLang])

    const title = useMemo(() => {
        if (mode === "daily") return getTranslationSafe("dailyReport", getLang, "Ежедневная статистика")
        return getTranslationSafe("regionStatistic", getLang, "Статистика по регионам")
    }, [mode, getLang])

    const dailyButtonText = useMemo(() =>
        getTranslationSafe("dailyShort", getLang, getTranslationSafe("dailyReport", getLang, "Кунлик")), [getLang])

    const regionButtonText = useMemo(() =>
        getTranslationSafe("regionShort", getLang, "Hudud"), [getLang])

    useEffect(() => {
        const node = wrapperRef.current
        if (!node) return
        const observer = new ResizeObserver((entries) => {
            const rect = entries[0] && entries[0].contentRect
            if (!rect) return
            setSize({ width: Math.round(rect.width), height: Math.round(rect.height) })
        })
        observer.observe(node)
        return () => observer.disconnect()
    }, [])

    useEffect(() => {
        if (mode !== "daily") return
        polygonRef.current.queryFeatures({
            where: "1=1",
            returnGeometry: false,
            groupByFieldsForStatistics: ["date"],
            outStatistics: [
                { statisticType: "count", onStatisticField: "date", outStatisticFieldName: "count" },
                { statisticType: "sum", onStatisticField: "area", outStatisticFieldName: "sum" }
            ]
        })
            .then((result: any) => {
                const normalized = result.features
                    .map((item: any) => ({
                        date: String(item.attributes.date),
                        count: Number(item.attributes.count) || 0,
                        area: Number(item.attributes.sum) || 0
                    }))
                    .sort((a: GraphPoint, b: GraphPoint) =>
                        new Date(a.date).getTime() - new Date(b.date).getTime()
                    )
                setDailyData(normalized)
                setInnerSelectedDate(normalized[normalized.length - 1]?.date ?? null)
                setSliderActive(false)
                setHoverIndex(null)
                setWindowStart(0)
            })
            .catch((error: any) => {
                console.error("Query failed daily graph:", error)
                setDailyData([])
                setInnerSelectedDate(null)
                setSliderActive(false)
            })
    }, [mode, polygonRef])

    useEffect(() => {
        if (mode !== "region") return
        polygonRef.current.queryFeatures({
            where: "1=1",
            returnGeometry: false,
            groupByFieldsForStatistics: ["id_region"],
            outStatistics: [
                { statisticType: "count", onStatisticField: "id_region", outStatisticFieldName: "count" },
                { statisticType: "sum", onStatisticField: "area", outStatisticFieldName: "sum" }
            ]
        })
            .then((result: any) => {
                const normalized = result.features
                    .map((item: any) => {
                        const idRegion = String(item.attributes.id_region)
                        return {
                            id_region: idRegion,
                            label: getRegionLabel(idRegion, getLang),
                            count: Number(item.attributes.count) || 0,
                            area: Number(item.attributes.sum) || 0
                        }
                    })
                    .sort((a: RegionPoint, b: RegionPoint) => b.count - a.count)
                setRegionData(normalized)
                setHoverIndex(null)
                setSelectedRegionIndex((prev) => {
                    if (!normalized.length) return 0
                    return clamp(prev, 0, normalized.length - 1)
                })
                setSliderActive(false)
            })
            .catch((error: any) => {
                console.error("Query failed region graph:", error)
                setRegionData([])
                setSelectedRegionIndex(0)
                setSliderActive(false)
            })
    }, [mode, polygonRef, getLang])

    const series = useMemo(() => buildContinuousSeries(dailyData), [dailyData])
    const actualSelectedDate = innerSelectedDate ?? null

    useEffect(() => {
        if (mode !== "daily") return
        if (!series.length) return
        if (!actualSelectedDate) return
        const targetIndex = series.findIndex((item) => item.date === actualSelectedDate)
        if (targetIndex < 0) return
        const visibleStart = windowStart
        const visibleEnd = windowStart + VIEW_DAYS - 1
        const maxStart = Math.max(0, series.length - VIEW_DAYS)
        if (targetIndex < visibleStart) { setWindowStart(clamp(targetIndex, 0, maxStart)); return }
        if (targetIndex > visibleEnd) { setWindowStart(clamp(targetIndex - VIEW_DAYS + 1, 0, maxStart)) }
    }, [mode, series, actualSelectedDate, windowStart])

    const visiblePoints = useMemo(() => series.slice(windowStart, windowStart + VIEW_DAYS), [series, windowStart])

    const selectedVisibleIndex = useMemo(() => {
        if (!actualSelectedDate) return -1
        return visiblePoints.findIndex((item) => item.date === actualSelectedDate)
    }, [visiblePoints, actualSelectedDate])

    const activeRegion = useMemo(() => {
        if (!regionData.length) return null
        return regionData[clamp(selectedRegionIndex, 0, regionData.length - 1)] || null
    }, [regionData, selectedRegionIndex])

    const setSelectedByIndex = useCallback((index: number) => {
        const point = visiblePoints[index]
        if (!point) return
        setInnerSelectedDate(point.date)
        setSliderActive(true)
        setPendingDate(point.date)
    }, [visiblePoints])

    const setSelectedRegionByIndex = useCallback((index: number) => {
        if (!regionData.length) return
        const clamped = clamp(index, 0, regionData.length - 1)
        setSelectedRegionIndex(clamped)
        setSliderActive(true)
        const region = regionData[clamped]
        if (region) setPendingRegion(region.id_region)
    }, [regionData])

    const clearSelection = useCallback(() => {
        setSliderActive(false)
        if (mode === "daily") { setInnerSelectedDate(null); setPendingDate(null) }
        else { setPendingRegion("") }
    }, [mode])

    const getMetrics = useCallback(() => {
        const width = size.width
        const height = size.height
        const left = UI.paddingX
        const right = width - UI.paddingX
        const top = UI.paddingTop + UI.headerHeight + UI.chartTopGap
        const bottom = height - UI.paddingBottom - UI.chartBottomGap
        const chartWidth = right - left
        const chartHeight = bottom - top
        const sliderY = height - UI.paddingBottom - UI.sliderYBottomOffset
        return { width, height, left, right, top, bottom, chartWidth, chartHeight, sliderY }
    }, [size])

    const getHandleX = useCallback(() => {
        const metrics = getMetrics()
        if (mode === "region") {
            if (regionData.length <= 1) return metrics.left + metrics.chartWidth / 2
            const stepX = metrics.chartWidth / (regionData.length - 1)
            return metrics.left + stepX * clamp(selectedRegionIndex, 0, regionData.length - 1)
        }
        if (selectedVisibleIndex >= 0 && visiblePoints.length > 0) {
            const stepX = visiblePoints.length > 1 ? metrics.chartWidth / (visiblePoints.length - 1) : 0
            return metrics.left + stepX * selectedVisibleIndex
        }
        return metrics.left + metrics.chartWidth / 2
    }, [getMetrics, mode, regionData.length, selectedRegionIndex, selectedVisibleIndex, visiblePoints.length])

    // ── Canvas render — использует themeVars напрямую ──
    useEffect(() => {
        const canvas = canvasRef.current
        if (!canvas || !size.width || !size.height) return
        const ctx = canvas.getContext("2d")
        if (!ctx) return

        const dpr = Math.min(window.devicePixelRatio || 1, DPR_LIMIT)
        canvas.width = Math.max(1, Math.floor(size.width * dpr))
        canvas.height = Math.max(1, Math.floor(size.height * dpr))
        canvas.style.width = `${size.width}px`
        canvas.style.height = `${size.height}px`
        ctx.setTransform(dpr, 0, 0, dpr, 0, 0)
        ctx.clearRect(0, 0, size.width, size.height)

        // ← Читаем напрямую из themeVars
        const bg = rgba(themeVars["--area-color"], 0.82)
        const lineColor = rgba(themeVars["--main-color"], 0.58)
        const textColor = rgba(themeVars["--active-text-color"], 0.95)
        const mutedText = rgba(themeVars["--active-text-color"], 0.64)
        const accent = rgba(themeVars["--confirmed-color"], 1)
        const accentHoverBg = rgba(themeVars["--confirmed-color"], 0.18)
        const separatorColor = rgba(themeVars["--main-color"], UI.separatorAlpha)
        const baseLineColor = rgba(themeVars["--main-color"], 0.18)

        const metrics = getMetrics()
        const left = metrics.left
        const right = metrics.right
        const top = metrics.top
        const bottom = metrics.bottom
        const chartWidth = metrics.chartWidth
        const chartHeight = metrics.chartHeight
        const sliderY = metrics.sliderY

        roundedRectPath(ctx, 0, 0, metrics.width, metrics.height, UI.radius)
        ctx.fillStyle = bg
        ctx.fill()

        ctx.textBaseline = "top"
        ctx.fillStyle = textColor
        ctx.font = `700 ${UI.headerTitleSize}px Inter, system-ui, sans-serif`
        ctx.fillText(title, left, UI.paddingTop)

        if (mode === "daily") {
            if (!visiblePoints.length) return

            const maxValue = Math.max(1, ...visiblePoints.map((item) => Number(item[valueField]) || 0))
            const stepX = visiblePoints.length > 1 ? chartWidth / (visiblePoints.length - 1) : 0

            const graphPoints = visiblePoints.map((item, index) => {
                const x = left + stepX * index
                const value = Number(item[valueField]) || 0
                const ratio = value / maxValue
                const y = bottom - ratio * chartHeight
                return { x, y, raw: item }
            })

            const firstVisibleDate = parseDate(visiblePoints[0].date)
            const firstMonthText = MONTHS[getLang][firstVisibleDate.getMonth()]
            ctx.font = `500 ${UI.headerMonthSize}px Inter, system-ui, sans-serif`
            ctx.fillStyle = mutedText
            ctx.fillText(firstMonthText, left, UI.paddingTop + UI.headerTitleSize + UI.headerGap)

            const monthStartIndices: number[] = []
            let i = 0
            for (i = 0; i < visiblePoints.length; i += 1) {
                const d = parseDate(visiblePoints[i].date)
                if (d.getDate() === 1 || i === 0) monthStartIndices.push(i)
            }

            ctx.save()
            ctx.setLineDash(UI.separatorDash)
            ctx.lineWidth = 1
            ctx.strokeStyle = separatorColor

            monthStartIndices.forEach((index) => {
                if (index === 0) return
                const x = left + stepX * index
                const monthDate = parseDate(visiblePoints[index].date)
                const monthText = MONTHS[getLang][monthDate.getMonth()]
                ctx.beginPath()
                ctx.moveTo(x, top - 10)
                ctx.lineTo(x, bottom)
                ctx.stroke()
                ctx.setLineDash([])
                ctx.fillStyle = mutedText
                ctx.font = `500 ${UI.monthLabelSize}px Inter, system-ui, sans-serif`
                ctx.fillText(monthText, x + 8, top - 18)
                ctx.setLineDash(UI.separatorDash)
            })
            ctx.restore()

            createAreaPath(ctx, graphPoints, bottom)
            const areaGradient = ctx.createLinearGradient(0, top, 0, bottom)
            areaGradient.addColorStop(0, rgba(themeVars["--main-color"], UI.areaTopAlpha))
            areaGradient.addColorStop(1, rgba(themeVars["--main-color"], UI.areaBottomAlpha))
            ctx.fillStyle = areaGradient
            ctx.fill()

            ctx.beginPath()
            createSmoothPath(ctx, graphPoints)
            ctx.lineWidth = UI.chartLineWidth
            ctx.strokeStyle = lineColor
            ctx.stroke()

            const activeGraphIndex = sliderActive ? selectedVisibleIndex : -1
            if (activeGraphIndex >= 0 && graphPoints[activeGraphIndex]) {
                const p = graphPoints[activeGraphIndex]
                ctx.beginPath()
                ctx.arc(p.x, p.y, 4, 0, Math.PI * 2)
                ctx.fillStyle = accent
                ctx.fill()
            }

            ctx.font = `500 ${UI.axisLabelSize}px Inter, system-ui, sans-serif`
            ctx.textAlign = "center"
            ctx.textBaseline = "middle"

            visiblePoints.forEach((item, index) => {
                const d = parseDate(item.date)
                const x = left + stepX * index
                const text = String(d.getDate())
                const isActive = sliderActive && index === selectedVisibleIndex
                const isHover = hoverIndex === index
                if (isActive) return
                if (isHover) {
                    const textWidth = ctx.measureText(text).width
                    const bgWidth = textWidth + UI.hoverDatePadX * 2
                    const bgX = x - bgWidth / 2
                    const bgY = sliderY - 18 - UI.hoverDateHeight / 2 + 1
                    roundedRectPath(ctx, bgX, bgY, bgWidth, UI.hoverDateHeight, UI.hoverDateRadius)
                    ctx.fillStyle = accentHoverBg
                    ctx.fill()
                }
                ctx.fillStyle = isHover ? accent : rgba(themeVars["--active-text-color"], 0.92)
                ctx.fillText(text, x, sliderY - 18)
            })

            const handleX = getHandleX()

            ctx.save()
            ctx.lineCap = "round"
            ctx.lineJoin = "round"

            if (sliderActive) {
                const sideOffset = UI.bypassHalfWidth
                const bypassStartX = Math.max(left, handleX - sideOffset)
                const bypassEndX = Math.min(right, handleX + sideOffset)
                const hiddenStartX = bypassStartX + (bypassEndX - bypassStartX) * UI.baseLineHiddenStartRatio
                const hiddenEndX = bypassStartX + (bypassEndX - bypassStartX) * UI.baseLineHiddenEndRatio

                if (hiddenStartX > left) {
                    ctx.beginPath(); ctx.moveTo(left, sliderY); ctx.lineTo(hiddenStartX, sliderY)
                    ctx.lineWidth = UI.sliderBaseWidth; ctx.strokeStyle = baseLineColor; ctx.stroke()
                }
                if (hiddenEndX < right) {
                    ctx.beginPath(); ctx.moveTo(hiddenEndX, sliderY); ctx.lineTo(right, sliderY)
                    ctx.lineWidth = UI.sliderBaseWidth; ctx.strokeStyle = baseLineColor; ctx.stroke()
                }
                if (bypassStartX > left) {
                    ctx.beginPath(); ctx.moveTo(left, sliderY); ctx.lineTo(bypassStartX, sliderY)
                    const leftGradient = ctx.createLinearGradient(left, 0, bypassStartX, 0)
                    leftGradient.addColorStop(0, rgba(themeVars["--main-color"], 0.35))
                    leftGradient.addColorStop(1, rgba(themeVars["--confirmed-color"], 0.55))
                    ctx.lineWidth = UI.sliderBaseWidth; ctx.strokeStyle = leftGradient; ctx.stroke()
                }
                if (bypassEndX < right) {
                    ctx.beginPath(); ctx.moveTo(bypassEndX, sliderY); ctx.lineTo(right, sliderY)
                    const rightGradient = ctx.createLinearGradient(bypassEndX, 0, right, 0)
                    rightGradient.addColorStop(0, rgba(themeVars["--confirmed-color"], 0.55))
                    rightGradient.addColorStop(1, rgba(themeVars["--main-color"], 0.35))
                    ctx.lineWidth = UI.sliderBaseWidth; ctx.strokeStyle = rightGradient; ctx.stroke()
                }

                drawBypassCurve(ctx, handleX, sliderY, UI.bypassOffset, UI.bypassHalfWidth)
                const curveGradient = ctx.createLinearGradient(handleX - sideOffset, 0, handleX + sideOffset, 0)
                curveGradient.addColorStop(0, rgba(themeVars["--confirmed-color"], 0))
                curveGradient.addColorStop(0.32, rgba(themeVars["--confirmed-color"], 0.8))
                curveGradient.addColorStop(0.46, rgba(themeVars["--confirmed-color"], 0.9))
                curveGradient.addColorStop(0.5, rgba(themeVars["--confirmed-color"], 1))
                curveGradient.addColorStop(0.54, rgba(themeVars["--confirmed-color"], 0.9))
                curveGradient.addColorStop(0.68, rgba(themeVars["--confirmed-color"], 0.8))
                curveGradient.addColorStop(1, rgba(themeVars["--confirmed-color"], 0))
                ctx.lineWidth = UI.bypassLineWidth; ctx.strokeStyle = curveGradient; ctx.stroke()
            } else {
                ctx.beginPath(); ctx.moveTo(left, sliderY); ctx.lineTo(right, sliderY)
                ctx.lineWidth = UI.sliderBaseWidth; ctx.strokeStyle = baseLineColor; ctx.stroke()
            }
            ctx.restore()

            if (sliderActive && selectedVisibleIndex >= 0 && visiblePoints[selectedVisibleIndex]) {
                const activePoint = visiblePoints[selectedVisibleIndex]
                const dayText = String(parseDate(activePoint.date).getDate())
                const bubbleTextWidth = ctx.measureText(dayText).width
                const bubbleW = Math.max(UI.activeBubbleMinWidth, bubbleTextWidth + UI.activeBubblePadX * 2)
                const bubbleH = UI.activeBubbleHeight
                const bubbleX = handleX - bubbleW / 2
                const bubbleY = sliderY - UI.bypassOffset - bubbleH - UI.activeBubbleGap
                roundedRectPath(ctx, bubbleX, bubbleY, bubbleW, bubbleH, bubbleH / 2)
                ctx.fillStyle = rgba(themeVars["--confirmed-color"], 0.95)
                ctx.fill()
                ctx.fillStyle = rgba(themeVars["--active-text-color"], 1)
                ctx.textAlign = "center"; ctx.textBaseline = "middle"
                ctx.fillText(dayText, handleX, bubbleY + bubbleH / 2 + 0.5)
            }

            const tooltipPoint = hoverIndex != null ? visiblePoints[hoverIndex] : null
            const tooltipCenterX = hoverIndex != null ? left + stepX * hoverIndex : 0

            if (tooltipPoint) {
                const titleText = formatDate(tooltipPoint.date)
                const line1 = `${countPrefix}: ${formatNumber(tooltipPoint.count)}`
                const line2 = `${areaPrefix}: ${formatNumber(tooltipPoint.area)}`
                ctx.font = `700 ${UI.tooltipTitleSize}px Inter, system-ui, sans-serif`
                const w1 = ctx.measureText(titleText).width
                ctx.font = `500 ${UI.tooltipTextSize}px Inter, system-ui, sans-serif`
                const w2 = ctx.measureText(line1).width
                const w3 = ctx.measureText(line2).width
                const tooltipW = Math.max(UI.tooltipMinWidth, Math.max(w1, w2, w3) + UI.tooltipPadX * 2)
                const tooltipH = UI.tooltipHeight
                let tooltipX = tooltipCenterX - tooltipW / 2
                tooltipX = clamp(tooltipX, left, right - tooltipW)
                const anchorTop = sliderActive
                    ? sliderY - UI.bypassOffset - UI.activeBubbleHeight - UI.activeBubbleGap
                    : sliderY - 4
                const tooltipY = anchorTop - tooltipH - UI.tooltipGap
                ctx.save()
                ctx.shadowColor = "rgba(0,0,0,0.10)"; ctx.shadowBlur = 16
                roundedRectPath(ctx, tooltipX, tooltipY, tooltipW, tooltipH, UI.tooltipRadius)
                ctx.fillStyle = "rgba(255,255,255,0.92)"; ctx.fill()
                ctx.restore()
                ctx.fillStyle = "rgba(17,24,39,0.95)"; ctx.textAlign = "left"; ctx.textBaseline = "top"
                ctx.font = `700 ${UI.tooltipTitleSize}px Inter, system-ui, sans-serif`
                ctx.fillText(titleText, tooltipX + UI.tooltipPadX, tooltipY + UI.tooltipPadY)
                ctx.font = `500 ${UI.tooltipTextSize}px Inter, system-ui, sans-serif`
                ctx.fillText(line1, tooltipX + UI.tooltipPadX, tooltipY + UI.tooltipPadY + 24)
                ctx.fillText(line2, tooltipX + UI.tooltipPadX, tooltipY + UI.tooltipPadY + 44)
            }

            roundedRectPath(ctx, handleX - UI.handleRadius, sliderY - UI.handleRadius, UI.handleRadius * 2, UI.handleRadius * 2, UI.handleRadius)
            ctx.fillStyle = sliderActive ? rgba(themeVars["--main-color"], 0.84) : rgba(themeVars["--main-color"], 0.55)
            ctx.fill()
            ctx.lineWidth = UI.handleBorderWidth
            ctx.strokeStyle = rgba(themeVars["--text-color"], sliderActive ? 0.24 : 0.18)
            ctx.stroke()
            ctx.save(); ctx.translate(handleX, sliderY); ctx.rotate(Math.PI / 4)
            ctx.beginPath(); ctx.rect(-UI.handleIconSize, -UI.handleIconSize, UI.handleIconSize * 2, UI.handleIconSize * 2)
            ctx.fillStyle = rgba(themeVars["--text-color"], 0.92); ctx.fill()
            ctx.restore()
            return
        }

        // ── REGION MODE ──
        if (!regionData.length) return

        const regionTop = top + 8
        const regionBottom = bottom - UI.regionBottomAxisOffset
        const regionHeight = regionBottom - regionTop
        const maxValue = Math.max(1, ...regionData.map((item) => item.count))
        const count = regionData.length
        const totalGap = UI.regionBarGap * Math.max(0, count - 1)
        const barWidth = Math.max(28, (chartWidth - totalGap) / Math.max(1, count))
        const totalWidth = barWidth * count + totalGap
        const startX = left + Math.max(0, (chartWidth - totalWidth) / 2)

        ctx.beginPath(); ctx.moveTo(left - 2, regionBottom + 26); ctx.lineTo(right + 2, regionBottom + 26)
        ctx.lineWidth = 1.5; ctx.strokeStyle = rgba(themeVars["--main-color"], 0.38); ctx.stroke()
        ctx.textAlign = "center"

        regionData.forEach((item, index) => {
            const ratio = item.count / maxValue
            const barHeight = Math.max(UI.regionBarMinHeight, ratio * regionHeight)
            const x = startX + index * (barWidth + UI.regionBarGap)
            const y = regionBottom - barHeight
            const isHover = hoverIndex === index
            const isActive = sliderActive && index === selectedRegionIndex
            const gradient = ctx.createLinearGradient(0, y, 0, regionBottom)
            gradient.addColorStop(0, isActive || isHover ? rgba(themeVars["--confirmed-color"], 0.62) : rgba(themeVars["--main-color"], 0.52))
            gradient.addColorStop(1, isActive || isHover ? rgba(themeVars["--confirmed-color"], 0.26) : rgba(themeVars["--main-color"], 0.18))
            roundedRectPath(ctx, x, y, barWidth, barHeight, UI.regionBarRadius)
            ctx.fillStyle = gradient; ctx.fill()
            if (isActive) {
                ctx.save()
                ctx.shadowColor = rgba(themeVars["--confirmed-color"], 0.35); ctx.shadowBlur = 16
                roundedRectPath(ctx, x, y, barWidth, barHeight, UI.regionBarRadius)
                ctx.strokeStyle = rgba(themeVars["--confirmed-color"], 0.85); ctx.lineWidth = 2; ctx.stroke()
                ctx.restore()
            }
        })

        ctx.font = `500 ${UI.axisLabelSize}px Inter, system-ui, sans-serif`
        ctx.textAlign = "center"; ctx.textBaseline = "middle"

        regionData.forEach((item, index) => {
            const barCenterX = startX + index * (barWidth + UI.regionBarGap) + barWidth / 2
            const isActive = sliderActive && index === selectedRegionIndex
            const isHover = hoverIndex === index
            const fitted = fitLabel(ctx, item.label, barWidth + UI.regionBarGap - 4)
            if (isHover && !isActive) {
                const textWidth = ctx.measureText(fitted).width
                const bgWidth = textWidth + UI.hoverDatePadX * 2
                const bgX = barCenterX - bgWidth / 2
                const bgY = sliderY - 18 - UI.hoverDateHeight / 2 + 1
                roundedRectPath(ctx, bgX, bgY, bgWidth, UI.hoverDateHeight, UI.hoverDateRadius)
                ctx.fillStyle = accentHoverBg; ctx.fill()
            }
            ctx.fillStyle = isActive || isHover ? accent : rgba(themeVars["--active-text-color"], 0.92)
            ctx.fillText(fitted, barCenterX, sliderY - 18)
        })

        const handleX = getHandleX()
        ctx.save(); ctx.lineCap = "round"; ctx.lineJoin = "round"

        if (sliderActive) {
            const sideOffset = UI.bypassHalfWidth
            const bypassStartX = Math.max(left, handleX - sideOffset)
            const bypassEndX = Math.min(right, handleX + sideOffset)
            const hiddenStartX = bypassStartX + (bypassEndX - bypassStartX) * UI.baseLineHiddenStartRatio
            const hiddenEndX = bypassStartX + (bypassEndX - bypassStartX) * UI.baseLineHiddenEndRatio

            if (hiddenStartX > left) {
                ctx.beginPath(); ctx.moveTo(left, sliderY); ctx.lineTo(hiddenStartX, sliderY)
                ctx.lineWidth = UI.sliderBaseWidth; ctx.strokeStyle = baseLineColor; ctx.stroke()
            }
            if (hiddenEndX < right) {
                ctx.beginPath(); ctx.moveTo(hiddenEndX, sliderY); ctx.lineTo(right, sliderY)
                ctx.lineWidth = UI.sliderBaseWidth; ctx.strokeStyle = baseLineColor; ctx.stroke()
            }
            if (bypassStartX > left) {
                ctx.beginPath(); ctx.moveTo(left, sliderY); ctx.lineTo(bypassStartX, sliderY)
                const leftGradient = ctx.createLinearGradient(left, 0, bypassStartX, 0)
                leftGradient.addColorStop(0, rgba(themeVars["--main-color"], 0.35))
                leftGradient.addColorStop(1, rgba(themeVars["--confirmed-color"], 0.55))
                ctx.lineWidth = UI.sliderBaseWidth; ctx.strokeStyle = leftGradient; ctx.stroke()
            }
            if (bypassEndX < right) {
                ctx.beginPath(); ctx.moveTo(bypassEndX, sliderY); ctx.lineTo(right, sliderY)
                const rightGradient = ctx.createLinearGradient(bypassEndX, 0, right, 0)
                rightGradient.addColorStop(0, rgba(themeVars["--confirmed-color"], 0.55))
                rightGradient.addColorStop(1, rgba(themeVars["--main-color"], 0.35))
                ctx.lineWidth = UI.sliderBaseWidth; ctx.strokeStyle = rightGradient; ctx.stroke()
            }
            drawBypassCurve(ctx, handleX, sliderY, UI.bypassOffset, UI.bypassHalfWidth)
            const curveGradient = ctx.createLinearGradient(handleX - sideOffset, 0, handleX + sideOffset, 0)
            curveGradient.addColorStop(0, rgba(themeVars["--confirmed-color"], 0))
            curveGradient.addColorStop(0.32, rgba(themeVars["--confirmed-color"], 0.2))
            curveGradient.addColorStop(0.46, rgba(themeVars["--confirmed-color"], 0.82))
            curveGradient.addColorStop(0.5, rgba(themeVars["--confirmed-color"], 1))
            curveGradient.addColorStop(0.54, rgba(themeVars["--confirmed-color"], 0.82))
            curveGradient.addColorStop(0.68, rgba(themeVars["--confirmed-color"], 0.2))
            curveGradient.addColorStop(1, rgba(themeVars["--confirmed-color"], 0))
            ctx.lineWidth = UI.bypassLineWidth; ctx.strokeStyle = curveGradient; ctx.stroke()
        } else {
            ctx.beginPath(); ctx.moveTo(left, sliderY); ctx.lineTo(right, sliderY)
            ctx.lineWidth = UI.sliderBaseWidth; ctx.strokeStyle = baseLineColor; ctx.stroke()
        }
        ctx.restore()

        if (sliderActive && activeRegion) {
            const bubbleText = `${formatNumber(activeRegion.count)}`
            ctx.font = `700 13px Inter, system-ui, sans-serif`
            const bubbleTextWidth = ctx.measureText(bubbleText).width + UI.activeBubblePadX * 2
            const bubbleW = Math.max(UI.activeBubbleMinWidth + 20, bubbleTextWidth)
            const bubbleH = UI.activeBubbleHeight
            const bubbleX = clamp(handleX - bubbleW / 2, left, right - bubbleW)
            const bubbleY = sliderY - UI.bypassOffset - bubbleH - UI.activeBubbleGap
            roundedRectPath(ctx, bubbleX, bubbleY, bubbleW, bubbleH, bubbleH / 2)
            ctx.fillStyle = rgba(themeVars["--confirmed-color"], 0.95); ctx.fill()
            ctx.fillStyle = rgba(themeVars["--active-text-color"], 1)
            ctx.textAlign = "center"; ctx.textBaseline = "middle"
            ctx.fillText(bubbleText, bubbleX + bubbleW / 2, bubbleY + bubbleH / 2 + 0.5)
        }

        const tooltipRegion = hoverIndex != null ? regionData[hoverIndex] || null : null
        const tooltipCenterX = hoverIndex != null && regionData.length > 1
            ? left + (chartWidth / (regionData.length - 1)) * hoverIndex : 0

        if (tooltipRegion) {
            const titleText = tooltipRegion.label
            const line1 = `${countPrefix}: ${formatNumber(tooltipRegion.count)}`
            const line2 = `${areaPrefix}: ${formatNumber(tooltipRegion.area)}`
            ctx.font = `700 ${UI.tooltipTitleSize}px Inter, system-ui, sans-serif`
            const w1 = ctx.measureText(titleText).width
            ctx.font = `500 ${UI.tooltipTextSize}px Inter, system-ui, sans-serif`
            const w2 = ctx.measureText(line1).width
            const w3 = ctx.measureText(line2).width
            const tooltipW = Math.max(UI.tooltipMinWidth, Math.max(w1, w2, w3) + UI.tooltipPadX * 2)
            const tooltipH = UI.tooltipHeight
            let tooltipX = tooltipCenterX - tooltipW / 2
            tooltipX = clamp(tooltipX, left, right - tooltipW)
            const anchorTop = sliderY - UI.bypassOffset - UI.activeBubbleHeight - UI.activeBubbleGap
            const tooltipY = anchorTop - tooltipH - UI.tooltipGap
            ctx.save()
            ctx.shadowColor = "rgba(0,0,0,0.10)"; ctx.shadowBlur = 16
            roundedRectPath(ctx, tooltipX, tooltipY, tooltipW, tooltipH, UI.tooltipRadius)
            ctx.fillStyle = "rgba(255,255,255,0.1)"; ctx.fill()
            ctx.restore()
            ctx.fillStyle = "rgba(17,24,39,0.95)"; ctx.textAlign = "left"; ctx.textBaseline = "top"
            ctx.font = `700 ${UI.tooltipTitleSize}px Inter, system-ui, sans-serif`
            ctx.fillText(titleText, tooltipX + UI.tooltipPadX, tooltipY + UI.tooltipPadY)
            ctx.font = `500 ${UI.tooltipTextSize}px Inter, system-ui, sans-serif`
            ctx.fillText(line1, tooltipX + UI.tooltipPadX, tooltipY + UI.tooltipPadY + 24)
            ctx.fillText(line2, tooltipX + UI.tooltipPadX, tooltipY + UI.tooltipPadY + 44)
        }

        roundedRectPath(ctx, handleX - UI.handleRadius, sliderY - UI.handleRadius, UI.handleRadius * 2, UI.handleRadius * 2, UI.handleRadius)
        ctx.fillStyle = sliderActive ? rgba(themeVars["--main-color"], 0.84) : rgba(themeVars["--main-color"], 0.55)
        ctx.fill()
        ctx.lineWidth = UI.handleBorderWidth
        ctx.strokeStyle = rgba(themeVars["--text-color"], sliderActive ? 0.24 : 0.18)
        ctx.stroke()
        ctx.save(); ctx.translate(handleX, sliderY); ctx.rotate(Math.PI / 4)
        ctx.beginPath(); ctx.rect(-UI.handleIconSize, -UI.handleIconSize, UI.handleIconSize * 2, UI.handleIconSize * 2)
        ctx.fillStyle = rgba(themeVars["--text-color"], 0.92); ctx.fill()
        ctx.restore()
    }, [
        size, mode, visiblePoints, regionData, getLang, themeVars, valueField, title,
        hoverIndex, sliderActive, selectedVisibleIndex, selectedRegionIndex, activeRegion,
        countPrefix, areaPrefix, getMetrics, getHandleX
    ])

    const getPointerIndex = useCallback((clientX: number): number => {
        const canvas = canvasRef.current
        if (!canvas) return -1
        const rect = canvas.getBoundingClientRect()
        const metrics = getMetrics()
        const x = clientX - rect.left
        if (mode === "region") {
            if (!regionData.length) return -1
            const totalGap = UI.regionBarGap * Math.max(0, regionData.length - 1)
            const barWidth = Math.max(28, (metrics.chartWidth - totalGap) / Math.max(1, regionData.length))
            const totalWidth = barWidth * regionData.length + totalGap
            const startX = metrics.left + Math.max(0, (metrics.chartWidth - totalWidth) / 2)
            let i = 0
            for (i = 0; i < regionData.length; i += 1) {
                const barX = startX + i * (barWidth + UI.regionBarGap)
                if (x >= barX && x <= barX + barWidth) return i
            }
            return -1
        }
        if (!visiblePoints.length) return -1
        return hitIndexByX(x, metrics.left, metrics.chartWidth, visiblePoints.length)
    }, [mode, visiblePoints.length, regionData.length, getMetrics])

    const pointerHitsHandle = useCallback((clientX: number, clientY: number): boolean => {
        const canvas = canvasRef.current
        if (!canvas) return false
        const rect = canvas.getBoundingClientRect()
        const metrics = getMetrics()
        const handleX = getHandleX()
        const x = clientX - rect.left
        const y = clientY - rect.top
        const dx = x - handleX
        const dy = y - metrics.sliderY
        return Math.sqrt(dx * dx + dy * dy) <= UI.handleHitRadius
    }, [getMetrics, getHandleX])

    const onWheel = useCallback((e: React.WheelEvent<HTMLCanvasElement>) => {
        if (mode === "region") {
            if (!regionData.length) return
            const canvas = canvasRef.current
            if (!canvas) return
            const rect = canvas.getBoundingClientRect()
            const metrics = getMetrics()
            const x = e.clientX - rect.left
            const y = e.clientY - rect.top
            const insideGraph = x >= metrics.left && x <= metrics.right && y >= metrics.top && y <= metrics.bottom
            if (!insideGraph) return
            e.preventDefault()
            const direction = e.deltaY > 0 ? 1 : -1
            setSliderActive(true)
            setSelectedRegionIndex((prev) => {
                const next = clamp(prev + direction, 0, Math.max(0, regionData.length - 1))
                const region = regionData[next]
                if (region) setPendingRegion(region.id_region)
                return next
            })
            return
        }
        if (!series.length || series.length <= VIEW_DAYS) return
        const canvas = canvasRef.current
        if (!canvas) return
        const rect = canvas.getBoundingClientRect()
        const metrics = getMetrics()
        const x = e.clientX - rect.left
        const y = e.clientY - rect.top
        const insideGraph = x >= metrics.left && x <= metrics.right && y >= metrics.top && y <= metrics.bottom
        if (!insideGraph) return
        e.preventDefault()
        const direction = e.deltaY > 0 ? 1 : -1
        const maxStart = Math.max(0, series.length - VIEW_DAYS)
        setSliderActive(true)
        setWindowStart((prevWindowStart) => {
            const nextWindowStart = clamp(prevWindowStart + direction, 0, maxStart)
            if (innerSelectedDate) {
                const currentSelectedIndex = series.findIndex((item) => item.date === innerSelectedDate)
                if (currentSelectedIndex >= 0) {
                    const nextSelectedIndex = clamp(currentSelectedIndex + direction, 0, series.length - 1)
                    const nextSelectedPoint = series[nextSelectedIndex]
                    if (nextSelectedPoint && nextSelectedPoint.date !== innerSelectedDate) {
                        setInnerSelectedDate(nextSelectedPoint.date)
                        setPendingDate(nextSelectedPoint.date)
                    }
                }
            } else {
                const nextVisible = series.slice(nextWindowStart, nextWindowStart + VIEW_DAYS)
                const middleIndex = Math.floor(nextVisible.length / 2)
                const middlePoint = nextVisible[middleIndex] || null
                if (middlePoint) { setInnerSelectedDate(middlePoint.date); setPendingDate(middlePoint.date) }
            }
            return nextWindowStart
        })
    }, [mode, regionData, series, innerSelectedDate, getMetrics])

    const onPointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
        const hitHandle = pointerHitsHandle(e.clientX, e.clientY)
        pointerDownOnHandleRef.current = hitHandle
        movedAfterDownRef.current = false
        draggingRef.current = true
        e.currentTarget.setPointerCapture(e.pointerId)
        const index = getPointerIndex(e.clientX)
        if (index >= 0) {
            setHoverIndex(index)
            if (mode === "region") { setSelectedRegionByIndex(index); return }
            if (!sliderActive || !hitHandle) setSelectedByIndex(index)
        }
    }

    const onPointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
        if (draggingRef.current) movedAfterDownRef.current = true
        const index = getPointerIndex(e.clientX)
        if (index >= 0) {
            setHoverIndex(index)
            if (draggingRef.current) {
                if (mode === "region") setSelectedRegionByIndex(index)
                else setSelectedByIndex(index)
            }
        } else { setHoverIndex(null) }
    }

    const onPointerUp = (e: React.PointerEvent<HTMLCanvasElement>) => {
        const clickedActiveHandle = pointerDownOnHandleRef.current && !movedAfterDownRef.current && sliderActive && pointerHitsHandle(e.clientX, e.clientY)
        if (clickedActiveHandle) { clearSelection(); setHoverIndex(null) }
        draggingRef.current = false
        pointerDownOnHandleRef.current = false
        movedAfterDownRef.current = false
        try { e.currentTarget.releasePointerCapture(e.pointerId) } catch (error) { }
    }

    const onPointerLeave = () => {
        draggingRef.current = false
        pointerDownOnHandleRef.current = false
        movedAfterDownRef.current = false
        setHoverIndex(null)
    }

    return (
        <div ref={wrapperRef} style={{
            width: "100%", height: "var(--content-height)", minWidth: 0, minHeight: 0,
            position: "relative", overflow: "hidden", borderRadius: `${UI.radius}px`,
            userSelect: "none", touchAction: "none"
        }}>
            <div style={{
                position: "absolute", top: `${UI.toggleTop}px`, right: `${UI.toggleRight}px`,
                zIndex: 2, display: "flex", gap: `${UI.toggleGap}px`, padding: "4px",
                borderRadius: "14px", backgroundColor: "rgba(0,0,0,0.08)"
            }}>
                <button type="button"
                    onClick={() => { setMode("daily"); setPendingRegion(""); setFilter((prev) => ({ ...prev, id_region: "" })) }}
                    style={{
                        border: "none", outline: "none", height: `${UI.toggleHeight}px`,
                        padding: `0 ${UI.togglePadX}px`, borderRadius: `${UI.toggleRadius}px`,
                        cursor: "pointer", fontWeight: 600, fontSize: "14px",
                        color: mode === "daily" ? "rgba(17,24,39,1)" : "rgba(255,255,255,0.95)",
                        backgroundColor: mode === "daily"
                            ? `rgba(${themeVars["--confirmed-color"]}, 1)`
                            : `rgba(${themeVars["--main-color"]}, 0.35)`
                    }}>
                    {dailyButtonText}
                </button>
                <button type="button"
                    onClick={() => { setMode("region"); setPendingDate(null); setFilter((prev) => ({ ...prev, from_date: "", to_date: "" })) }}
                    style={{
                        border: "none", outline: "none", height: `${UI.toggleHeight}px`,
                        padding: `0 ${UI.togglePadX}px`, borderRadius: `${UI.toggleRadius}px`,
                        cursor: "pointer", fontWeight: 600, fontSize: "14px",
                        color: mode === "region" ? "rgba(17,24,39,1)" : "rgba(255,255,255,0.95)",
                        backgroundColor: mode === "region"
                            ? `rgba(${themeVars["--confirmed-color"]}, 1)`
                            : `rgba(${themeVars["--main-color"]}, 0.35)`
                    }}>
                    {regionButtonText}
                </button>
            </div>
            <canvas ref={canvasRef}
                onPointerDown={onPointerDown} onPointerMove={onPointerMove}
                onPointerUp={onPointerUp} onPointerCancel={onPointerUp}
                onPointerLeave={onPointerLeave} onWheel={onWheel}
                style={{ width: "100%", height: "100%", display: "block", cursor: draggingRef.current ? "grabbing" : "grab" }}
            />
        </div>
    )
}