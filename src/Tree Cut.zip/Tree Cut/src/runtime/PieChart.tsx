/** @jsx jsx */
import { React, jsx } from "jimu-core"
import FeatureLayer from "@arcgis/core/layers/FeatureLayer"
import { LangKey, Translations } from "../configs/translation"
import { CSSVars } from "../configs/theme"

export interface StatusStat {
    status: 0 | 1 | 2
    count: number
}

export interface FilterState {
    status: StatusStat["status"] | ""
    [key: string]: any
}

interface PieChartWidgetProps {
    stats: StatusStat[]
    total: number
    getLang: LangKey
    themeVars: CSSVars              // ← вместо getTheme
    getFilter: FilterState
    setFilter: React.Dispatch<React.SetStateAction<FilterState>>
}

interface PieChartProps {
    polygonRef: React.MutableRefObject<FeatureLayer>
    getLang: LangKey
    themeVars: CSSVars              // ← вместо getTheme
    getFilter: FilterState
    setFilter: React.Dispatch<React.SetStateAction<FilterState>>
}

const STATUS_KEY_MAP: Record<StatusStat["status"], "confirmed" | "not_confirmed" | "in_process"> = {
    0: "in_process",
    1: "not_confirmed",
    2: "confirmed",
}

const tr = (key: string, lang: LangKey): string => {
    const val = (Translations as any)[key]
    return val?.[lang] ?? key
}

const COLOR_VAR: Record<"confirmed" | "not_confirmed" | "in_process", string> = {
    confirmed: "--confirmed-color",
    not_confirmed: "--no-confirmed-color",
    in_process: "--in-process-color",
}

const LEGEND_LABEL_KEY: Record<"confirmed" | "not_confirmed" | "in_process", string> = {
    in_process: "pieInTheProcess",
    confirmed: "pieConfirmed",
    not_confirmed: "pieUnverified",
}

const LEGEND_ORDER: StatusStat["status"][] = [0, 2, 1]
const SLICE_ORDER: StatusStat["status"][] = [2, 0, 1]

const VBOX = 220
const CX = VBOX / 2
const CY = VBOX / 2
const OUTER = 96
const INNER = 60
const GAP_DEG = 2

function polarToXY(cx: number, cy: number, r: number, angleDeg: number) {
    const rad = ((angleDeg - 90) * Math.PI) / 180
    return { x: cx + r * Math.cos(rad), y: cy + r * Math.sin(rad) }
}

function donutPath(cx: number, cy: number, outerR: number, innerR: number, startDeg: number, endDeg: number): string {
    const sweep = Math.min(endDeg - startDeg, 359.99)
    const large = sweep > 180 ? 1 : 0
    const o1 = polarToXY(cx, cy, outerR, startDeg)
    const o2 = polarToXY(cx, cy, outerR, startDeg + sweep)
    const i1 = polarToXY(cx, cy, innerR, startDeg + sweep)
    const i2 = polarToXY(cx, cy, innerR, startDeg)
    return [
        `M ${o1.x.toFixed(2)} ${o1.y.toFixed(2)}`,
        `A ${outerR} ${outerR} 0 ${large} 1 ${o2.x.toFixed(2)} ${o2.y.toFixed(2)}`,
        `L ${i1.x.toFixed(2)} ${i1.y.toFixed(2)}`,
        `A ${innerR} ${innerR} 0 ${large} 0 ${i2.x.toFixed(2)} ${i2.y.toFixed(2)}`,
        "Z",
    ].join(" ")
}

const PieChartWidget: React.FC<PieChartWidgetProps> = ({
    stats, total, getLang, themeVars, getFilter, setFilter,
}) => {
    // Читаем цвета напрямую из themeVars
    const rgba = (varName: string, alpha = 1) =>
        `rgba(${themeVars[varName as `--${string}`] ?? "255,255,255"}, ${alpha})`

    const selected = getFilter.status
    const [hoveredLegend, setHoveredLegend] = React.useState<StatusStat["status"] | null>(null)
    const [hoveredSlice, setHoveredSlice] = React.useState<StatusStat["status"] | null>(null)

    const handleClick = React.useCallback((key: StatusStat["status"]) => {
        const next: StatusStat["status"] | "" = selected === key ? "" : key
        setFilter((prev) => ({ ...prev, status: next }))
    }, [selected, setFilter])

    const isActive = (key: StatusStat["status"]) => selected === "" || selected === key

    const slices = React.useMemo(() => {
        let cursor = 0
        return SLICE_ORDER.map((key) => {
            const stat = stats.find((s) => s.status === key)
            const count = stat?.count ?? 0
            const pct = total > 0 ? (count / total) * 100 : 0
            const deg = (pct / 100) * 360
            const start = cursor
            cursor += deg
            return { key, count, pct, startDeg: start, endDeg: cursor }
        })
    }, [stats, total])

    const centerPct = selected !== ""
        ? Math.round(slices.find((s) => s.key === selected)?.pct ?? 0) + "%"
        : "100%"

    return (
        <div style={{
            width: "100%", height: "var(--content-height)", display: "flex",
            flexDirection: "row", background: "transparent",
            fontFamily: "Inter, 'Segoe UI', system-ui, sans-serif",
            boxSizing: "border-box", overflow: "hidden",
        }}>
            {/* Left: title + legend */}
            <div style={{ width: "50%", display: "flex", flexDirection: "column", boxSizing: "border-box", padding: "20px" }}>
                <div style={{
                    color: rgba("--text-color"), fontWeight: 700, fontSize: 20,
                    marginBottom: 20, letterSpacing: 0.3, flexShrink: 0, textAlign: "center",
                    transition: "color 0.4s",
                }}>
                    {tr("pieChartTitle", getLang)}
                </div>

                <div style={{ display: "flex", flexDirection: "column", justifyContent: "center", flex: 1, gap: 10, paddingLeft: 4, boxSizing: "border-box" }}>
                    {LEGEND_ORDER.map((key) => {
                        const cfgKey = STATUS_KEY_MAP[key]
                        const colorRgb = themeVars[COLOR_VAR[cfgKey] as `--${string}`]
                        const solidBg = `rgba(${colorRgb},1)`
                        const slice = slices.find((x) => x.key === key)!
                        const active = isActive(key)
                        const hovered = hoveredLegend === key
                        const label = tr(LEGEND_LABEL_KEY[cfgKey], getLang)

                        return (
                            <div key={key}
                                onClick={() => handleClick(key)}
                                onMouseEnter={() => setHoveredLegend(key)}
                                onMouseLeave={() => setHoveredLegend(null)}
                                style={{
                                    display: "flex", alignItems: "center", justifyContent: "space-between",
                                    cursor: "pointer", borderRadius: 10, padding: "7px 10px",
                                    transition: "box-shadow 0.2s, background 0.2s",
                                    background: hovered ? `rgba(${colorRgb},0.1)` : "transparent",
                                    boxShadow: hovered ? `0 0 14px 4px rgba(${colorRgb},0.4)` : "none",
                                }}>
                                <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                                    <div style={{
                                        width: 26, height: 26, borderRadius: 6, flexShrink: 0,
                                        position: "relative", overflow: "hidden",
                                        background: active ? solidBg : "transparent",
                                        border: active ? "none" : `2px solid ${solidBg}`,
                                        opacity: active ? 1 : 0.6, transition: "opacity 0.2s",
                                    }}>
                                        {!active && (
                                            <svg width="26" height="26" style={{ position: "absolute", inset: 0 }}>
                                                <defs>
                                                    <pattern id={`sw-hatch-${key}`} patternUnits="userSpaceOnUse" width="4" height="4" patternTransform="rotate(45)">
                                                        <rect width="4" height="4" fill={solidBg} fillOpacity="0.1" />
                                                        <line x1="0" y1="0" x2="0" y2="4" stroke={solidBg} strokeWidth="2" strokeOpacity="0.8" />
                                                    </pattern>
                                                </defs>
                                                <rect width="26" height="26" fill={`url(#sw-hatch-${key})`} />
                                            </svg>
                                        )}
                                    </div>
                                    <span style={{ color: rgba("--text-color", active ? 1 : 0.45), fontSize: 15, transition: "color 0.4s" }}>
                                        {label} ({Math.round(slice.pct)}%)
                                    </span>
                                </div>
                                <span style={{
                                    color: rgba("--text-color", active ? 1 : 0.45), fontSize: 15,
                                    fontWeight: 600, marginLeft: 16, whiteSpace: "nowrap", transition: "color 0.4s",
                                }}>
                                    {slice.count.toLocaleString()}&nbsp;/&nbsp;{total.toLocaleString()}
                                </span>
                            </div>
                        )
                    })}
                </div>
            </div>

            {/* Donut */}
            <div style={{ width: "50%", maxHeight: "100%", display: "flex", alignItems: "center", justifyContent: "center", boxSizing: "border-box", padding: "20px 20px 20px 0" }}>
                <svg viewBox={`0 0 ${VBOX} ${VBOX}`} style={{ width: "100%", height: "100%", overflow: "visible" }}>
                    <defs>
                        {SLICE_ORDER.map((key) => {
                            const cfgKey = STATUS_KEY_MAP[key]
                            const colorRgb = themeVars[COLOR_VAR[cfgKey] as `--${string}`]
                            return (
                                <pattern key={key} id={`donut-hatch-${key}`} patternUnits="userSpaceOnUse" width="5" height="5" patternTransform="rotate(45)">
                                    <rect width="5" height="5" fill={`rgba(${colorRgb},0.08)`} />
                                    <line x1="0" y1="0" x2="0" y2="5" stroke={`rgba(${colorRgb},0.7)`} strokeWidth="2.2" />
                                </pattern>
                            )
                        })}
                        {SLICE_ORDER.map((key) => {
                            const cfgKey = STATUS_KEY_MAP[key]
                            const colorRgb = themeVars[COLOR_VAR[cfgKey] as `--${string}`]
                            return (
                                <filter key={key} id={`glow-${key}`} x="-40%" y="-40%" width="180%" height="180%">
                                    <feDropShadow dx="0" dy="0" stdDeviation="7" floodColor={`rgba(${colorRgb},1)`} floodOpacity="0.8" />
                                </filter>
                            )
                        })}
                    </defs>

                    {slices.map(({ key, startDeg, endDeg, pct }) => {
                        if (pct <= 0) return null
                        const cfgKey = STATUS_KEY_MAP[key]
                        const colorRgb = themeVars[COLOR_VAR[cfgKey] as `--${string}`]
                        const active = isActive(key)
                        const hov = hoveredSlice === key
                        const outerR = hov ? OUTER + 7 : OUTER
                        const fill = active ? `rgba(${colorRgb},1)` : `url(#donut-hatch-${key})`
                        return (
                            <path key={key}
                                d={donutPath(CX, CY, outerR, INNER, startDeg + GAP_DEG / 2, endDeg - GAP_DEG / 2)}
                                fill={fill} opacity={active ? 1 : 0.55}
                                filter={hov ? `url(#glow-${key})` : undefined}
                                style={{ cursor: "pointer", transition: "opacity 0.2s" }}
                                onMouseEnter={() => setHoveredSlice(key)}
                                onMouseLeave={() => setHoveredSlice(null)}
                                onClick={() => handleClick(key)}
                            />
                        )
                    })}

                    <circle cx={CX} cy={CY} r={INNER - 2} fill={rgba("--main-color")} />

                    <text x={CX} y={CY - 6} textAnchor="middle"
                        fill={`rgba(${themeVars["--text-color"]},1)`}
                        fontSize="24" fontWeight="700"
                        fontFamily="Inter, 'Segoe UI', system-ui, sans-serif">
                        {centerPct}
                    </text>

                    <text x={CX} y={CY + 16} textAnchor="middle"
                        fill={`rgba(${themeVars["--text-color"]},0.65)`}
                        fontSize="13"
                        fontFamily="Inter, 'Segoe UI', system-ui, sans-serif">
                        {tr("pieInformation", getLang)}
                    </text>
                </svg>
            </div>
        </div>
    )
}

export default function PieChart({ polygonRef, getLang, themeVars, getFilter, setFilter }: PieChartProps): JSX.Element {
    const [stats, setStats] = React.useState<StatusStat[]>([])
    const [total, setTotal] = React.useState(0)

    React.useEffect(() => {
        if (!polygonRef?.current) return
        polygonRef.current
            .queryFeatures({
                where: "1=1",
                returnGeometry: false,
                groupByFieldsForStatistics: ["status"],
                outStatistics: [{ statisticType: "count", onStatisticField: "area", outStatisticFieldName: "count" }],
            })
            .then((result: any) => {
                const mapped: StatusStat[] = result.features.map((f: any) => ({
                    status: f.attributes.status as StatusStat["status"],
                    count: f.attributes.count as number,
                }))
                setStats(mapped)
                setTotal(mapped.reduce((acc, s) => acc + s.count, 0))
            })
            .catch((err: any) => console.error("Query failed PieChart:", err))
    }, [polygonRef, getFilter])

    return (
        <PieChartWidget
            stats={stats} total={total} getLang={getLang}
            themeVars={themeVars}
            getFilter={getFilter} setFilter={setFilter}
        />
    )
}