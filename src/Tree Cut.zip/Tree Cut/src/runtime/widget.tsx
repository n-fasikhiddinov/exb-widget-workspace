/** @jsx jsx */
import { React, jsx } from "jimu-core";
import MapView from "@arcgis/core/views/MapView";
import FeatureLayer from "@arcgis/core/layers/FeatureLayer";
import "./style.css";

import { filterStruct, uniqueIdField, buildWhereQuery } from "../configs/config";
import { Translations, LangKey } from "../configs/translation";
import { Theme, ThemeKey, CSSVars, buildAutoTheme } from "../configs/theme"
import {
    LogoIcon,
    DailyInformationIcon,
    ObjectAreaIcon,
    ObjectCountIcon,
} from "../configs/icons";

import CustomMap from "./CustomMap/CustomMap";
import Buttons from "./Buttons/Buttons";
import Popup from "./Popup/Popup";
import Graph from "./Graph";
import PieChart from "./PieChart";
import Table from "./Table/Table";

export default function Widget() {
    const polygonUrl = "https://gis.uzspace.uz/uzspacesrvr/rest/services/TreeCut/FeatureServer/0"
    const polygonRef = React.useRef<FeatureLayer>(new FeatureLayer({
        id: "mainPolygon",
        url: polygonUrl,
        outFields: [uniqueIdField, "status"],
        renderer: {
            type: "unique-value",
            field: "status",
            uniqueValueInfos: [
                {
                    value: 0,
                    symbol: {
                        type: "simple-fill",
                        color: [...Theme["main"]["--in-process-color"].split(",").map(v => Number(v.trim())), 0.3],
                        outline: { type: "simple-line", color: [...Theme["main"]["--in-process-color"].split(",").map(v => Number(v.trim())), 1], width: 3 }
                    }
                },
                {
                    value: 1,
                    symbol: {
                        type: "simple-fill",
                        color: [...Theme["main"]["--no-confirmed-color"].split(",").map(v => Number(v.trim())), 0.3],
                        outline: { type: "simple-line", color: [...Theme["main"]["--no-confirmed-color"].split(",").map(v => Number(v.trim())), 1], width: 3 }
                    }
                },
                {
                    value: 2,
                    symbol: {
                        type: "simple-fill",
                        color: [...Theme["main"]["--confirmed-color"].split(",").map(v => Number(v.trim())), 0.3],
                        outline: { type: "simple-line", color: [...Theme["main"]["--confirmed-color"].split(",").map(v => Number(v.trim())), 1], width: 3 }
                    }
                },
            ]
        }
    }))

    const [getMap, setMap] = React.useState<MapView | null>(null)
    const [getLang, setLang] = React.useState<LangKey>("UZ" as LangKey)
    const [getTheme, setTheme] = React.useState<ThemeKey>("main" as ThemeKey)

    // Отдельное состояние для реальных CSS-переменных
    // При auto — обновляется динамически через палитру карты
    // При статичных темах — просто Theme[getTheme]
    const [themeVars, setThemeVars] = React.useState<CSSVars>(Theme["auto"])

    const [getSelectedPoly, setSelectedPoly] = React.useState<string>("")
    const [getFilter, setFilter] = React.useState<filterStruct>({
        id_country: "",
        id_region: "",
        id_distric: "",
        from_date: "",
        to_date: "",
        status: "",
    })
    const [getIndicatorData, setIndicatorData] = React.useState({
        count: 0,
        sum: 0,
        dailyCount: 0
    })

    // Когда тема меняется на статичную — сразу берём из Theme
    // Когда auto — ждём первой палитры с карты (themeVars обновится через handlePaletteChange)
    React.useEffect(() => {
        if (getTheme !== "auto") {
            setThemeVars(Theme[getTheme])
        }
    }, [getTheme])

    // Callback из CustomMap: новая палитра → пересчитываем тему
    const handlePaletteChange = React.useCallback((palette: string[]) => {
        if (getTheme !== "auto") return
        setThemeVars(buildAutoTheme(palette))
    }, [getTheme])

    React.useEffect(() => {
        polygonRef.current.queryFeatures({
            where: `1=1 AND ${buildWhereQuery(getFilter)}`,
            returnGeometry: false,
            outStatistics: [
                { statisticType: "count", onStatisticField: "area", outStatisticFieldName: "count" },
                { statisticType: "sum", onStatisticField: "area", outStatisticFieldName: "sum" },
            ]
        })
            .then((result: any) => {
                const stats = result.features[0].attributes
                setIndicatorData(prev => ({ ...prev, count: stats.count, sum: stats.sum }))
            })
            .catch((error: any) => console.error("Query failed Widget 1:", error))

        const now = new Date()
        const pad = (n: number) => String(n).padStart(2, "0")
        const startOfDay = `timestamp '${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())} 00:00:00'`
        const endOfDay = `timestamp '${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())} 23:59:59'`

        polygonRef.current.queryFeatures({
            where: `date >= ${startOfDay} AND date <= ${endOfDay}`,
            returnGeometry: false,
            outStatistics: [
                { statisticType: "count", onStatisticField: "area", outStatisticFieldName: "count" }
            ]
        })
            .then((result: any) => {
                const stats = result.features[0].attributes
                setIndicatorData(prev => ({ ...prev, dailyCount: stats.count }))
            })
            .catch((error: any) => console.error("Query failed Widget 2:", error))
    }, [getFilter])

    // themeVars используем для style на корневом div
    // Theme[getTheme] используем только там где нужен конкретный ключ (иконки, renderer)
    // Для иконок — берём из themeVars напрямую, чтобы они тоже реагировали на auto
    return (
        <div style={themeVars as React.CSSProperties} className="mainArea">
            <CustomMap
                getFilter={getFilter}
                polygonRef={polygonRef}
                getSelectedPoly={getSelectedPoly}
                setSelectedPoly={setSelectedPoly}
                getTheme={getTheme}
                getLang={getLang}
                getMap={getMap}
                setMap={setMap}
                onPaletteChange={handlePaletteChange}
            />

            {getSelectedPoly !== "" && <Popup
                getFilter={getFilter}
                getLang={getLang}
                getSelectedPoly={getSelectedPoly}
                setSelectedPoly={setSelectedPoly}
                polygonRef={polygonRef}
            />}

            <div className="logo">
                <LogoIcon
                    size={["160px", "60px"]}
                    color={`rgb(${themeVars["--text-color"]})`}
                />
            </div>

            <div className="pageBtns" style={{ display: "none" }}>
                <div className="pageBtn active">{Translations["mainPage"][getLang]}</div>
                <div className="pageBtn">{Translations["statisticPage"][getLang]}</div>
            </div>

            <Buttons
                polygonRef={polygonRef}
                setSelectedPoly={setSelectedPoly}
                themeVars={themeVars}        // ← вместо getTheme
                getTheme={getTheme}          // ← getTheme оставляем только для логики переключения
                setTheme={setTheme}
                getLang={getLang}
                setLang={setLang}
                setFilter={setFilter}
            />

            <div className="indicators">
                <div className="indicator">
                    <div className="indicatorLogo">
                        <ObjectCountIcon
                            size="40px"
                            color={`rgb(${themeVars["--main-color"]})`}
                        />
                    </div>
                    <div className="indicatorInfo">
                        <div className="indicatorTitle">{Translations["indicatorCount"][getLang]}</div>
                        <div className="indicatorValue">{getIndicatorData.count}</div>
                    </div>
                </div>
                <div className="indicator">
                    <div className="indicatorLogo">
                        <ObjectAreaIcon
                            size="40px"
                            color={`rgb(${themeVars["--main-color"]})`}
                        />
                    </div>
                    <div className="indicatorInfo">
                        <div className="indicatorTitle">{Translations["indicatorArea"][getLang]}</div>
                        <div className="indicatorValue">
                            {(getIndicatorData.sum ?? 0).toLocaleString("ru-RU")}
                        </div>
                    </div>
                </div>
                <div className="indicator">
                    <div className="indicatorLogo">
                        <DailyInformationIcon
                            size="40px"
                            color={`rgb(${themeVars["--main-color"]})`}
                        />
                    </div>
                    <div className="indicatorInfo">
                        <div className="indicatorTitle">{Translations["dailyReport"][getLang]}</div>
                        <div className="indicatorValue">{getIndicatorData.dailyCount}</div>
                    </div>
                </div>
            </div>

            <div className="contentSection">
                <div className="table">
                    <Table
                        getLang={getLang}
                        themeVars={themeVars}        // ← вместо getTheme
                        polygonRef={polygonRef}
                        getFilter={getFilter}
                        setSelectedPoly={setSelectedPoly}
                    />
                </div>
                <div className="pieChart">
                    <PieChart
                        getLang={getLang}
                        themeVars={themeVars}        // ← вместо getTheme
                        polygonRef={polygonRef}
                        getFilter={getFilter}
                        setFilter={setFilter}
                    />
                </div>
                <div className="graph">
                    <Graph
                        setFilter={setFilter}
                        polygonRef={polygonRef}
                        getLang={getLang}
                        themeVars={themeVars}        // ← вместо getTheme
                    />
                </div>
            </div>
        </div>
    )
}