import { React } from "jimu-core"
import "./Popup.css"

import FeatureLayer from "@arcgis/core/layers/FeatureLayer"

import { LangKey, Translations } from "../../configs/translation"
import { filterStruct, uniqueIdField, uniqueIdQuery } from "../../configs/config"

interface PopupProps {
    getLang: LangKey
    getSelectedPoly: string
    setSelectedPoly: (value: string) => void
    polygonRef: React.MutableRefObject<FeatureLayer>
    getFilter: filterStruct
}

const ANIM_DURATION = 400
const HOLD_DURATION = 200

type Phase = "idle" | "forward" | "hold" | "backward"

export default function Popup({
    getLang,
    getSelectedPoly,
    polygonRef,
    getFilter,
    setSelectedPoly
}: PopupProps) {
    const [getPopupInfo, setPopupInfo] = React.useState({})
    const [phase, setPhase] = React.useState<Phase>("idle")
    const timerRef = React.useRef<any>(null)

    React.useEffect(() => {
        if (getSelectedPoly === "") {
            setPopupInfo({})
            return
        }
        polygonRef.current.queryFeatures({
            where: uniqueIdQuery(getSelectedPoly),
            returnGeometry: false,
            outFields: ["*"]
        })
            .then((result: any) => {
                setPopupInfo(result.features[0].attributes)
            })
            .catch((error: any) => console.error("Query failed Popup:", error))
    }, [getSelectedPoly])

    React.useEffect(() => {
        return () => clearTimeout(timerRef.current)
    }, [])

    React.useEffect(() => {
        console.log(getFilter);
        console.log(getPopupInfo);

        if (!getSelectedPoly || Object.keys(getPopupInfo).length === 0) return

        const mismatch = Object.entries(getFilter).some(([key, filterVal]) => {
            // Пропускаем пустые значения фильтра (не заданы)
            if (filterVal === "" || filterVal === null || filterVal === undefined) return false
            // status = 0 тоже считаем "не задан"
            if (key === "status" && filterVal === 0) return false

            const polyVal = getPopupInfo[key]
            // Приводим к строке для сравнения
            return String(polyVal) !== String(filterVal)
        })

        if (mismatch) {
            setSelectedPoly("")
        }
    }, [getFilter])

    const handleCopy = () => {
        if (phase !== "idle") return

        // Копируем текст
        const textToCopy = String(getPopupInfo[uniqueIdField] ?? "")
        navigator.clipboard.writeText(textToCopy).catch(() => {
            const el = document.createElement("textarea")
            el.value = textToCopy
            document.body.appendChild(el)
            el.select()
            document.execCommand("copy")
            document.body.removeChild(el)
        })

        // Фаза 1: forward — оба текста анимируются одновременно
        setPhase("forward")

        // Фаза 2: hold — анимация закончилась, держим "Скопировано"
        timerRef.current = setTimeout(() => {
            setPhase("hold")

            // Фаза 3: backward — возвращаем всё обратно
            timerRef.current = setTimeout(() => {
                setPhase("backward")

                // Фаза 4: idle — всё вернулось
                timerRef.current = setTimeout(() => {
                    setPhase("idle")
                }, ANIM_DURATION)
            }, HOLD_DURATION)
        }, ANIM_DURATION)
    }

    // Классы для оригинального текста
    const origClass = "clipText " + (() => {
        switch (phase) {
            case "idle": return "clipText--orig-idle"
            case "forward": return "clipText--orig-forward"
            case "hold": return "clipText--copy-idle"   // скрыт (переиспользуем hidden)
            case "backward": return "clipText--orig-backward"
        }
    })()

    // Классы для текста "Скопировано"
    const copiedClass = "clipText clipText--copied " + (() => {
        switch (phase) {
            case "idle": return "clipText--copy-idle"
            case "forward": return "clipText--copy-forward"
            case "hold": return "clipText--orig-idle"   // полностью виден
            case "backward": return "clipText--copy-backward"
        }
    })()

    return <div className="mainPopupArea">
        <div className="popupInfoBlock">
            <div className="popupInfoTitle">{Translations["popupTitle"][getLang]}</div>
            <div className="popupInfoBlock">
                {Object.entries(getPopupInfo).map((value: any) => {
                    if (["after", "before", "gid", "screenshot", "tax", "act", "id_country", "subject", "id_mahalla", "type_tree", "comment", "insp_tree", "insp_date", "count_tree"].includes(value[0])) return false
                    return <div className="popupInfoRow" key={value[0]}>
                        {/* <div className="popupInfoKey">{value[0]}</div> */}
                        <div className="popupInfoKey">{Translations?.[value[0]]?.[getLang] ?? value[0]}</div>
                        <div className="popupInfoValue">{Translations?.[value[1]]?.[getLang] ?? value[1]}</div>
                    </div>
                }).filter((item: any) => item)}
            </div>
        </div>

        <div className="imageBlock">
            <div className="imageContent">
                <div className="imageTitle">{Translations["beforeText"][getLang]}</div>
                <div className="imageArea"></div>
            </div>
            <div className="imageContent">
                <div className="imageTitle">{Translations["afterText"][getLang]}</div>
                <div className="imageArea"></div>
            </div>
        </div>

        <div className="copyBlock" onClick={handleCopy}>
            <span className={origClass}>
                {getPopupInfo[uniqueIdField]}
            </span>
            <span className={copiedClass}>
                {Translations["copiedText"][getLang]}
            </span>
        </div>
    </div>
}