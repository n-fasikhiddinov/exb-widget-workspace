import { React } from "jimu-core";
import "./LanguageButton.css";

import { LanguageIcon, CheckIcon, CloseIcon } from "../../../configs/icons";
import { Translations, LangKey } from "../../../configs/translation";
import { CSSVars } from "../../../configs/theme";

interface LanguageButtonProps {
    getButtonsStatus: boolean;
    setButtonsStatus: (value: boolean) => void;
    getLang: LangKey;
    setLang: (value: LangKey) => void;
    themeVars: CSSVars;             // ← вместо getTheme
}

export default function LanguageButton({
    getButtonsStatus,
    setButtonsStatus,
    getLang,
    setLang,
    themeVars,
}: LanguageButtonProps) {
    const iconColor = `rgb(${themeVars["--main-color"]})`

    return (
        <div className="button">
            <div
                className={`buttonLogo ${getButtonsStatus && "active"}`}
                onClick={() => setButtonsStatus(!getButtonsStatus)}
            >
                {getButtonsStatus ? (
                    <CloseIcon size="30px" color={iconColor} />
                ) : (
                    <LanguageIcon size="30px" color={iconColor} />
                )}
            </div>

            {getButtonsStatus && (
                <div className="languageSelector">
                    <div className="languageSelectorTitle">
                        {Translations["langsTitle"][getLang]}
                    </div>
                    {Object.entries(Translations["langsName"]).map(
                        (option: [string, string], index: number) => (
                            <div
                                key={index}
                                className={`languageSelectorOption ${option[0] === getLang && "active"}`}
                                onClick={() => setLang(option[0] as LangKey)}
                            >
                                {option[1]}
                                {option[0] === getLang && (
                                    <CheckIcon size="30px" color={iconColor} />
                                )}
                            </div>
                        )
                    )}
                </div>
            )}
        </div>
    );
}