import { React } from "jimu-core";
import "./SearchButton.css";

import { SearchIcon, CloseIcon } from "../../../configs/icons";
import { Translations, LangKey } from "../../../configs/translation";
import { CSSVars } from "../../../configs/theme";

interface SearchButtonProps {
    setSelectedPoly: (value: string) => void;
    getButtonsStatus: "" | "inInput" | "outInput";
    setButtonsStatus: (value: "" | "inInput" | "outInput") => void;
    getLang: LangKey;
    themeVars: CSSVars;             // ← вместо getTheme
}

export default function SearchButton({
    setSelectedPoly,
    getButtonsStatus,
    setButtonsStatus,
    getLang,
    themeVars,
}: SearchButtonProps) {
    const [getSearchInput, setSearchInput] = React.useState<string>("")

    const iconColor = `rgb(${themeVars["--main-color"]})`

    return (
        <div className="button">
            <div
                className={`buttonLogo ${getButtonsStatus === "inInput" && "active"}`}
                onClick={() => {
                    setButtonsStatus(getButtonsStatus === "inInput" ? "outInput" : "inInput")
                    if (getButtonsStatus === "inInput") {
                        setSelectedPoly("")
                        setSearchInput("")
                    }
                }}
            >
                {getButtonsStatus !== "inInput" ? (
                    <SearchIcon size="30px" color={iconColor} />
                ) : (
                    <CloseIcon size="30px" color={iconColor} />
                )}
            </div>

            <div className="searchInputArea" style={{ animationName: getButtonsStatus }}>
                <input
                    value={getSearchInput}
                    className="tempInput"
                    placeholder={Translations["search"][getLang]}
                    type="text"
                    onChange={(value: any) => setSearchInput(value.target.value)}
                    onKeyDown={(event: any) => {
                        if (event.keyCode === 13) {
                            setSelectedPoly(event.target.value)
                            setSearchInput(event.target.value)
                        }
                    }}
                />
            </div>
        </div>
    );
}