import { React } from "jimu-core"
import { LangKey, Translations } from "../../../configs/translation"

interface SelectorProps {
    className: string
    option: string
    options: string[]
    onChange: (item: string) => void
    placeholder?: string
    getLang: LangKey
}

export default function Selector({
    className,
    option,
    options,
    onChange,
    placeholder = "Tanlang",
    getLang
}: SelectorProps) {
    const [showOptions, toggleOptions] = React.useState<boolean>(false)
    const rootRef = React.useRef<HTMLDivElement | null>(null)

    React.useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (!rootRef.current) return
            if (!rootRef.current.contains(event.target as Node)) {
                toggleOptions(false)
            }
        }

        document.addEventListener("mousedown", handleClickOutside)
        return () => {
            document.removeEventListener("mousedown", handleClickOutside)
        }
    }, [])

    return (
        <div ref={rootRef} className={className}>
            <div
                className={`selectedOption ${showOptions ? "active" : ""}`}
                onClick={() => {
                    toggleOptions((prev) => !prev)
                }}
            >
                <span className={`selectedOptionText ${!option ? "placeholder" : ""}`}>
                    {Translations[option][getLang] || placeholder}
                </span>

                <span className={`selectedOptionArrow ${showOptions ? "open" : ""}`}>
                    ❯
                </span>
            </div>

            {showOptions && (
                <div className="selectorOptions">
                    {options.length > 0 ? (
                        options.map((item: string) => {
                            if( !Translations?.[item]?.[getLang] ) console.log(item);
                            
                            return <div
                                key={item}
                                className={`selectorOption ${item === option ? "active" : ""}`}
                                onClick={() => {
                                    onChange(item === option ? "" : item)
                                    toggleOptions(false)
                                }}
                            >
                                {Translations?.[item]?.[getLang] ?? item}
                            </div>
                        })
                    ) : (
                        <div className="selectorOption disabled">
                            Нет данных
                        </div>
                    )}
                </div>
            )}
        </div>
    )
}