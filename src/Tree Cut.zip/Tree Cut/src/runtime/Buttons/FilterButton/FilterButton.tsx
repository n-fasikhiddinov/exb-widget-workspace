import { React } from "jimu-core"
import FeatureLayer from "@arcgis/core/layers/FeatureLayer"
import "./FilterButton.css"

import { CSSVars } from "../../../configs/theme"
import { FilterIcon, CloseIcon } from "../../../configs/icons"
import { LangKey, Translations } from "../../../configs/translation"
import { filterStruct, buildWhereQuery } from "../../../configs/config"

import Selector from "./Selector"
import DateInput, { displayToIso } from "./DateInput"

interface FilterButtonProps {
    polygonRef: React.MutableRefObject<FeatureLayer>
    getButtonsStatus: boolean
    setButtonsStatus: (value: boolean) => void
    themeVars: CSSVars
    getLang: LangKey
    setFilter: (value: filterStruct) => void
}

type FilterField = "id_country" | "id_region" | "id_distric"
type FilterOptionsState = Record<FilterField, string[]>

const FILTER_FIELDS: FilterField[] = ["id_country", "id_region", "id_distric"]

const EMPTY_OPTIONS: FilterOptionsState = {
    id_country: [],
    id_region: [],
    id_distric: []
}

const EMPTY_VALUES: filterStruct = {
    id_country: "17",
    id_region: "",
    id_distric: "",
    from_date: "",
    to_date: "",
    status: ""
}

export default function FilterButton({
    polygonRef,
    getButtonsStatus,
    setButtonsStatus,
    themeVars,
    getLang,
    setFilter
}: FilterButtonProps) {
    console.log(123);
    
    const [getFiltersOptions, setFiltersOptions] = React.useState<FilterOptionsState>(EMPTY_OPTIONS)
    const [getSelectedFilters, setSelectedFilters] = React.useState<filterStruct>(EMPTY_VALUES)
    const [getLoading, setLoading] = React.useState<boolean>(false)
    const [getSubFilter, setSubFilter] = React.useState({
        id_region: "",
        id_distric: ""
    })

    const iconColor = `rgb(${themeVars["--main-color"]})`

    const setFilterField = React.useCallback((field: keyof filterStruct, value: string) => {
        setSelectedFilters((prev) => ({ ...prev, [field]: value }))
    }, [])

    const clearFilters = React.useCallback(() => {
        setSelectedFilters(EMPTY_VALUES)
        setFilter(EMPTY_VALUES)
    }, [setFilter])

    React.useEffect(() => {
        let isMounted = true

        const loadByGroupQuery = async (): Promise<FilterOptionsState> => {
            const nextState: FilterOptionsState = { id_country: [], id_region: [], id_distric: [] }
            for (let i = 0; i < FILTER_FIELDS.length; i += 1) {
                const field = FILTER_FIELDS[i]
                try {
                    let filter_filter = `1=1`;
                    switch (field) {
                        case "id_region": filter_filter += `${getSubFilter["id_region"] && (" AND id_country = " + getSubFilter["id_region"])}`; break;
                        case "id_distric": filter_filter += `${getSubFilter["id_region"] && (" AND id_country = " + getSubFilter["id_region"])} ${getSubFilter["id_distric"] && ("AND id_region = " + getSubFilter["id_distric"])}`; break;
                        default: break;
                    }

                    const result = await polygonRef.current.queryFeatures({
                        where: filter_filter,
                        returnGeometry: false,
                        groupByFieldsForStatistics: [field],
                        orderByFields: [`${field} ASC`],
                        outStatistics: [{ statisticType: "count", onStatisticField: field, outStatisticFieldName: "count" }]
                    })
                    nextState[field] = result.features
                        .map((feature: any) => {
                            const rawValue = feature.attributes[field]
                            if (rawValue == null) return null
                            return String(rawValue).trim()
                        })
                        .filter((value: string | null): value is string => value !== null && value !== "")
                } catch (error) {
                    console.error(`Group query failed for ${field}:`, error)
                    nextState[field] = []
                }
            }
            return nextState
        }

        const loadByFallbackQuery = async (): Promise<FilterOptionsState> => {
            const result = await polygonRef.current.queryFeatures({
                where: "1=1",
                returnGeometry: false,
                outFields: ["id_country", "id_region", "id_district"]
            })
            const countries = new Set<string>()
            const regions = new Set<string>()
            const districts = new Set<string>()
            result.features.forEach((feature: any) => {
                const attr = feature.attributes
                if (attr.id_country != null && String(attr.id_country).trim() !== "") countries.add(String(attr.id_country).trim())
                if (attr.id_region != null && String(attr.id_region).trim() !== "") regions.add(String(attr.id_region).trim())
                if (attr.id_distric != null && String(attr.id_distric).trim() !== "") districts.add(String(attr.id_distric).trim())
            })
            return {
                id_country: Array.from(countries).sort(),
                id_region: Array.from(regions).sort(),
                id_distric: Array.from(districts).sort()
            }
        }

        const loadFilterOptions = async () => {
            setLoading(true)
            try {
                const groupedState = await loadByGroupQuery()
                const hasAnyData = groupedState.id_country.length > 0 || groupedState.id_region.length > 0 || groupedState.id_distric.length > 0
                if (!isMounted) return
                if (hasAnyData) { setFiltersOptions(groupedState); return }
                const fallbackState = await loadByFallbackQuery()
                if (isMounted) setFiltersOptions(fallbackState)
            } catch (error) {
                console.error("Main filter loading failed, fallback start:", error)
                try {
                    const fallbackState = await loadByFallbackQuery()
                    if (isMounted) setFiltersOptions(fallbackState)
                } catch (fallbackError) {
                    console.error("Fallback filter loading failed:", fallbackError)
                    if (isMounted) setFiltersOptions(EMPTY_OPTIONS)
                }
            } finally {
                if (isMounted) setLoading(false)
            }
        }

        loadFilterOptions()
        return () => { isMounted = false }
    }, [polygonRef, getSubFilter])

    const applyFilters = React.useCallback(() => {
        try {
            const filterToSend: filterStruct = {
                ...getSelectedFilters,
                from_date: displayToIso(getSelectedFilters.from_date),
                to_date: displayToIso(getSelectedFilters.to_date)
            }
            buildWhereQuery(filterToSend)
            setFilter(filterToSend)
        } catch (error) {
            console.error("Apply filter failed:", error)
        }
    }, [getSelectedFilters, setFilter])

    return (
        <div className="button">
            <div
                className={`buttonLogo ${getButtonsStatus ? "active" : ""}`}
                onClick={() => { setButtonsStatus(!getButtonsStatus) }}
            >
                {getButtonsStatus ? (
                    <CloseIcon size="30px" color={iconColor} />
                ) : (
                    <FilterIcon size="30px" color={iconColor} />
                )}
            </div>

            {getButtonsStatus && (
                <div className="filterArea">
                    <div className="filterTitle">{Translations["filterTitle"][getLang]}</div>

                    <div className="filterSelector">
                        <div className="filterSelectorName">{Translations["filterRepublics"][getLang]}</div>
                        <Selector
                            getLang={getLang}
                            className="filterSelectorOptions"
                            option={getSelectedFilters.id_country}
                            options={getFiltersOptions.id_country}
                            placeholder="Davlatlar"
                            onChange={(value: string) => {
                                setFilterField("id_country", value)
                                setSubFilter((prev: any) => ({ ...prev, "id_region": value }))
                            }}
                        />
                    </div>

                    <div className="filterSelector">
                        <div className="filterSelectorName">{Translations["filterRegions"][getLang]}</div>
                        <Selector
                            getLang={getLang}
                            className="filterSelectorOptions"
                            option={getSelectedFilters.id_region}
                            options={getFiltersOptions.id_region}
                            placeholder="Hududlar"
                            onChange={(value: string) => {
                                setFilterField("id_region", value)
                                setSubFilter((prev: any) => ({ ...prev, "id_distric": value }))
                            }}
                        />
                    </div>

                    <div className="filterSelector">
                        <div className="filterSelectorName">{Translations["filterDistricts"][getLang]}</div>
                        <Selector
                            getLang={getLang}
                            className="filterSelectorOptions"
                            option={getSelectedFilters.id_distric}
                            options={getFiltersOptions.id_distric}
                            placeholder="Tumanlar"
                            onChange={(value: string) => setFilterField("id_distric", value)}
                        />
                    </div>

                    <div className="filterSelector">
                        <div className="filterSelectorName">{Translations["filterDates"][getLang]}</div>
                        <DateInput
                            className="filterDateInput"
                            value={getSelectedFilters.from_date}
                            placeholder="KK / OO / YYYY"
                            onChange={(value: string) => setFilterField("from_date", value)}
                        />
                        <DateInput
                            className="filterDateInput"
                            value={getSelectedFilters.to_date}
                            placeholder="KK / OO / YYYY"
                            onChange={(value: string) => setFilterField("to_date", value)}
                        />
                    </div>

                    <div className="filterButtons">
                        <button type="button" className="filterClear" onClick={clearFilters}>
                            {Translations["filterClear"][getLang]}
                        </button>
                        <button type="button" className="filterApply" onClick={applyFilters} disabled={getLoading}>
                            {getLoading ? "Loading..." : Translations["filterApply"][getLang]}
                        </button>
                    </div>
                </div>
            )}
        </div>
    )
}