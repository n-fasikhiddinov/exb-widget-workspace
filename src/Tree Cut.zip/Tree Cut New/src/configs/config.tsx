export const uniqueIdField = "mgrs"

export interface summaryStruct {
    count: number;
    sum: number;
    dailyCount: number;
}

export interface selectedPolyStruct {
    [uniqueIdField]: string
}

export interface filterStruct {
    id_country: string
    id_region: string
    id_district: string

    day: number[]
    month: number[]
    year: number[]

    status: number | null
}

export const escapeSqlString = (value: string): string => {
    console.log(value);

    return value.replace(/'/g, "''")
}

export const buildSelectedWhereQuery = (selected: selectedPolyStruct): string => {
    return `${uniqueIdField} = '${escapeSqlString(selected[uniqueIdField])}'`;
}

export const buildWhereQuery = (filter: filterStruct, widget: string): string => {
    const result: string[] = ["1=1"];

    if (
        widget === "Table" ||
        widget === "Indicator"
    ) {
        if (filter.id_country !== "") result.push(`id_country = ${filter.id_country}`);
        if (filter.id_region !== "") result.push(`id_region = ${filter.id_region}`);
        if (filter.id_district !== "") result.push(`id_district = ${filter.id_district}`);

        if (filter.year.length !== 0) result.push(`EXTRACT( YEAR FROM date ) IN (${filter.year.join(",")})`);
        if (filter.month.length !== 0) result.push(`EXTRACT( MONTH FROM date ) IN (${filter.month.join(",")})`);
        if (filter.day.length !== 0) result.push(`EXTRACT( DAY FROM date ) IN (${filter.day.join(",")})`);

        if (filter.status !== null) result.push(`status = ${filter.status}`);
    }
    else if (widget === "Graph") {
        if (filter.id_country !== "") result.push(`id_country = ${filter.id_country}`);
        if (filter.id_region !== "") result.push(`id_region = ${filter.id_region}`);
        if (filter.id_district !== "") result.push(`id_district = ${filter.id_district}`);

        if (filter.year.length !== 0) result.push(`EXTRACT( YEAR FROM date ) IN (${filter.year.join(",")})`);
        if (filter.month.length !== 0) result.push(`EXTRACT( MONTH FROM date ) IN (${filter.month.join(",")})`);

        if (filter.status !== null) result.push(`status = ${filter.status}`);
    }
    else if (widget === "BarChart") {
        if (filter.id_country !== "") result.push(`id_country = ${filter.id_country}`);
        if (filter.id_district !== "") result.push(`id_district = ${filter.id_district}`);

        if (filter.year.length !== 0) result.push(`EXTRACT( YEAR FROM date ) IN (${filter.year.join(",")})`);
        if (filter.month.length !== 0) result.push(`EXTRACT( MONTH FROM date ) IN (${filter.month.join(",")})`);
        if (filter.day.length !== 0) result.push(`EXTRACT( DAY FROM date ) IN (${filter.day.join(",")})`);

        if (filter.status !== null) result.push(`status = ${filter.status}`);
    }
    else if (widget === "PieChart") {
        if (filter.id_country !== "") result.push(`id_country = ${filter.id_country}`);
        if (filter.id_region !== "") result.push(`id_region = ${filter.id_region}`);
        if (filter.id_district !== "") result.push(`id_district = ${filter.id_district}`);
    }
    else return "1=0"

    return result.join(" AND ");
}