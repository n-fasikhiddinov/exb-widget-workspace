import { React } from "jimu-core";
import { LangKey, Translations } from "../../configs/translations";
import { ThemeKey } from "../../configs/themes";
import { buildWhereQuery, filterStruct } from "../../configs/config";
import FeatureLayer from "@arcgis/core/layers/FeatureLayer";
import Query from "@arcgis/core/rest/support/Query";

import "./Graph.css";

interface graphProps {
    mainDateRef: React.MutableRefObject<FeatureLayer>;
    style?: React.CSSProperties;
    className?: string;
    getLang: LangKey;
    getTheme: ThemeKey;
    getFilter: filterStruct;
    setFilter: React.Dispatch<React.SetStateAction<filterStruct>>;
}

type GraphType = "dailyType" | "regionType";

interface DailyGraphItem {
    day: number;
    count: number;
    sum: number;
}

interface RegionGraphItem {
    region: string;
    count: number;
    sum: number;
}

interface GraphTheme {
    areaColor: string;
    mainColor: string;
    activeColor: string;
    activeTextColor: string;
    textColor: string;
    iconAreaColor: string;
}

const DPR_LIMIT = 2;
const APPLY_DAY_DELAY = 320;
const APPLY_MONTH_DELAY = 420;
const TOOLTIP_SHOW_THRESHOLD = 0.5;

const UI = {
    canvasTopPadding: 0,
    canvasBottomPadding: 0,
    sidePadding: 4,

    chartTop: 28,
    chartBottomGap: 58,

    chartLineWidth: 2,

    sliderBaseWidth: 2,
    sliderYBottomOffset: 14,
    sliderEdgePadding: 16,

    handleRadius: 11,
    handleRadiusActive: 12,
    handleHitRadius: 22,
    handleIconSize: 3.5,

    dayFontSize: 14,
    dayRowOffset: 28,

    dayActiveBgHeight: 30,
    dayActivePadX: 10,
    dayActiveRadius: 999,
    dayActiveLift: 0,
    dayBubbleGap: 0,

    sliderBumpHeight: 15,
    sliderBumpHalfWidth: 50,
    sliderGlowWidth: 4,
    sliderLineGapToHandle: -8,

    tooltipMinWidth: 170,
    tooltipHeight: 74,
    tooltipPadX: 12,
    tooltipPadY: 10,
    tooltipRadius: 12,
    tooltipGap: 8,
    tooltipTitleSize: 13,
    tooltipTextSize: 12
};

function clamp(value: number, min: number, max: number): number {
    if (value < min) return min;
    if (value > max) return max;
    return value;
}

function rgba(rgb: string, alpha: number): string {
    return `rgba(${rgb}, ${alpha})`;
}

function roundedRectPath(
    ctx: CanvasRenderingContext2D,
    x: number,
    y: number,
    width: number,
    height: number,
    radius: number
): void {
    const r = Math.min(radius, width / 2, height / 2);

    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.lineTo(x + width - r, y);
    ctx.quadraticCurveTo(x + width, y, x + width, y + r);
    ctx.lineTo(x + width, y + height - r);
    ctx.quadraticCurveTo(x + width, y + height, x + width - r, y + height);
    ctx.lineTo(x + r, y + height);
    ctx.quadraticCurveTo(x, y + height, x, y + height - r);
    ctx.lineTo(x, y + r);
    ctx.quadraticCurveTo(x, y, x + r, y);
    ctx.closePath();
}

function createSmoothPath(
    ctx: CanvasRenderingContext2D,
    points: Array<{ x: number; y: number }>
): void {
    if (points.length === 0) return;

    if (points.length === 1) {
        ctx.moveTo(points[0].x, points[0].y);
        return;
    }

    if (points.length === 2) {
        ctx.moveTo(points[0].x, points[0].y);
        ctx.lineTo(points[1].x, points[1].y);
        return;
    }

    ctx.moveTo(points[0].x, points[0].y);

    for (let i = 1; i < points.length - 1; i += 1) {
        const current = points[i];
        const next = points[i + 1];
        const midX = (current.x + next.x) / 2;
        const midY = (current.y + next.y) / 2;
        ctx.quadraticCurveTo(current.x, current.y, midX, midY);
    }

    const penultimate = points[points.length - 2];
    const last = points[points.length - 1];
    ctx.quadraticCurveTo(penultimate.x, penultimate.y, last.x, last.y);
}

function createAreaPath(
    ctx: CanvasRenderingContext2D,
    points: Array<{ x: number; y: number }>,
    bottomY: number
): void {
    if (points.length === 0) return;

    ctx.beginPath();
    createSmoothPath(ctx, points);
    ctx.lineTo(points[points.length - 1].x, bottomY);
    ctx.lineTo(points[0].x, bottomY);
    ctx.closePath();
}

function getTranslationValue(key: string, lang: LangKey, fallback: string): string {
    const item = (Translations as Record<string, Record<string, string> | undefined>)[key];
    if (!item) return fallback;
    return item[lang] || fallback;
}

function getCssVar(node: HTMLElement, name: string, fallback: string): string {
    const value = getComputedStyle(node).getPropertyValue(name).trim();
    return value !== "" ? value : fallback;
}

function normalizeDateArray(values: number[] | undefined): number[] {
    if (!Array.isArray(values)) return [];

    return values
        .map((value: number) => Number(value))
        .filter((value: number) => Number.isFinite(value));
}

function normalizeMonthSelection(values: number[] | undefined): number[] {
    const unique: Record<number, boolean> = {};
    const normalized = normalizeDateArray(values)
        .filter((month: number) => month >= 1 && month <= 12)
        .filter((month: number) => {
            if (unique[month]) return false;
            unique[month] = true;
            return true;
        })
        .sort((a: number, b: number) => a - b);

    return normalized;
}

function areNumberArraysEqual(a: number[], b: number[]): boolean {
    if (a.length !== b.length) return false;

    for (let i = 0; i < a.length; i += 1) {
        if (a[i] !== b[i]) return false;
    }

    return true;
}

function getDateLabel(day: number, lang: LangKey): string {
    switch (lang) {
        case "RU":
            return day + " число";
        case "UZ":
            return day + "-kun";
        case "EN":
            return String(day);
        default:
            return String(day);
    }
}

function getMonthNames(lang: LangKey): string[] {
    switch (lang) {
        case "RU":
            return [
                "Январь", "Февраль", "Март", "Апрель", "Май", "Июнь",
                "Июль", "Август", "Сентябрь", "Октябрь", "Ноябрь", "Декабрь"
            ];
        case "EN":
            return [
                "January", "February", "March", "April", "May", "June",
                "July", "August", "September", "October", "November", "December"
            ];
        case "UZ":
            return [
                "Yanvar", "Fevral", "Mart", "Aprel", "May", "Iyun",
                "Iyul", "Avgust", "Sentabr", "Oktabr", "Noyabr", "Dekabr"
            ];
        default:
            return [];
    }
}

function getFilterMonths(filter: filterStruct): number[] {
    return normalizeMonthSelection(filter.month);
}

function getFilterYears(filter: filterStruct): number[] {
    return normalizeDateArray(filter.year)
        .filter((year: number) => year >= 1);
}

function getSingleDayFromFilter(filter: filterStruct): number | null {
    const days = normalizeDateArray(filter.day)
        .filter((day: number) => day >= 1 && day <= 31);

    if (days.length !== 1) return null;
    return days[0];
}

function getDaysInMonth(year: number, month: number): number {
    return new Date(year, month, 0).getDate();
}

function getMaxPossibleDaysInMonth(month: number): number {
    switch (month) {
        case 2:
            return 29;
        case 4:
        case 6:
        case 9:
        case 11:
            return 30;
        default:
            return 31;
    }
}

function getDaysInScope(filter: filterStruct): number {
    const months = getFilterMonths(filter);
    const years = getFilterYears(filter);

    if (months.length === 1 && years.length === 1) {
        return getDaysInMonth(years[0], months[0]);
    }

    if (months.length === 1) {
        return getMaxPossibleDaysInMonth(months[0]);
    }

    return 31;
}

function readGroupedDay(item: Record<string, unknown>): number {
    const keys = ["expr1", "EXPR_1", "expr_1", "day", "DAY"];

    for (let i = 0; i < keys.length; i += 1) {
        const value = Number(item[keys[i]]);
        if (Number.isFinite(value) && value > 0) {
            return value;
        }
    }

    return 0;
}

function readGroupedRegion(item: Record<string, unknown>): string {
    const keys = ["id_region", "ID_REGION", "region", "REGION", "expr1", "EXPR_1", "expr_1"];
    for (let i = 0; i < keys.length; i += 1) {
        const value = item[keys[i]];
        if (value != null && String(value).trim() !== "") {
            return String(value).trim();
        }
    }

    return "";
}

export default function Graph({
    style = {},
    className = "",
    mainDateRef,
    getLang,
    getTheme,
    getFilter,
    setFilter
}: graphProps) {
    const [showMonthSelector, toggleMonthSelector] = React.useState<boolean>(false);
    const types: GraphType[] = [
        "dailyType",
        "regionType"
    ];

    const rootRef = React.useRef<HTMLDivElement | null>(null);
    const canvasWrapRef = React.useRef<HTMLDivElement | null>(null);
    const canvasRef = React.useRef<HTMLCanvasElement | null>(null);

    const draggingRef = React.useRef<boolean>(false);
    const pointerDownOnHandleRef = React.useRef<boolean>(false);
    const movedAfterDownRef = React.useRef<boolean>(false);
    const queryVersionRef = React.useRef<number>(0);
    const debounceTimerRef = React.useRef<number | null>(null);
    const monthDebounceTimerRef = React.useRef<number | null>(null);

    const [getCurrentType, setCurrentType] = React.useState<GraphType>("dailyType");
    const [graphData, setGraphData] = React.useState<DailyGraphItem[]>([]);
    const [regionData, setRegionData] = React.useState<RegionGraphItem[]>([]);
    const [selectedDay, setSelectedDay] = React.useState<number>(1);
    const [hoverDay, setHoverDay] = React.useState<number | null>(null);
    const [sliderActive, setSliderActive] = React.useState<boolean>(false);
    const [hoverTooltipEnabled, setHoverTooltipEnabled] = React.useState<boolean>(false);
    const [selectedMonthsDraft, setSelectedMonthsDraft] = React.useState<number[]>(() => {
        return normalizeMonthSelection(getFilter.month);
    });

    const [size, setSize] = React.useState<{ width: number; height: number }>({
        width: 0,
        height: 0
    });

    const [theme, setTheme] = React.useState<GraphTheme>({
        areaColor: "217, 219, 202",
        mainColor: "99, 108, 84",
        activeColor: "225, 241, 49",
        activeTextColor: "252, 254, 238",
        textColor: "17, 24, 39",
        iconAreaColor: "174, 179, 162"
    });

    const clearPendingDayApply = React.useCallback(() => {
        if (debounceTimerRef.current != null) {
            window.clearTimeout(debounceTimerRef.current);
            debounceTimerRef.current = null;
        }
    }, []);

    const clearPendingMonthApply = React.useCallback(() => {
        if (monthDebounceTimerRef.current != null) {
            window.clearTimeout(monthDebounceTimerRef.current);
            monthDebounceTimerRef.current = null;
        }
    }, []);

    const applyDayToFilter = React.useCallback((day: number) => {
        setFilter((prev: filterStruct) => {
            const prevDay = Array.isArray(prev.day) ? prev.day : [];
            if (prevDay.length === 1 && prevDay[0] === day) return prev;

            return {
                ...prev,
                day: [day]
            };
        });
    }, [setFilter]);

    const applyMonthsToFilter = React.useCallback((months: number[]) => {
        const normalizedMonths = normalizeMonthSelection(months);

        setFilter((prev: filterStruct) => {
            const prevMonths = normalizeMonthSelection(prev.month);

            if (areNumberArraysEqual(prevMonths, normalizedMonths)) {
                return prev;
            }

            return {
                ...prev,
                month: normalizedMonths
            };
        });
    }, [setFilter]);

    const clearDayFromFilter = React.useCallback(() => {
        setFilter((prev: filterStruct) => {
            const prevDay = Array.isArray(prev.day) ? prev.day : [];
            if (prevDay.length === 0) return prev;

            return {
                ...prev,
                day: []
            };
        });
    }, [setFilter]);

    const scheduleApplyDay = React.useCallback((day: number) => {
        clearPendingDayApply();

        debounceTimerRef.current = window.setTimeout(() => {
            debounceTimerRef.current = null;
            applyDayToFilter(day);
        }, APPLY_DAY_DELAY);
    }, [applyDayToFilter, clearPendingDayApply]);

    const scheduleApplyMonths = React.useCallback((months: number[]) => {
        const normalizedMonths = normalizeMonthSelection(months);

        clearPendingMonthApply();

        monthDebounceTimerRef.current = window.setTimeout(() => {
            monthDebounceTimerRef.current = null;
            applyMonthsToFilter(normalizedMonths);
        }, APPLY_MONTH_DELAY);
    }, [applyMonthsToFilter, clearPendingMonthApply]);

    const flushApplyDay = React.useCallback((day: number) => {
        clearPendingDayApply();
        applyDayToFilter(day);
    }, [applyDayToFilter, clearPendingDayApply]);

    React.useEffect(() => {
        return () => {
            clearPendingDayApply();
            clearPendingMonthApply();
        };
    }, [clearPendingDayApply, clearPendingMonthApply]);

    React.useEffect(() => {
        setSelectedMonthsDraft(normalizeMonthSelection(getFilter.month));
    }, [getFilter.month]);

    React.useLayoutEffect(() => {
        const rootNode = rootRef.current;
        const canvasWrapNode = canvasWrapRef.current;
        if (!rootNode || !canvasWrapNode) return;

        const readData = () => {
            const rect = canvasWrapNode.getBoundingClientRect();

            setSize({
                width: Math.round(rect.width),
                height: Math.round(rect.height)
            });

            setTheme({
                areaColor: getCssVar(rootNode, "--area-color", "217, 219, 202"),
                mainColor: getCssVar(rootNode, "--main-color", "99, 108, 84"),
                activeColor: getCssVar(rootNode, "--active-color", "225, 241, 49"),
                activeTextColor: getCssVar(rootNode, "--active-text-color", "252, 254, 238"),
                textColor: getCssVar(rootNode, "--text-color", "17, 24, 39"),
                iconAreaColor: getCssVar(rootNode, "--icon-area-color", "174, 179, 162")
            });
        };

        readData();

        if (typeof ResizeObserver !== "undefined") {
            const observer = new ResizeObserver(() => {
                readData();
            });

            observer.observe(rootNode);
            observer.observe(canvasWrapNode);

            return () => observer.disconnect();
        }
    }, [getTheme, getCurrentType]);

    React.useEffect(() => {
        const singleDay = getSingleDayFromFilter(getFilter);

        if (singleDay != null) {
            setSelectedDay(singleDay);
            if (getCurrentType === "dailyType") {
                setSliderActive(true);
            }
            return;
        }

        if (getCurrentType === "dailyType") {
            setSliderActive(false);
        }
    }, [getFilter.day, getCurrentType]);

    React.useEffect(() => {
        draggingRef.current = false;
        pointerDownOnHandleRef.current = false;
        movedAfterDownRef.current = false;
        setHoverDay(null);
        setHoverTooltipEnabled(false);

        if (getCurrentType !== "dailyType") {
            clearPendingDayApply();
        }
    }, [getCurrentType, clearPendingDayApply]);

    React.useEffect(() => {
        const version = queryVersionRef.current + 1;
        queryVersionRef.current = version;

        if (getCurrentType === "dailyType") {
            mainDateRef.current.queryFeatures(new Query({
                where: buildWhereQuery(getFilter, "Graph"),
                returnGeometry: false,
                groupByFieldsForStatistics: ["EXTRACT(DAY FROM date)"],
                outStatistics: [
                    {
                        statisticType: "count",
                        onStatisticField: "area",
                        outStatisticFieldName: "count"
                    },
                    {
                        statisticType: "sum",
                        onStatisticField: "area",
                        outStatisticFieldName: "sum"
                    }
                ],
                orderByFields: ["EXTRACT(DAY FROM date) ASC"]
            }))
                .then((result: __esri.FeatureSet) => {
                    if (queryVersionRef.current !== version) return;

                    const rawItems = (result.features || []).map((item: __esri.Graphic) => item.attributes || {});
                    const daysInScope = getDaysInScope(getFilter);
                    const normalized: DailyGraphItem[] = [];
                    const rawMap: Record<number, DailyGraphItem> = {};

                    rawItems.forEach((item: Record<string, unknown>) => {
                        const day = readGroupedDay(item);

                        if (day < 1 || day > daysInScope) return;

                        rawMap[day] = {
                            day: day,
                            count: Number(item["count"] || 0),
                            sum: Number(item["sum"] || 0)
                        };
                    });

                    for (let dayIndex = 1; dayIndex <= daysInScope; dayIndex += 1) {
                        normalized.push(rawMap[dayIndex] || {
                            day: dayIndex,
                            count: 0,
                            sum: 0
                        });
                    }

                    setGraphData(normalized);
                    setRegionData([]);

                    const selectedFromFilter = getSingleDayFromFilter(getFilter);
                    var lastMeaningfulDay = normalized.reduce((best: number, item: DailyGraphItem) => {
                        if (item.count > 0 || item.sum > 0) return item.day;
                        return best;
                    }, 0);

                    if (lastMeaningfulDay <= 0) {
                        lastMeaningfulDay = normalized.length > 0
                            ? normalized[normalized.length - 1].day
                            : 1;
                    }

                    if (selectedFromFilter != null && selectedFromFilter <= daysInScope) {
                        setSelectedDay(selectedFromFilter);
                        setSliderActive(true);
                    } else {
                        setSelectedDay(lastMeaningfulDay);
                        setSliderActive(false);

                        if (selectedFromFilter != null) {
                            clearPendingDayApply();
                            clearDayFromFilter();
                        }
                    }

                    setHoverDay(null);
                    setHoverTooltipEnabled(false);
                })
                .catch((error: unknown) => {
                    if (queryVersionRef.current !== version) return;

                    console.error("[Graph daily query failed]", error);
                    setGraphData([]);
                    setRegionData([]);
                    setHoverDay(null);
                    setHoverTooltipEnabled(false);
                    setSliderActive(false);
                });

            return;
        }

        mainDateRef.current.queryFeatures(new Query({
            where: buildWhereQuery(getFilter, "BarChart"),
            returnGeometry: false,
            groupByFieldsForStatistics: ["id_region"],
            orderByFields: ["count DESC"],
            outStatistics: [
                {
                    statisticType: "count",
                    onStatisticField: "area",
                    outStatisticFieldName: "count"
                },
                {
                    statisticType: "sum",
                    onStatisticField: "area",
                    outStatisticFieldName: "sum"
                }
            ],
            outFields: ["id_region"],
        }))
            .then((result: __esri.FeatureSet) => {
                console.log(buildWhereQuery(getFilter, "BarChart"));
                if (queryVersionRef.current !== version) return;

                const mainValue = result["features"].map((att: any) => att["attributes"]["id_region"]);
                const newValue = result["features"].map((att: any) => att["attributes"]);

                [
                    1703,
                    1706,
                    1708,
                    1710,
                    1712,
                    1714,
                    1718,
                    1722,
                    1724,
                    1726,
                    1727,
                    1730,
                    1733,
                    1735,
                ].map((item: number) => {
                    if (!mainValue.includes(item)) {
                        newValue.push({
                            id_region: item,
                            count: 0,
                            sum: 0
                        })
                    }
                })
                console.log(newValue);
                console.log(result);
                

                setRegionData(newValue);
                setGraphData([]);
                setHoverDay(null);
                setHoverTooltipEnabled(false);
                setSliderActive(false);
            })
            .catch((error: unknown) => {
                if (queryVersionRef.current !== version) return;

                console.error("[Graph region query failed]", error);
                setRegionData([]);
                setGraphData([]);
                setHoverDay(null);
                setHoverTooltipEnabled(false);
                setSliderActive(false);
            });
    }, [
        getCurrentType,
        mainDateRef,
        getFilter,
        clearPendingDayApply,
        clearDayFromFilter
    ]);

    const getMetrics = React.useCallback(() => {
        const width = size.width;
        const height = size.height;

        const left = UI.sidePadding;
        const right = width - UI.sidePadding;

        const sliderLeft = left + UI.sliderEdgePadding;
        const sliderRight = right - UI.sliderEdgePadding;

        const top = UI.canvasTopPadding;
        const bottom = height - UI.canvasBottomPadding - UI.chartBottomGap;
        const chartWidth = right - left;
        const chartHeight = bottom - top;
        const sliderWidth = Math.max(1, sliderRight - sliderLeft);

        const handleY = height - UI.sliderYBottomOffset;
        const lineBaseY = handleY - UI.handleRadiusActive - UI.sliderLineGapToHandle;

        return {
            width: width,
            height: height,
            left: left,
            right: right,
            sliderLeft: sliderLeft,
            sliderRight: sliderRight,
            top: top,
            bottom: bottom,
            chartWidth: chartWidth,
            chartHeight: chartHeight,
            sliderWidth: sliderWidth,
            handleY: handleY,
            lineBaseY: lineBaseY
        };
    }, [size]);

    const getSelectedIndex = React.useCallback((): number => {
        const index = graphData.findIndex((item: DailyGraphItem) => item.day === selectedDay);
        return index >= 0 ? index : Math.max(0, graphData.length - 1);
    }, [graphData, selectedDay]);

    const getHandleX = React.useCallback((): number => {
        const metrics = getMetrics();
        const index = getSelectedIndex();

        if (graphData.length <= 1) return metrics.sliderLeft + metrics.sliderWidth / 2;

        const stepX = metrics.sliderWidth / (graphData.length - 1);
        return metrics.sliderLeft + stepX * index;
    }, [getMetrics, getSelectedIndex, graphData.length]);

    const pointerHitsHandle = React.useCallback((clientX: number, clientY: number): boolean => {
        const canvas = canvasRef.current;
        if (!canvas) return false;

        const rect = canvas.getBoundingClientRect();
        const metrics = getMetrics();

        const x = clientX - rect.left;
        const y = clientY - rect.top;
        const handleX = getHandleX();

        const dx = x - handleX;
        const dy = y - metrics.handleY;

        return Math.sqrt(dx * dx + dy * dy) <= UI.handleHitRadius;
    }, [getMetrics, getHandleX]);

    const getPointIndexByClientX = React.useCallback((clientX: number): number => {
        const canvas = canvasRef.current;
        if (!canvas || graphData.length === 0) return -1;

        const rect = canvas.getBoundingClientRect();
        const metrics = getMetrics();
        const x = clientX - rect.left;

        if (graphData.length <= 1) return 0;

        const stepX = metrics.sliderWidth / (graphData.length - 1);
        const rawIndex = Math.round((x - metrics.sliderLeft) / stepX);

        return clamp(rawIndex, 0, graphData.length - 1);
    }, [getMetrics, graphData.length]);

    const setSelectedByIndex = React.useCallback((index: number) => {
        const item = graphData[index];
        if (!item) return;

        setSelectedDay(item.day);
    }, [graphData]);

    const updateTooltipVisibility = React.useCallback((clientY: number) => {
        const canvas = canvasRef.current;
        if (!canvas) return;

        const rect = canvas.getBoundingClientRect();
        const localY = clientY - rect.top;
        const shouldShow = localY >= rect.height * TOOLTIP_SHOW_THRESHOLD;

        setHoverTooltipEnabled(shouldShow);
    }, []);

    React.useEffect(() => {
        const canvas = canvasRef.current;
        if (!canvas || !size.width || !size.height) return;

        const ctx = canvas.getContext("2d");
        if (!ctx) return;

        const dpr = Math.min(window.devicePixelRatio || 1, DPR_LIMIT);
        canvas.width = Math.max(1, Math.floor(size.width * dpr));
        canvas.height = Math.max(1, Math.floor(size.height * dpr));
        canvas.style.width = size.width + "px";
        canvas.style.height = size.height + "px";
        ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
        ctx.clearRect(0, 0, size.width, size.height);

        if (getCurrentType !== "dailyType" || graphData.length === 0) {
            return;
        }

        const metrics = getMetrics();
        const left = metrics.left;
        const right = metrics.right;
        const top = metrics.top;
        const bottom = metrics.bottom;
        const chartWidth = metrics.chartWidth;
        const chartHeight = metrics.chartHeight;
        const handleY = metrics.handleY;
        const lineBaseY = metrics.lineBaseY;

        const lineColor = rgba(theme.mainColor, 0.82);
        const areaTopColor = rgba(theme.mainColor, 0.7);
        const areaBottomColor = rgba(theme.mainColor, 0.0);
        const sliderLineColor = rgba(theme.mainColor, 0.55);
        const sliderOffColor = rgba(theme.mainColor, 0.22);
        const activeGlowColor = rgba(theme.activeColor, 1);
        const titleColor = rgba(theme.textColor, 1);

        const maxValue = Math.max(
            1,
            ...graphData.map((item: DailyGraphItem) => Number(item.count) || 0)
        );

        const stepX = graphData.length > 1 ? chartWidth / (graphData.length - 1) : 0;

        const graphPoints = graphData.map((item: DailyGraphItem, index: number) => {
            const value = Number(item.count) || 0;
            const ratio = value / maxValue;

            return {
                x: left + stepX * index,
                y: clamp(bottom - ratio * chartHeight, top, bottom),
                raw: item
            };
        });

        createAreaPath(ctx, graphPoints, bottom);
        const areaGradient = ctx.createLinearGradient(0, top, 0, bottom);
        areaGradient.addColorStop(0, areaTopColor);
        areaGradient.addColorStop(1, areaBottomColor);
        ctx.fillStyle = areaGradient;
        ctx.fill();

        ctx.beginPath();
        createSmoothPath(ctx, graphPoints);
        ctx.lineWidth = UI.chartLineWidth;
        ctx.strokeStyle = lineColor;
        ctx.lineCap = "round";
        ctx.lineJoin = "round";
        ctx.stroke();

        const activeIndex = getSelectedIndex();
        const handleX = getHandleX();

        ctx.save();
        ctx.lineCap = "round";
        ctx.lineJoin = "round";

        if (sliderActive) {
            const leftShoulder = Math.max(left, handleX - UI.sliderBumpHalfWidth);
            const rightShoulder = Math.min(right, handleX + UI.sliderBumpHalfWidth);
            const peakY = lineBaseY - UI.sliderBumpHeight;

            const sliderPoints = [
                { x: left, y: lineBaseY },
                { x: leftShoulder, y: lineBaseY },
                { x: handleX, y: peakY },
                { x: rightShoulder, y: lineBaseY },
                { x: right, y: lineBaseY }
            ];

            ctx.beginPath();
            createSmoothPath(ctx, sliderPoints);

            const glowGradient = ctx.createLinearGradient(left, 0, right, 0);
            glowGradient.addColorStop(0, sliderLineColor);
            glowGradient.addColorStop(
                clamp((leftShoulder - left) / Math.max(1, right - left), 0, 1),
                sliderLineColor
            );
            glowGradient.addColorStop(
                clamp((handleX - 2 - left) / Math.max(1, right - left), 0, 1),
                rgba(theme.activeColor, 0.95)
            );
            glowGradient.addColorStop(
                clamp((handleX + 2 - left) / Math.max(1, right - left), 0, 1),
                rgba(theme.activeColor, 0.95)
            );
            glowGradient.addColorStop(
                clamp((rightShoulder - left) / Math.max(1, right - left), 0, 1),
                sliderLineColor
            );
            glowGradient.addColorStop(1, sliderLineColor);

            ctx.lineWidth = UI.sliderGlowWidth;
            ctx.strokeStyle = glowGradient;
            ctx.stroke();
        } else {
            ctx.beginPath();
            createSmoothPath(ctx, [
                { x: left, y: lineBaseY },
                { x: right, y: lineBaseY }
            ]);
            ctx.lineWidth = UI.sliderBaseWidth;
            ctx.strokeStyle = sliderOffColor;
            ctx.stroke();
        }

        ctx.restore();

        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        ctx.font = "500 " + UI.dayFontSize + "px Inter, system-ui, sans-serif";

        const sliderStepX = graphData.length > 1 ? metrics.sliderWidth / (graphData.length - 1) : 0;

        graphData.forEach((item: DailyGraphItem, index: number) => {
            const x = metrics.sliderLeft + sliderStepX * index;
            const isSelected = item.day === selectedDay;
            const isActiveSelected = isSelected && sliderActive;

            if (isActiveSelected) return;

            ctx.fillStyle = titleColor;
            ctx.fillText(String(item.day), x, lineBaseY - 20);
        });

        if (sliderActive && graphPoints[activeIndex]) {
            const activeDayText = String(graphData[activeIndex].day);
            ctx.font = "700 18px Inter, system-ui, sans-serif";

            const activeWidth = Math.max(
                30,
                ctx.measureText(activeDayText).width + UI.dayActivePadX * 2
            );

            const peakY = lineBaseY - UI.sliderBumpHeight;
            const activeY = peakY - UI.dayActiveBgHeight - UI.dayBubbleGap;
            const activeX = clamp(handleX - activeWidth / 2, left, right - activeWidth);

            roundedRectPath(
                ctx,
                activeX,
                activeY,
                activeWidth,
                UI.dayActiveBgHeight,
                UI.dayActiveRadius
            );
            ctx.fillStyle = activeGlowColor;
            ctx.fill();

            ctx.fillStyle = titleColor;
            ctx.textAlign = "center";
            ctx.textBaseline = "middle";
            ctx.fillText(activeDayText, activeX + activeWidth / 2, activeY + UI.dayActiveBgHeight / 2 + 0.5);
        }

        if (hoverDay != null && hoverTooltipEnabled) {
            const tooltipIndex = graphData.findIndex((item: DailyGraphItem) => item.day === hoverDay);

            if (tooltipIndex >= 0) {
                const tooltipItem = graphData[tooltipIndex];
                const tooltipCenterX = metrics.sliderLeft + sliderStepX * tooltipIndex;

                const titleText = getDateLabel(tooltipItem.day, getLang);
                const countText = getTranslationValue("count", getLang, "Count") + ": " + tooltipItem.count;
                const areaText = getTranslationValue("area", getLang, "Area") + ": " + tooltipItem.sum;

                ctx.font = "700 " + UI.tooltipTitleSize + "px Inter, system-ui, sans-serif";
                const w1 = ctx.measureText(titleText).width;

                ctx.font = "500 " + UI.tooltipTextSize + "px Inter, system-ui, sans-serif";
                const w2 = ctx.measureText(countText).width;
                const w3 = ctx.measureText(areaText).width;

                const tooltipWidth = Math.max(UI.tooltipMinWidth, Math.max(w1, w2, w3) + UI.tooltipPadX * 2);
                const tooltipHeight = UI.tooltipHeight;
                const tooltipX = clamp(tooltipCenterX - tooltipWidth / 2, left, right - tooltipWidth);
                const tooltipPeakY = lineBaseY - UI.sliderBumpHeight;
                const tooltipActiveY = tooltipPeakY - UI.dayActiveBgHeight - UI.dayBubbleGap;
                const tooltipY = tooltipActiveY - UI.tooltipHeight - UI.tooltipGap;

                roundedRectPath(ctx, tooltipX, tooltipY, tooltipWidth, tooltipHeight, UI.tooltipRadius);
                ctx.fillStyle = rgba(theme.mainColor, 0.92);
                ctx.fill();

                ctx.textAlign = "left";
                ctx.textBaseline = "top";
                ctx.fillStyle = rgba(theme.activeTextColor, 1);

                ctx.font = "700 " + UI.tooltipTitleSize + "px Inter, system-ui, sans-serif";
                ctx.fillText(titleText, tooltipX + UI.tooltipPadX, tooltipY + UI.tooltipPadY);

                ctx.font = "500 " + UI.tooltipTextSize + "px Inter, system-ui, sans-serif";
                ctx.fillText(countText, tooltipX + UI.tooltipPadX, tooltipY + UI.tooltipPadY + 22);
                ctx.fillText(areaText, tooltipX + UI.tooltipPadX, tooltipY + UI.tooltipPadY + 42);
            }
        }

        roundedRectPath(
            ctx,
            handleX - (sliderActive ? UI.handleRadiusActive : UI.handleRadius),
            handleY - (sliderActive ? UI.handleRadiusActive : UI.handleRadius),
            (sliderActive ? UI.handleRadiusActive : UI.handleRadius) * 2,
            (sliderActive ? UI.handleRadiusActive : UI.handleRadius) * 2,
            sliderActive ? UI.handleRadiusActive : UI.handleRadius
        );
        ctx.fillStyle = rgba(theme.mainColor, sliderActive ? 0.92 : 0.65);
        ctx.fill();

        ctx.strokeStyle = rgba(theme.activeTextColor, 0.18);
        ctx.lineWidth = 1;
        ctx.stroke();

        ctx.beginPath();
        ctx.moveTo(handleX, handleY - UI.handleIconSize);
        ctx.lineTo(handleX + UI.handleIconSize, handleY);
        ctx.lineTo(handleX, handleY + UI.handleIconSize);
        ctx.lineTo(handleX - UI.handleIconSize, handleY);
        ctx.closePath();
        ctx.fillStyle = rgba(theme.activeTextColor, 1);
        ctx.fill();
    }, [
        size,
        theme,
        getCurrentType,
        graphData,
        selectedDay,
        hoverDay,
        sliderActive,
        hoverTooltipEnabled,
        getLang,
        getMetrics,
        getHandleX,
        getSelectedIndex
    ]);

    const onPointerDown = (event: React.PointerEvent<HTMLCanvasElement>) => {
        if (getCurrentType !== "dailyType") return;
        if (graphData.length === 0) return;

        const hitHandle = pointerHitsHandle(event.clientX, event.clientY);
        pointerDownOnHandleRef.current = hitHandle;
        movedAfterDownRef.current = false;
        draggingRef.current = true;
        updateTooltipVisibility(event.clientY);

        try {
            event.currentTarget.setPointerCapture(event.pointerId);
        } catch (error) {
        }

        const index = getPointIndexByClientX(event.clientX);

        if (index >= 0) {
            if (!sliderActive) {
                setSliderActive(true);
                setSelectedByIndex(index);
                scheduleApplyDay(graphData[index].day);
            } else {
                setSelectedByIndex(index);
            }

            setHoverDay(graphData[index].day);
        }
    };

    const onPointerMove = (event: React.PointerEvent<HTMLCanvasElement>) => {
        if (getCurrentType !== "dailyType") return;
        if (graphData.length === 0) return;

        updateTooltipVisibility(event.clientY);

        const index = getPointIndexByClientX(event.clientX);

        if (index >= 0) {
            setHoverDay(graphData[index].day);
        } else {
            setHoverDay(null);
        }

        if (draggingRef.current && index >= 0) {
            movedAfterDownRef.current = true;

            if (!sliderActive) {
                setSliderActive(true);
            }

            setSelectedByIndex(index);
            scheduleApplyDay(graphData[index].day);
        }
    };

    const onPointerUp = (event: React.PointerEvent<HTMLCanvasElement>) => {
        if (getCurrentType !== "dailyType") return;

        updateTooltipVisibility(event.clientY);

        const clickedHandleOnly = pointerDownOnHandleRef.current
            && !movedAfterDownRef.current
            && pointerHitsHandle(event.clientX, event.clientY);

        if (clickedHandleOnly) {
            setSliderActive((prev: boolean) => {
                const next = !prev;

                if (!next) {
                    clearPendingDayApply();
                    clearDayFromFilter();
                } else {
                    flushApplyDay(selectedDay);
                }

                return next;
            });
        } else if (draggingRef.current && sliderActive) {
            flushApplyDay(selectedDay);
        }

        draggingRef.current = false;
        pointerDownOnHandleRef.current = false;
        movedAfterDownRef.current = false;

        try {
            event.currentTarget.releasePointerCapture(event.pointerId);
        } catch (error) {
        }
    };

    const onPointerLeave = () => {
        draggingRef.current = false;
        pointerDownOnHandleRef.current = false;
        movedAfterDownRef.current = false;
        setHoverDay(null);
        setHoverTooltipEnabled(false);
    };

    const toggleMonth = (month: number) => {
        setSelectedMonthsDraft((prev: number[]) => {
            const next = prev.includes(month)
                ? prev.filter((value: number) => value !== month)
                : [...prev, month];

            const normalizedNext = normalizeMonthSelection(next);
            scheduleApplyMonths(normalizedNext);

            return normalizedNext;
        });
    };

    const graphContent = (): React.ReactNode => {
        switch (getCurrentType) {
            case "dailyType":
                return (
                    <div
                        ref={canvasWrapRef}
                        style={{
                            width: "100%",
                            height: "100%",
                            minHeight: 0,
                            minWidth: 0,
                            position: "relative",
                            overflow: "hidden"
                        }}
                    >
                        {showMonthSelector && <div
                            className="graphMonthSelectorArea"
                            onClick={(e: React.MouseEvent<HTMLDivElement>) => {
                                if (e.target !== e.currentTarget) return;
                                toggleMonthSelector(false);
                            }}
                        >
                            <div className="graphMonthSelectorBlocks">
                                {getMonthNames(getLang).map((month: string, index: number) => {
                                    const monthNumber = index + 1;

                                    return (
                                        <div
                                            key={monthNumber}
                                            className={`graphMonthSelectorBlock ${selectedMonthsDraft.includes(monthNumber) ? "active" : ""}`}
                                            onClick={() => toggleMonth(monthNumber)}
                                        >
                                            {month}
                                        </div>
                                    );
                                })}
                            </div>
                        </div>}
                        <div className="monthInfo" onClick={() => toggleMonthSelector(true)}>
                            {/* <div className="monthTitle">{Translations["months"][getLang]}: </div> */}
                            <div className="months">{
                                selectedMonthsDraft.length === 0 || selectedMonthsDraft.length === getMonthNames(getLang).length ?
                                    Translations["allMonths"][getLang] :
                                    selectedMonthsDraft.map((month: number) => getMonthNames(getLang)[month - 1]).join(", ")
                            }</div>
                        </div>
                        <canvas
                            ref={canvasRef}
                            onPointerDown={onPointerDown}
                            onPointerMove={onPointerMove}
                            onPointerUp={onPointerUp}
                            onPointerCancel={onPointerUp}
                            onPointerLeave={onPointerLeave}
                            style={{
                                width: "100%",
                                height: "100%",
                                display: "block",
                                cursor: draggingRef.current ? "grabbing" : "grab"
                            }}
                        />
                    </div>
                );
            case "regionType":
                return (
                    <div
                        ref={canvasWrapRef}
                        className="regionBarChart"
                        style={{
                            gridTemplateColumns: `repeat(${regionData.length}, 1fr)`
                        }}
                    >
                        {regionData.map((regionInfo: any, index: number, arr: any[]) => {
                            return (
                                <div className="regionBarBlock" key={index}>
                                    <div className="regionBarValue">{regionInfo["count"]}</div>
                                    <div className={`regionBarBar ${getFilter["id_region"] === regionInfo["id_region"] && "active"}`}
                                        style={{
                                            height: `${20 + regionInfo["count"] / arr[0]["count"] * (canvasWrapRef.current.clientHeight - 90)}px`
                                        }}
                                        onClick={() => {
                                            setFilter((prev: filterStruct) => {
                                                if (prev["id_region"] === regionInfo["id_region"]) {
                                                    return ({
                                                        ...prev,
                                                        id_region: ""
                                                    } as filterStruct)
                                                }
                                                return ({
                                                    ...prev,
                                                    id_region: regionInfo["id_region"]
                                                } as filterStruct)
                                            })
                                        }}
                                    />
                                    <div className="regionBarNameBlock">
                                        <div className="regionBarName">
                                            {Translations[regionInfo["id_region"]][getLang]}
                                        </div>
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                );
            default:
                return null;
        }
    };

    return (
        <div
            ref={rootRef}
            className={`graphArea ${className}`}
            style={style}
        >
            <div className="graphHeader">
                <div className="graphTitle">{Translations["dailyGraphTitle"][getLang]}</div>

                <div className="graphTypes">
                    {types.map((type: GraphType) => (
                        <div
                            key={type}
                            className={`graphType ${type === getCurrentType ? "active" : ""}`}
                            onClick={() => setCurrentType(type)}
                        >
                            {Translations[type][getLang]}
                        </div>
                    ))}
                </div>
            </div>

            <div
                style={{
                    minHeight: 0,
                    minWidth: 0,
                    width: "100%",
                    height: "100%",
                    position: "relative",
                    overflow: "hidden"
                }}
            >
                {graphContent()}
            </div>
        </div>
    );
}
