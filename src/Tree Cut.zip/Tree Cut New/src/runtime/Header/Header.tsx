import { React } from "jimu-core"
import "./Header.css"

import { filterStruct, selectedPolyStruct } from "../../configs/config";
import { Theme, ThemeKey } from "../../configs/themes";
import { LangKey } from "../../configs/translations";
import Button from "../Button/Button";
import { FilterIcon, LanguageIcon, MenuIcon, SearchIcon } from "../../configs/icon";

type buttonsType = "" | "search"
interface headerProps {
    setSelectedPoly: React.Dispatch<React.SetStateAction<selectedPolyStruct>>;
    setFilter: React.Dispatch<React.SetStateAction<filterStruct>>;
    getTheme: ThemeKey;
    setTheme: React.Dispatch<React.SetStateAction<ThemeKey>>;
    getLang: LangKey;
    setLang: React.Dispatch<React.SetStateAction<LangKey>>;
}

export default function Header({
    setSelectedPoly,
    setFilter,
    getTheme,
    setTheme,
    getLang,
    setLang
}: headerProps) {
    const [getCurrentBtn, setCurrentBtn] = React.useState<buttonsType>("search" as buttonsType)
    return <div className="headerArea">
        <div className="headerLeftArea"></div>
        <div className="headerMiddleArea"></div>
        <div className="headerRightArea">
            <Button
                getTheme={getTheme}
                Icon={SearchIcon}
            >
                123
            </Button>
            <Button
                getTheme={getTheme}
                Icon={FilterIcon}
            >
                123
            </Button>
            <Button
                getTheme={getTheme}
                Icon={LanguageIcon}
            >
                123
            </Button>
            <Button
                getTheme={getTheme}
                Icon={MenuIcon}
            >
                123
            </Button>
        </div>
    </div>
}