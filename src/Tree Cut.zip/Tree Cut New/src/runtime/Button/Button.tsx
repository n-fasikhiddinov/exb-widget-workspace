import { React } from "jimu-core"
import "./Button.css"

import { CloseIcon } from "../../configs/icon"
import { Theme, ThemeKey } from "../../configs/themes"

type SizeProp = string | number

type IconProps = {
    size: SizeProp
    color: string
}

interface buttonProps {
    Icon: React.ComponentType<IconProps>
    children: React.ReactNode
    getTheme: ThemeKey
}

export default function Button({
    Icon,
    children,
    getTheme
}: buttonProps) {
    const [isActive, toggleActive] = React.useState<boolean>(false);
    return (
        <div className="buttonArea">
            <div
                className={`buttonBlock ${isActive ? "active" : ""}`}
                onClick={() => toggleActive(!isActive)}
            >
                {isActive ? (
                    <CloseIcon
                        size="30px"
                        color={`rgb(${Theme[getTheme]["--main-color"]})`}
                    />
                ) : (
                    <Icon
                        size={"30px"}
                        color={`rgb(${Theme[getTheme]["--main-color"]})`}
                    />
                )}
            </div>

            {isActive && children}
        </div>
    )
}