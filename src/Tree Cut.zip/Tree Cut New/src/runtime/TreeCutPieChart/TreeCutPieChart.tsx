import { React } from "jimu-core";
import "./TreeCutPieChart.css";

import FeatureLayer from "@arcgis/core/layers/FeatureLayer";
import { LangKey, Translations } from "../../configs/translations";
import { otherColors, ThemeKey } from "../../configs/themes";
import { buildWhereQuery, filterStruct, summaryStruct } from "../../configs/config";
import Query from "@arcgis/core/rest/support/Query";
import { PieChart, pieClasses, } from "@mui/x-charts/PieChart";
import Indicator from "../Indicator/Indicator";

interface pieChartProps {
    getSummary: summaryStruct
    mainDateRef: React.MutableRefObject<FeatureLayer>
    style?: React.CSSProperties
    className?: string
    getLang: LangKey
    getTheme: ThemeKey
    getFilter: filterStruct
    setFilter: React.Dispatch<React.SetStateAction<filterStruct>>
}

type StatusKey = 0 | 1 | 2
const getColor = (status: StatusKey): string => {
    switch (status) {
        case 0:
            return otherColors["--in-process-color"]
        case 1:
            return otherColors["--no-confirmed-color"]
        case 2:
            return otherColors["--confirmed-color"]
        default:
            return otherColors["--in-process-color"]
    }
}

export default function TreeCutPieChart({
    style = {},
    className = "",
    mainDateRef,
    getLang,
    getTheme,
    getFilter,
    setFilter
}: pieChartProps) {
    const [getPieChartSize, setPieChartSize] = React.useState({
        width: window.innerWidth <= 1920 ? 250 : 320,
        height: window.innerHeight <= 1080 ? 250 : 320,
    })
    const [getMax, setMax] = React.useState<number>(0)
    const [getPieChartData, setPieChartData] = React.useState<any[]>([
        {
            id: 0,
            value: 0,
            color: "#00000000"
        },
        {
            id: 0,
            value: 0,
            color: "#00000000"
        },
        {
            id: 0,
            value: 0,
            color: "#00000000"
        },
    ])
    const [getHoveredStatus, setHoveredStatus] = React.useState<StatusKey | null>(null)

    React.useEffect(() => {
        mainDateRef.current.queryFeatures(new Query({
            where: buildWhereQuery(getFilter, "PieChart"),
            returnGeometry: false,
            groupByFieldsForStatistics: ["status"],
            orderByFields: ["count DESC"],
            outStatistics: [
                {
                    statisticType: "count",
                    onStatisticField: "area",
                    outStatisticFieldName: "count"
                },
                {
                    statisticType: "sum",
                    onStatisticField: "area",
                    outStatisticFieldName: "sum"
                }
            ]
        }))
            .then((result: __esri.FeatureSet) => {
                let count = 0
                const normalized = result.features.map((feature: __esri.Graphic) => {
                    let alpha = 1
                    if (getFilter["status"] !== null) {
                        alpha = getFilter["status"] === feature.attributes.status ? 1 : 0.4
                    }
                    const featureCount = Number(feature.attributes.count) || 0
                    count += featureCount
                    return {
                        id: Number(feature.attributes.status) as StatusKey,
                        value: featureCount,
                        color: `rgb(${getColor(feature.attributes.status)}, ${alpha})`
                    }
                })

                setPieChartData(normalized)
                setMax(count)
            })
    }, [getFilter, mainDateRef])

    const toggleStatus = React.useCallback((status: StatusKey) => {
        setFilter((prev: filterStruct) => {
            const nextStatus = prev.status === status ? null : status
            return {
                ...prev,
                status: nextStatus
            } as filterStruct
        })
    }, [setFilter])

    const getPercent = React.useCallback(() => {
        if (getFilter["status"] === null) return 100;
        const value = getPieChartData.find((item: any) => item.id === getFilter["status"])["value"]
        return getMax > 0 ? (value / getMax) * 100 : 0
    }, [getPieChartData])

    return <div
        className={`pieChartArea ${className}`}
        style={style}
    >
        <div className="pieChartHeader">
            <div className="pieChartBackBtn"></div>
            <div className="pieChartTitle">{Translations["pieChartTitle"][getLang]}</div>
        </div>
        <div className="pieChartContent">
            <div className="pieChartList">
                {getPieChartData.map((item: any) => {
                    const isSelected = getFilter["status"] === item.id
                    const isHovered = getHoveredStatus === item.id && getHoveredStatus !== isSelected
                    const isDimmed = getFilter["status"] !== null && !isSelected

                    return (
                        <div
                            key={status}
                            className={`pieChartItem ${isSelected && "isSelected"} ${isHovered && "isHovered"} ${isDimmed && "isDimmed"}`}
                            style={{
                                ["--status-color" as string]: getColor(item.id)
                            }}
                            onClick={() => toggleStatus(item.id)}
                            onMouseEnter={() => setHoveredStatus(item.id)}
                            onMouseLeave={() => setHoveredStatus(null)}
                        >
                            <span className="pieChartStatusSquare" />
                            <span className="pieChartStatusName">{Translations[item.id][getLang]}</span>
                            <span className="pieChartStatusPercent">
                                <Indicator
                                    value={getMax > 0 ? (item.value / getMax) * 100 : 0}
                                    duration={600}
                                />%
                            </span>
                            <span className="pieChartStatusCount">
                                <Indicator
                                    value={item.value}
                                    duration={600}
                                />
                                <span className="pieChartStatusCountTotal"> /
                                    <Indicator
                                        value={getMax}
                                        duration={600}
                                    />
                                </span>
                            </span>
                        </div>
                    )
                })}
            </div>

            <div className="pieChartVisual">
                <div className="pieChartVisualInfo">
                    <div className="pieChartVisualValue">
                        <Indicator
                            value={getPercent()}
                            duration={600}
                        />%
                    </div>
                    <div className="pieChartVisualText">{Translations["pieInformation"][getLang]}</div>
                </div>
                <PieChart
                    width={getPieChartSize.width}
                    height={getPieChartSize.height}
                    series={[
                        {
                            data: getPieChartData,
                            innerRadius: getPieChartSize.height / 4 + 10,
                            outerRadius: getPieChartSize.height / 2 - 10,
                            paddingAngle: 2,
                            cornerRadius: 15,
                            startAngle: 0,
                            endAngle: 360,
                            highlightScope: { highlight: "item" },
                            highlighted: {
                                outerRadius: getPieChartSize.height / 2
                            },
                        },
                    ]}
                    slotProps={{
                        legend: { hidden: true },
                        tooltip: { trigger: "none" },
                        noDataOverlay: {
                            children: null
                        }
                    }}
                    onItemClick={(_, item) => toggleStatus(getPieChartData[item.dataIndex]["id"])}
                    onHighlightChange={(item: any) =>
                        setHoveredStatus(() => {
                            if (item?.["dataIndex"] === undefined) return null;
                            return getPieChartData[item["dataIndex"]]["id"];
                        })
                    }
                    sx={{
                        [`.${pieClasses.arc}`]: {
                            stroke: "none",
                            strokeWidth: 0,
                        },
                    }}
                />
            </div>
        </div>
    </div>
}
