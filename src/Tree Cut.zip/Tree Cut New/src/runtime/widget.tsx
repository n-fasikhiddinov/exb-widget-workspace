/** @jsx jsx */
import { React, jsx } from "jimu-core";
import MapView from "@arcgis/core/views/MapView";
import FeatureLayer from "@arcgis/core/layers/FeatureLayer";
import Query from "@arcgis/core/rest/support/Query.js";

import "./style.css"

import { LangKey } from "../configs/translations";
import { Theme, ThemeKey, otherColors } from "../configs/themes";
import {
    uniqueIdField,
    filterStruct,
    buildWhereQuery,
    selectedPolyStruct,
    summaryStruct
} from "../configs/config";

import CustomMap from "./CustomMap/CustomMap";
import Popup from "./Popup/Popup";
import Indicators from "./Indicator/Indicators";
import StatisticInformation from "./StatisticInformation/StatisticInformation";
import Header from "./Header/Header";

export default function Widget() {
    console.log("[Widget Rerender]");

    const mainDateRef = React.useRef<FeatureLayer>(new FeatureLayer({
        id: "mainPolygon",
        url: "https://gis.uzspace.uz/uzspacesrvr/rest/services/TreeCut/FeatureServer/0",
        outFields: [uniqueIdField, "status"],
        renderer: {
            type: "unique-value",
            field: "status",
            uniqueValueInfos: Object.values(otherColors).map((item: string, index: number) => {
                const color = item.split(",").map(v => Number(v))
                return ({
                    value: index,
                    symbol: {
                        type: "simple-fill",
                        color: [...color, 0.3],
                        outline: { type: "simple-line", color: [...color, 1], width: 3 }
                    }
                })
            })
        }
    }));

    const [getMap, setMap] = React.useState<MapView>();
    const [getLang, setLang] = React.useState<LangKey>("RU" as LangKey);
    const [getTheme, setTheme] = React.useState<ThemeKey>("main" as ThemeKey);
    const [isFullScreen, toggleScreen] = React.useState<boolean>(false);
    const [getSummary, setSummary] = React.useState<summaryStruct>({
        count: 0,
        sum: 0,
        dailyCount: 0,
    } as summaryStruct)
    const [getSelectedPoly, setSelectedPoly] = React.useState<selectedPolyStruct>({
        [uniqueIdField]: ""
    } as selectedPolyStruct);
    const [getFilter, setFilter] = React.useState<filterStruct>({
        id_country: "",
        id_region: "",
        id_district: "",

        year: [],
        month: [],
        day: [],

        status: null,
    } as filterStruct);

    React.useEffect(() => {
        mainDateRef.current.definitionExpression = buildWhereQuery(getFilter, "Indicator");
        mainDateRef.current.queryFeatures(new Query({
            where: buildWhereQuery(getFilter, "Indicator"),
            returnGeometry: false,
            outStatistics: [
                {
                    statisticType: "count",
                    onStatisticField: "area",
                    outStatisticFieldName: "count"
                },
                {
                    statisticType: "sum",
                    onStatisticField: "area",
                    outStatisticFieldName: "sum"
                }
            ]
        }))
            .then((result: any) => {
                setSummary((prev: summaryStruct) => {
                    const info = result["features"][0]["attributes"];
                    return ({
                        ...prev,
                        count: info["count"],
                        sum: info["sum"]
                    } as summaryStruct)
                })
            })
            .catch((error: any) => console.error("[Widget]:", error))
    }, [getFilter])

    React.useEffect(() => {
        console.log(getSelectedPoly);
    }, [getSelectedPoly])

    React.useEffect(() => {
        console.log(getFilter);
        console.log(buildWhereQuery(getFilter, "Indicator"));
    }, [getFilter])

    return (<div className="mainArea" style={{
        ...Theme[getTheme as ThemeKey]
    }}>
        <CustomMap
            setSelectedPoly={setSelectedPoly}
            getSelectedPoly={getSelectedPoly}
            toggleScreen={toggleScreen}
            isFullScreen={isFullScreen}
            mainDateRef={mainDateRef}
            setMap={setMap}
            getMap={getMap}
            getTheme={getTheme}
        />
        <Popup
            mainDateRef={mainDateRef}
            isFullScreen={isFullScreen}
            setSelectedPoly={setSelectedPoly}
            getSelectedPoly={getSelectedPoly}
            getLang={getLang}
            getTheme={getTheme}
        />
        <Header
            setSelectedPoly={setSelectedPoly}
            setFilter={setFilter}
            getTheme={getTheme}
            setTheme={setTheme}
            getLang={getLang}
            setLang={setLang}
        />
        <div className="contentArea">
            <Indicators
                getTheme={getTheme}
                getLang={getLang}
                getSummary={getSummary}
                isFullScreen={isFullScreen}
            />
            <StatisticInformation
                getSummary={getSummary}
                mainDateRef={mainDateRef}
                setSelectedPoly={setSelectedPoly}
                getSelectedPoly={getSelectedPoly}
                isFullScreen={isFullScreen}
                getFilter={getFilter}
                setFilter={setFilter}
                getTheme={getTheme}
                getLang={getLang}
            />
        </div>
    </div>);
}