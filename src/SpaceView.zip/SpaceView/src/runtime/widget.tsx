import { React, AllWidgetProps } from "jimu-core";
import "./style.css"

import Header from "./assets/Header/Header"
import CustomMap from "./assets/CustomMap/CustomMap"
import DragAndDrop from "./assets/DragAndDrop/DragAndDrop";

import {
    allThemes
} from "./config"

export default function CustomMapWidget(props: AllWidgetProps<any>) {
    const [getTheme, setTheme] = React.useState<string>("Dark")
    const [getLang, setLang] = React.useState<string>("UZ")
    const [getData, setData] = React.useState(["none", ""])
    const [getFile, setFile] = React.useState([])
    const [getUrl, setUrl] = React.useState<string>("https://sgm.uzspace.uz/image/rest/services/AdminRaster/republic_maxar_2026_year_1_monitoring/ImageServer")

    return (
        <div className="mainArea" style={allThemes[getTheme]}>
            <DragAndDrop
                active={getData[0]}
                onChange={(geometries) => {
                    setFile(geometries);
                }}
                clear={(type: string) => { setData([type, type]) }}
                getTheme={getTheme}
                getLang={getLang}
            />
            <Header
                setUrl={setUrl}
                onChange={(type: string, data: any) => { setData([type, data]) }}
                getTheme={getTheme}
                setTheme={(theme: string) => { setTheme(theme) }}
                getLang={getLang}
                setLang={(lang: string) => { setLang(lang) }}
            />
            <CustomMap
                getUrl={getUrl}
                headerInfo={getData}
                file={getFile}
                getTheme={getTheme}
                getLang={getLang}
                onChange={(type: string, data: any) => { setData([type, data]) }}
            />
        </div>
    );
}
